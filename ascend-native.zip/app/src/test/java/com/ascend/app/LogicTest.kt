package com.ascend.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {
    @Test fun dayPartBoundaries() {
        assertEquals("morning", Logic.dayPart(0))
        assertEquals("morning", Logic.dayPart(11))
        assertEquals("afternoon", Logic.dayPart(12))
        assertEquals("afternoon", Logic.dayPart(16))
        assertEquals("evening", Logic.dayPart(17))
        assertEquals("evening", Logic.dayPart(23))
    }

    @Test fun greetingUsesFirstNameOnly() {
        assertEquals("morning, Asha.", Logic.greetingTail(9, "Asha Rao"))
        assertEquals("evening.", Logic.greetingTail(20, "  "))
    }

    @Test fun themeMode() {
        assertTrue(Logic.themeIsDark("dark", false))
        assertFalse(Logic.themeIsDark("light", true))
        assertTrue(Logic.themeIsDark("system", true))
        assertFalse(Logic.themeIsDark(null, false))
    }
}
