package com.ascend.app

import com.ascend.app.domain.Cfg
import com.ascend.app.domain.Ranges
import com.ascend.app.domain.Res
import com.ascend.app.domain.Sec
import com.ascend.app.domain.Sess
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionTest {
    private val t0 = 1_700_000_000_000L

    @Test fun formatsLikeTheWebApp() {
        assertEquals("00:00", Sess.fmt(0)); assertEquals("01:05", Sess.fmt(65_000)); assertEquals("1:01:01", Sess.fmt(3_661_000))
        assertEquals("00:02", Sess.fmt(1500)); assertEquals("00:01", Sess.fmt(1499))
        assertEquals("4", Sess.num(4.0)); assertEquals("2.5", Sess.num(2.5)); assertEquals("0.33", Sess.num(1.0 / 3)); assertEquals("-1", Sess.num(-1.0))
        assertEquals("+4", Sess.sg(4.0)); assertEquals("−1", Sess.ng(1.0)); assertEquals("0", Sess.ng(0.0))
    }

    @Test fun rangeNumbersAndCompress() {
        assertEquals(listOf(1, 2, 3, 7), Ranges.numbers("1-3, 7"))
        assertEquals(listOf(5, 6), Ranges.numbers("6,5"))
        assertTrue(Ranges.numbers("x").isEmpty()); assertTrue(Ranges.numbers("").isEmpty()); assertTrue(Ranges.numbers("9-3").isEmpty())
        assertEquals("1-3,7", Ranges.compress(listOf(7, 1, 2, 3))); assertEquals("", Ranges.compress(emptyList()))
    }

    @Test fun homeworkSetupChecks() {
        assertEquals("", Sess.validateHw(1, 10, 4.0, 1.0))
        assertTrue(Sess.validateHw(null, 10, 4.0, 1.0).startsWith("Enter a valid"))
        assertTrue(Sess.validateHw(5, 4, 4.0, 1.0).startsWith("The last"))
        assertTrue(Sess.validateHw(1, 301, 4.0, 1.0).contains("300"))
        assertTrue(Sess.validateHw(1, 5, null, 1.0).contains("correct"))
        assertTrue(Sess.validateHw(1, 5, 4.0, -1.0).contains("negative"))
        val c = Sess.hwCfg("  ", 3, 5, 4.0, 1.0, "h1")
        assertEquals("Untitled task", c.name); assertEquals(listOf(3, 4, 5), c.q.map { it.no }); assertEquals("h1", c.hw)
    }

    @Test fun testPatternNumbersEachSubject() {
        val secs = listOf(Sec("A", 2, 4.0, 1.0), Sec("B", 1, 4.0, 2.0, true))
        val c = Sess.testCfg("", listOf("Phy", "Chem"), secs, 30)
        assertEquals("Untitled test", c.name); assertEquals(6, c.q.size)
        assertEquals(listOf(1, 2, 3, 1, 2, 3), c.q.map { it.no }); assertEquals(listOf(0, 0, 0, 1, 1, 1), c.q.map { it.sub })
        assertEquals(listOf(0, 0, 1, 0, 0, 1), c.q.map { it.sec }); assertEquals(3, c.q[2].pm); assertEquals(0, c.q[0].pm)
        assertEquals(30 * 60000L, c.dur); assertEquals(listOf("Phy", "Chem"), c.subs); assertEquals(2, c.secs.size)
        assertEquals("", Sess.validateTest(listOf("P"), true, secs, ""))
        assertTrue(Sess.validateTest(emptyList(), true, secs, "").contains("subject"))
        assertTrue(Sess.validateTest(emptyList(), false, emptyList(), "").contains("section"))
        assertTrue(Sess.validateTest(emptyList(), false, secs, "0").contains("duration"))
        assertTrue(Sess.validateTest(listOf("a", "b"), true, listOf(Sec(count = 200)), "").contains("300"))
        assertTrue(!Sec(pos = 1.0, partial = true).canPartial); assertEquals(0, Sec(pos = 1.0, partial = true).pm)
    }

    @Test fun answeringMovesOnAndFinishes() {
        var l = Sess.launch(Sess.hwCfg("W", 1, 3, 4.0, 1.0), t0, "s1")
        assertEquals("s1", l.cfg.id); assertEquals(t0, l.cfg.date)
        l = Sess.begin(l, t0)
        assertEquals(1, l.res[0]!!.v)
        assertEquals(0, Sess.answer(l, "A", t0 + 100).idx)          // double tap ignored
        l = Sess.answer(l, "A", t0 + 5000)
        assertEquals(1, l.idx); assertEquals(5000L, l.res[0]!!.t); assertEquals(1, l.res[0]!!.f)
        l = Sess.answer(l, "N", t0 + 9000)
        assertEquals(2, l.idx); assertEquals("N", l.res[1]!!.st)
        l = Sess.answer(l, "A", t0 + 20000)
        assertTrue(l.ended && !l.running)
        assertEquals(8.0, Sess.score(l), 0.0); assertEquals(12.0, Sess.maxMarks(l), 0.0)
        val c = Sess.calc(l)
        assertEquals(2, c.att); assertEquals(1, c.sk); assertEquals(0, c.un); assertEquals(0, c.wr); assertEquals(2, c.cor)
        assertEquals(20000L, c.tot); assertEquals(1, c.fi); assertEquals(2, c.si); assertEquals(3, c.vis); assertEquals(6666L, c.avg)
    }

    @Test fun pauseStopsTheClock() {
        var l = Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 2, 4.0, 1.0), t0, "a"), t0)
        assertEquals(3000L, l.elapsed(t0 + 3000))
        l = Sess.setPaused(l, true, t0 + 3000)
        assertEquals(3000L, l.elapsed(t0 + 60000))
        l = Sess.setPaused(l, false, t0 + 60000)
        assertEquals(3000L, l.elapsed(t0 + 60000)); assertEquals(5000L, l.elapsed(t0 + 62000))
        assertEquals(l, Sess.setPaused(l, false, t0 + 70000))
    }

    @Test fun jumpingBackContinuesTheQuestionTime() {
        var l = Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 3, 4.0, 1.0), t0, "a"), t0)
        l = Sess.jump(l, 2, t0 + 4000)
        assertEquals(2, l.idx); assertEquals(4000L, l.res[0]!!.t)
        assertEquals(1, l.res[2]!!.v)
        l = Sess.jump(l, 0, t0 + 10000)
        assertEquals(2, l.res[0]!!.v); assertEquals(4000L, l.base); assertEquals(5000L, l.elapsed(t0 + 11000))
        l = Sess.answer(l, "A", t0 + 12000)
        assertEquals(0, l.res[0]!!.f)                                  // second visit
        assertEquals(1, l.idx)                                         // next open question after 0 is 1
        assertEquals(l, Sess.jump(l, 1, t0 + 13000))
        assertEquals(l, Sess.jump(l, 9, t0 + 13000))
    }

    @Test fun nextOpenWrapsAround() {
        var l = Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 4, 4.0, 1.0), t0, "a"), t0)
        l = Sess.jump(l, 3, t0 + 1000)
        l = Sess.answer(l, "A", t0 + 2000)
        assertEquals(0, l.idx)                                         // after 3 the next open question wraps round to 0
    }

    @Test fun markingWrongAndPartialChangesScore() {
        val secs = listOf(Sec("", 2, 4.0, 1.0, true))
        var l = Sess.begin(Sess.launch(Sess.testCfg("T", emptyList(), secs, 0), t0, "t"), t0)
        l = Sess.answer(l, "A", t0 + 1000); l = Sess.answer(l, "A", t0 + 2000)
        assertEquals(8.0, Sess.score(l), 0.0)
        l = Sess.cycleMark(l, 0)
        assertTrue(l.res[0]!!.w); assertEquals(3.0, Sess.score(l), 0.0)                    // +4 -1
        l = Sess.cycleMark(l, 0)
        assertTrue(!l.res[0]!!.w); assertEquals(1, l.res[0]!!.p); assertEquals(5.0, Sess.score(l), 0.0)
        l = Sess.cycleMark(l, 0); assertEquals(2, l.res[0]!!.p)
        l = Sess.cycleMark(l, 0); assertEquals(3, l.res[0]!!.p)
        l = Sess.cycleMark(l, 0); assertEquals(0, l.res[0]!!.p); assertTrue(!l.res[0]!!.w)
        val c = Sess.calc(Sess.cycleMark(l, 0))
        assertEquals(1, c.wr); assertEquals(1, c.cor)
        val plain = Sess.cycleMark(Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 1, 4.0, 1.0), t0, "x"), t0).let { Sess.answer(it, "A", t0 + 1000) }, 0)
        assertTrue(plain.res[0]!!.w); assertEquals(0, Sess.cycleMark(plain, 0).res[0]!!.p)
        assertEquals(0.0, Sess.qMarks(plain.copy(res = listOf(Res(st = "N"))), 0), 0.0)
    }

    @Test fun subjectWiseStats() {
        val secs = listOf(Sec("", 2, 4.0, 1.0))
        var l = Sess.begin(Sess.launch(Sess.testCfg("T", listOf("P", "C"), secs, 0), t0, "t"), t0)
        l = Sess.answer(l, "A", t0 + 1000); l = Sess.answer(l, "N", t0 + 2000)
        l = Sess.answer(l, "A", t0 + 4000); l = Sess.answer(l, "A", t0 + 7000)
        val c = Sess.calc(l)
        assertEquals(2, c.subs.size); assertEquals(4.0, c.subs[0].sc, 0.0); assertEquals(8.0, c.subs[1].sc, 0.0)
        assertEquals(8.0, c.subs[0].mx, 0.0); assertEquals(1, c.subs[0].sk); assertEquals(5000L, c.subs[1].t)
        assertEquals("P · Q1", Sess.qLabel(l, 0)); assertEquals("C · Q2", Sess.qLabel(l, 3))
    }

    @Test fun timedTestEndsAtTheLimit() {
        val c = Sess.testCfg("T", emptyList(), listOf(Sec("", 5, 4.0, 1.0)), 10)
        var l = Sess.begin(Sess.launch(c, t0, "t"), t0)
        assertEquals(10 * 60000L, Sess.testLeft(l, t0)); assertEquals(4 * 60000L, Sess.testLeft(l, t0 + 6 * 60000))
        assertTrue(!Sess.timeUp(l, t0 + 9 * 60000)); assertTrue(Sess.timeUp(l, t0 + 10 * 60000))
        l = Sess.end(l, t0 + 11 * 60000)
        assertTrue(l.ended); assertEquals(10 * 60000L, l.testUsed)
        val early = Sess.end(Sess.begin(Sess.launch(c, t0, "t"), t0), t0 + 3 * 60000)
        assertEquals(3 * 60000L, early.testUsed); assertEquals(3 * 60000L, early.res[0]!!.t)
        val hw = Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 2, 4.0, 1.0), t0, "h"), t0)
        assertNull(Sess.testLeft(hw, t0)); assertTrue(!Sess.timeUp(hw, t0 + 99999999))
        assertEquals(0L, Sess.end(hw, t0 + 5000).testUsed)
    }

    @Test fun savedRecordKeepsUnknownFields() {
        val web = """{"id":"s9","v":1,"kind":"hw","name":"Web","date":5,"cfg":{"kind":"hw","name":"Web","id":"s9","date":5,"from":1,"to":2,"pos":4,"neg":1,"subs":[],"secs":[],"dur":0,"Q":[{"no":1,"sub":0,"sec":0,"pos":4,"neg":1,"pm":0},{"no":2,"sub":0,"sec":0,"pos":4,"neg":1,"pm":0}],"mystery":"keep"},"res":[{"st":"A","t":1000,"w":true,"p":0,"v":1,"f":1,"tag":"x"},null],"testUsed":0,"savedAt":7}"""
        val l = Sess.parseRecord(web)!!
        assertEquals("s9", l.cfg.id); assertEquals(2, l.n); assertTrue(l.res[0]!!.w); assertNull(l.res[1])
        val back = JSONObject(Sess.recordJson(l, 99))
        assertEquals("keep", back.getJSONObject("cfg").getString("mystery"))
        assertEquals("x", back.getJSONArray("res").getJSONObject(0).getString("tag"))
        assertTrue(back.getJSONArray("res").isNull(1)); assertEquals(99L, back.getLong("savedAt")); assertEquals("s9", back.getString("id"))
        assertNull(Sess.parseRecord("{}")); assertNull(Sess.parseRecord("nope")); assertNull(Sess.parseRecord(web.replace("\"res\":[{", "\"res\":[{\"x\":1},{\"x\":1},{")))
    }

    @Test fun draftResumesWhereYouStopped() {
        var l = Sess.begin(Sess.launch(Sess.hwCfg("W", 1, 3, 4.0, 1.0), t0, "d1"), t0)
        l = Sess.answer(l, "A", t0 + 2000)
        val d = Sess.parseDraft(Sess.draftJson(l, t0 + 5000))!!
        assertEquals(1, d.live.idx); assertEquals(3000L, d.curT); assertEquals(t0 + 5000, d.savedAt)
        val r = Sess.resume(d, t0 + 100000)
        assertTrue(r.running && !r.ended); assertEquals(1, r.idx); assertEquals(3000L, r.elapsed(t0 + 100000)); assertEquals(2, r.res[1]!!.v)
        assertNull(Sess.parseDraft("{\"v\":1}"))
    }

    @Test fun reportTextHasTheMainLines() {
        var l = Sess.begin(Sess.launch(Sess.hwCfg("Rotation", 1, 2, 4.0, 1.0), t0, "r"), t0)
        l = Sess.answer(l, "A", t0 + 5000); l = Sess.answer(l, "N", t0 + 8000)
        val r = Sess.reportText(l, "1 Jan 2026")
        assertTrue(r.contains("SESSION REPORT")); assertTrue(r.contains("Task: Rotation")); assertTrue(r.contains("Range: Q1 to Q2 (2 questions)"))
        assertTrue(r.contains("SCORE: 4 / 8")); assertTrue(r.contains("Attempted: 1 (correct 1, wrong 0)")); assertTrue(r.contains("Accuracy: 100%"))
        assertTrue(r.contains("Q1: Attempted ✓ correct · 00:05 [+4]")); assertTrue(r.contains("Q2: Not attempted · 00:03"))
    }
}
