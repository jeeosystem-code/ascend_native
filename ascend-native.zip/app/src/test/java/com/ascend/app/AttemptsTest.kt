package com.ascend.app.domain

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AttemptsTest {
    private val secs = listOf(Sec("MCQ", 3, 4.0, 1.0), Sec("Num", 1, 4.0, 0.0))
    private fun cfg(): Cfg = Sess.attemptCfg("T1", listOf("Physics"), secs, 3600000, "tx", "e", "", null)!!.with("a1", 1000)

    private fun res(): List<Res?> = listOf(
        Res(st = "A", t = 41000, f = 1),            // right
        Res(st = "A", t = 90000, w = true, f = 1),  // wrong
        Res(st = "N", t = 5000, d = true),          // skipped, doubt
        Res(st = "A", t = 30000, p = 0, f = 0),     // right on return
    )

    @Test fun cfgCarriesTest() {
        val c = cfg()
        assertEquals("tx", c.tid); assertEquals("e", c.tm); assertEquals(4, c.q.size); assertEquals(3600000L, c.dur)
        assertEquals(null, Sess.attemptCfg("x", listOf("P"), secs, 0, "t", "r", "", setOf("9.9")))
        val only = Sess.attemptCfg("x", listOf("P"), secs, 0, "t", "r", "b", setOf("0.2", "0.4"))!!
        assertEquals(listOf(2, 4), only.q.map { it.no }); assertEquals("b", only.baseId)
    }

    @Test fun scoreAndStates() {
        val a = Attempt(At.record(cfg(), res(), 120000, null, 5000))
        assertEquals(7.0, a.sc, 0.0001)   // 4 - 1 + 0 + 4
        assertEquals(16.0, a.mx, 0.0001)
        assertEquals(120, a.used)
        assertEquals(listOf("c", "w", "s", "c"), a.q.map { it.state })
        assertEquals(41, a.q[0].t)
        assertTrue(a.q[2].bits and 2 != 0)          // doubt
        assertTrue(a.q[0].bits and 4 != 0)          // first look
        val s = At.stat(a)
        assertEquals(2, s.c); assertEquals(1, s.w); assertEquals(1, s.s); assertEquals(3, s.att)
        assertEquals(67, s.acc); assertEquals(44, s.pct)
        assertEquals(1, s.fc); assertEquals(2, s.fa); assertEquals(1, s.sa); assertEquals(1, s.sc2)
        assertEquals(9.0, s.lost, 0.0001)           // wrong 4+1, skipped 4
    }

    @Test fun lostByReasons() {
        val j = At.record(cfg(), res(), 0, null, 1)
        j.put("rm", JSONObject().put("0.2", 3))  // wrong: Silly + Language
        val a = Attempt(j)
        val l = At.lostBy(a)
        assertEquals(2.5, l[1]!!, 0.0001); assertEquals(2.5, l[2]!!, 0.0001)
        assertEquals(4.0, l[0]!!, 0.0001)          // skipped q3 untagged
    }

    @Test fun keepsReasonsAndNotes() {
        val j = At.record(cfg(), res(), 0, null, 1)
        j.put("rm", JSONObject().put("0.2", 1)).put("nt", JSONObject().put("0.2", "rushed"))
        val k = At.record(cfg(), res(), 5000, j, 9)
        assertEquals(1, Attempt(k).rm("0.2")); assertEquals("rushed", Attempt(k).nt("0.2")); assertEquals(9L, k.optLong("u"))
    }

    @Test fun listAndNumbers() {
        val c1 = Cfg(JSONObject(cfg().j.toString()).put("date", 100)); val c2 = Cfg(JSONObject(c1.j.toString()).put("id", "a2").put("date", 200)); val c3 = Cfg(JSONObject(c1.j.toString()).put("id", "a3").put("date", 300).put("tm", "r"))
        val recs = listOf(At.record(c2, res(), 0, null, 2), At.record(c1, res(), 0, null, 1), At.record(c3, res(), 0, null, 3))
        val l = At.list(recs, "tx")
        assertEquals(listOf("a1", "a2", "a3"), l.map { it.id })
        assertEquals(2, At.no(recs, l[1])); assertEquals(0, At.no(recs, l[2]))
        assertEquals(emptyList<Attempt>(), At.list(recs, "other"))
    }

    @Test fun latestAndOpenKeys() {
        val c1 = cfg()
        val r1 = At.record(c1, res(), 0, null, 1)
        val again = Sess.attemptCfg("T1 review", listOf("Physics"), secs, 0, "tx", "r", "a1", setOf("0.2", "0.3"))!!.with("a2", 5000)
        val r2 = At.record(again, listOf(Res(st = "A", t = 1000), null), 0, null, 2)
        val recs = listOf(r1, r2)
        assertEquals(setOf("0.3"), At.openKeys(recs, "tx"))
        assertEquals("c", At.latest(recs, "tx")["0.2"]!!.state)
    }

    @Test fun idsAndChunks() {
        assertEquals("zz_att_abc_2", At.docId("abc", 2)); assertEquals("abc", At.tidOf("zz_att_abc_12")); assertEquals("at", Merge.kind("zz_att_abc_1"))
        val big = (1..5).map { JSONObject().put("id", "a$it").put("k", "a").put("o", it).put("pad", "x".repeat(300000)) }
        val ch = At.chunks(big)
        assertEquals(3, ch.size); assertEquals(5, ch.sumOf { it.size })
        val p = JSONObject().put("id", "ptx").put("k", "p").put("o", 0)
        assertEquals("p", At.chunks(big + p)[0][0].optString("k"))
        val m = Merge.mergeRow("at", "{\"recs\":[{\"id\":\"a\",\"u\":1}]}", "{\"recs\":[{\"id\":\"a\",\"u\":2},{\"id\":\"b\",\"u\":1}]}")!!
        assertTrue(m.changed); assertTrue(m.need.not()); assertEquals(2, JSONObject(m.json).getJSONArray("recs").length())
    }

    @Test fun tagAndChapters() {
        val recs = ArrayList<JSONObject>()
        val a1 = At.record(cfg(), res(), 0, null, 1); recs.add(a1)
        At.tag(recs, "tx", 0, listOf(1, 2), "chA", 10)
        At.tag(recs, "tx", 0, listOf(3), "chB", 11)
        assertEquals("chA", At.chapterOf(recs, "tx", "0.2")); assertEquals("", At.chapterOf(recs, "tx", "0.4"))
        assertEquals(2, recs.size)
        val a = At.list(recs, "tx")[0]
        val (rows, un) = At.chaptersOf(recs, a) { true }
        assertEquals(1, un)
        assertEquals(listOf("chB", "chA"), rows.map { it.id })     // chB: skipped only (0 att) -> weakest first with fraction 0
        val chA = rows.first { it.id == "chA" }
        assertEquals(1, chA.c); assertEquals(1, chA.w); assertEquals(50, chA.acc); assertEquals(5.0, chA.lost, 0.0001)
        At.tag(recs, "tx", 0, listOf(2), "", 12)
        assertEquals("", At.chapterOf(recs, "tx", "0.2"))
        assertEquals(1, At.chaptersOf(recs, a) { it == "chB" }.first.size)
    }

    @Test fun notebookAndReport() {
        val recs = ArrayList<JSONObject>()
        recs.add(At.record(cfg(), res(), 0, null, 1))
        At.tag(recs, "tx", 0, listOf(1, 2, 3), "chA", 10)
        val t = TestRec(JSONObject().put("id", "tx").put("f", "f1").put("n", "T1").put("secs", org.json.JSONArray()).put("subs", org.json.JSONArray().put("Physics")))
        val nb = At.allLatest(recs, listOf(t)) { it == "f1" }
        assertEquals(4, nb.size)
        assertEquals(listOf("w", "s"), nb.map { it.e.state }.filter { it == "w" || it == "s" })
        assertEquals(0, At.allLatest(recs, listOf(t)) { false }.size)
        val cr = At.chapterReport(recs, listOf(t), { true }, { true })
        assertEquals(1, cr.size); assertEquals(3, cr[0].n); assertEquals(1, cr[0].c); assertEquals(1, cr[0].w); assertEquals(1, cr[0].s)
        assertEquals(listOf("T1"), cr[0].tests.toList())
    }

    @Test fun shareText() {
        val recs = ArrayList<JSONObject>()
        recs.add(At.record(cfg(), res(), 120000, null, 1))
        At.tag(recs, "tx", 0, listOf(1, 2), "chA", 10)
        val txt = At.reportText(At.list(recs, "tx")[0], "T1", "28 Oct", { if (it == "chA") "Kinematics" else null }, recs)
        assertTrue(txt.startsWith("T1 · 28 Oct\nScore 7 / 16 (44%)"))
        assertTrue(txt.contains("Kinematics: 50%"))
        assertTrue(txt.contains("Not tagged: 9"))
    }
}
