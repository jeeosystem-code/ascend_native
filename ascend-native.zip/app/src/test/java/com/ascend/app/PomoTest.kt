package com.ascend.app

import com.ascend.app.domain.FocusEntry
import com.ascend.app.domain.Merge
import com.ascend.app.domain.Pomo
import com.ascend.app.domain.PomoRun
import com.ascend.app.domain.PomoSettings
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId

class PomoTest {
    private val z = ZoneId.of("UTC")
    private val s = PomoSettings()
    private val t0 = 1_700_000_000_000L
    private val min = 60000L

    @Test fun formatsTimeAndMinutes() {
        assertEquals("25:00", Pomo.fmt(25 * min))
        assertEquals("00:01", Pomo.fmt(1))
        assertEquals("00:00", Pomo.fmt(0))
        assertEquals("09:59", Pomo.fmt(9 * min + 59_000))
        assertEquals("45 min", Pomo.hm(45))
        assertEquals("1h 30m", Pomo.hm(90))
        assertEquals("2h ", Pomo.hm(120))
    }

    @Test fun settingsStayInRange() {
        assertEquals(180, PomoSettings(f = 180).bump("f", 1).f)
        assertEquals(5, PomoSettings(f = 5).bump("f", -1).f)
        assertEquals(30, s.bump("f", 1).f)
        assertEquals(1, PomoSettings(s = 1).bump("s", -1).s)
        assertEquals(8, PomoSettings(e = 8).bump("e", 1).e)
        assertEquals(s, PomoSettings.parse(s.toJson()))
        assertEquals(s, PomoSettings.parse("garbage"))
        assertEquals(180, PomoSettings.parse("{\"f\":999}").f)
    }

    @Test fun startRunsFocusBlock() {
        val r = Pomo.start("  Rotation ", "hw1", "abc", s, t0)
        assertEquals("focus", r.ph); assertTrue(r.run); assertEquals(t0 + 25 * min, r.end)
        assertEquals("Rotation", r.lab); assertEquals("abc", r.id)
        assertEquals(25 * min, Pomo.left(r, t0)); assertEquals(10 * min, Pomo.left(r, t0 + 15 * min))
        assertEquals(0L, Pomo.left(r, t0 + 99 * min))
        assertTrue(!Pomo.due(r, t0 + 24 * min)); assertTrue(Pomo.due(r, t0 + 25 * min))
    }

    @Test fun pauseAndResumeKeepRemainingTime() {
        val r = Pomo.start("", "", "a", s, t0)
        val p = Pomo.toggle(r, s, t0 + 10 * min)
        assertTrue(!p.run); assertEquals(15 * min, p.left)
        assertEquals(15 * min, Pomo.left(p, t0 + 500 * min))
        val q = Pomo.toggle(p, s, t0 + 50 * min)
        assertTrue(q.run); assertEquals(t0 + 65 * min, q.end)
    }

    @Test fun finishedFocusBlockIsSavedAndWaitsForBreak() {
        val r = Pomo.start("Maths", "", "a", s, t0)
        val st = Pomo.end(r, s, null, true, t0 + 25 * min, z, 3)
        assertEquals("short", st.run.ph); assertTrue(st.run.wait); assertTrue(!st.run.run)
        assertEquals(1, st.run.n); assertEquals(1, st.run.cel); assertEquals(25, st.run.sm)
        assertEquals("Block done. Take a short break.", st.alert)
        val e = st.entry!!
        assertEquals("pm:a", e.key); assertEquals(25, e.m); assertEquals(1, e.b); assertEquals("Maths", e.lab)
        assertEquals("2023-11-14", e.d)
        assertEquals(5 * min, st.run.left)
    }

    @Test fun fourthBlockEndsSessionWithLongBreakNext() {
        var r = Pomo.start("", "", "a", s, t0)
        var now = t0
        var last: com.ascend.app.domain.PomoStep? = null
        for (i in 1..4) {
            now += 25 * min
            last = Pomo.end(r, s, null, true, now, z, 0)
            r = last.run
            if (i < 4) { r = Pomo.begin(r.copy(cel = 0), "focus", s, now); }
        }
        assertEquals("long", r.ph); assertEquals(2, r.cel); assertEquals("Session complete. Well done.", last!!.alert)
        assertEquals(4, r.n)
        assertEquals(100, last.entry!!.m); assertEquals(4, last.entry!!.b)
    }

    @Test fun skippingFocusSavesElapsedMinutesOnly() {
        val r = Pomo.start("", "", "a", s, t0)
        val st = Pomo.end(r, s, null, false, t0 + 10 * min + 20_000, z, 0)
        assertEquals(10, st.entry!!.m); assertEquals(0, st.entry!!.b)
        assertEquals(0, st.run.n); assertNull(st.alert)
        assertEquals("short", st.run.ph)
        assertEquals(0, Pomo.end(r, s, null, false, t0 + 10_000, z, 0).entry.let { it?.m ?: 0 })
    }

    @Test fun breakEndsBackToFocusAndAutoStartWorks() {
        val r = Pomo.start("", "", "a", s, t0)
        val br = Pomo.end(r, s, null, true, t0 + 25 * min, z, 0).run
        val b2 = Pomo.begin(br.copy(cel = 0), "short", s, t0 + 26 * min)
        val manual = Pomo.end(b2, s, null, true, t0 + 31 * min, z, 0)
        assertEquals("focus", manual.run.ph); assertTrue(manual.run.wait); assertEquals("Break over. Ready to focus?", manual.alert)
        val auto = Pomo.end(b2, s.copy(auto = true), null, true, t0 + 31 * min, z, 0)
        assertTrue(auto.run.run); assertEquals("focus", auto.run.ph); assertEquals(t0 + 31 * min + 25 * min, auto.run.end)
    }

    @Test fun longBreakResetsBlockCount() {
        val r = PomoRun(ph = "long", run = true, tot = 15 * min, end = t0 + 15 * min, n = 4, id = "a", ts = t0)
        val st = Pomo.end(r, s, null, true, t0 + 15 * min, z, 0)
        assertEquals(0, st.run.n); assertEquals("focus", st.run.ph)
    }

    @Test fun liveMinutesAreSavedWhileRunningWithoutDoubleCounting() {
        val r = Pomo.start("", "", "a", s, t0)
        assertNull(Pomo.live(r, s, null, t0 + 30_000, z, false).entry)
        val a = Pomo.live(r, s, null, t0 + 7 * min, z, false)
        assertEquals(7, a.entry!!.m); assertEquals(0, a.entry!!.b)
        assertNull(Pomo.live(a.run, s, a.entry, t0 + 7 * min + 5000, z, false).entry)
        assertNotNull(Pomo.live(a.run, s, a.entry, t0 + 7 * min + 5000, z, true).entry)
        val fin = Pomo.end(a.run, s, a.entry, true, t0 + 25 * min, z, 0)
        assertEquals(25, fin.entry!!.m); assertEquals(1, fin.entry!!.b)
    }

    @Test fun stopSavesPartialBlockAndClears() {
        val r = Pomo.start("x", "", "a", s, t0)
        val st = Pomo.stop(r, s, null, t0 + 12 * min, z)
        assertTrue(st.run.idle); assertEquals(12, st.entry!!.m)
        val br = Pomo.end(r, s, null, true, t0 + 25 * min, z, 0).run
        assertNull(Pomo.stop(br, s, null, t0 + 26 * min, z).entry)
    }

    @Test fun carriesOnFromAnEarlierSavedEntry() {
        val old = FocusEntry("pm:a", "2023-11-14", t0, 30, 1, "", 25, 5)
        val r = Pomo.start("", "", "a", s, t0)
        val st = Pomo.end(r, s, old, true, t0 + 25 * min, z, 0)
        assertEquals(55, st.entry!!.m); assertEquals(2, st.entry!!.b)
    }

    @Test fun runStateSurvivesSaveAndRestore() {
        val r = Pomo.start("Chem", "h9", "id1", s, t0)
        assertEquals(r, PomoRun.parse(r.toJson()))
        assertTrue(PomoRun.parse("nope").idle)
        assertTrue(PomoRun.parse("{\"ph\":\"idle\"}").idle)
    }

    @Test fun totalsAndPills() {
        val today = "2023-11-14"
        val now = t0
        val l = listOf(
            FocusEntry("pm:1", today, t0, 50, 2, "", 25, 1),
            FocusEntry("pm:2", "2023-11-13", t0 - 86400000, 40, 1, "", 25, 1),
            FocusEntry("pm:3", "2023-11-01", t0 - 13 * 86400000, 30, 3, "", 25, 1),
        )
        val (t, w) = Pomo.totals(l, today, now)
        assertEquals(50, t.m); assertEquals(2, t.b); assertEquals(90, w.m); assertEquals(3, w.b)
        val p = Pomo.pills(l, PomoRun(id = "1", sm = 30), today)
        assertEquals(listOf("Your best focus day", "2 days in a row"), p)
    }

    @Test fun revisionLogMergesByNewestEntry() {
        val a = JSONObject("{\"m\":{\"pm:1\":{\"pm\":1,\"m\":10,\"u\":5},\"r:x\":{\"u\":1}},\"savedAt\":9}")
        val b = JSONObject("{\"m\":{\"pm:1\":{\"pm\":1,\"m\":20,\"u\":8},\"pm:2\":{\"pm\":1,\"m\":3,\"u\":2}},\"savedAt\":4}")
        val m = Merge.mergeLog(a, b)
        assertEquals(20, m.getJSONObject("m").getJSONObject("pm:1").getInt("m"))
        assertEquals(3, m.getJSONObject("m").length())
        assertEquals(9L, m.getLong("savedAt"))
        assertEquals("rl", Merge.kind("zz_revlog"))
        val r = Merge.mergeRow("rl", a.toString(), b.toString())!!
        assertTrue(r.need && r.changed)
        val same = Merge.mergeRow("rl", b.toString(), b.toString())!!
        assertTrue(!same.need && !same.changed)
        assertNull(Merge.mergeRow("rl", null, "{\"x\":1}"))
        val fresh = Merge.mergeRow("rl", null, b.toString())!!
        assertTrue(!fresh.need)
    }
}
