package com.ascend.app

import com.ascend.app.domain.Dates
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.Merge
import com.ascend.app.domain.Planner
import com.ascend.app.domain.Ranges
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainTest {
    private fun item(id: String, u: Long, extra: String = "") = JSONObject("{\"id\":\"$id\",\"u\":$u$extra}")
    private fun arr(vararg o: JSONObject) = JSONArray().also { a -> o.forEach { a.put(it) } }

    // ----- merge -----
    @Test fun newerItemWins() {
        val a = arr(item("1", 5, ",\"t\":\"old\""))
        val b = arr(item("1", 9, ",\"t\":\"new\""))
        assertEquals("new", Merge.list(a, b).getJSONObject(0).getString("t"))
        assertEquals("old", Merge.list(b.let { a }, arr(item("1", 3, ",\"t\":\"older\""))).getJSONObject(0).getString("t"))
    }

    @Test fun mergeKeepsOrderAndAddsNew() {
        val m = Merge.list(arr(item("a", 1), item("b", 1)), arr(item("c", 1), item("a", 2)))
        assertEquals(listOf("a", "b", "c"), (0 until m.length()).map { m.getJSONObject(it).getString("id") })
        assertEquals(2, m.getJSONObject(0).getInt("u"))
    }

    @Test fun signatureIgnoresOrderAndCountsDeletions() {
        assertEquals(Merge.sig(arr(item("a", 1), item("b", 2))), Merge.sig(arr(item("b", 2), item("a", 1))))
        assertTrue(Merge.sig(arr(item("a", 1))) != Merge.sig(arr(item("a", 1, ",\"x\":1"))))
    }

    @Test fun rowKinds() {
        assertEquals("hw", Merge.kind("zz_hw"))
        assertEquals("hw", Merge.kind("zz_hw_2026-10"))
        assertEquals("sy", Merge.kind("zz_syllabus"))
        assertNull(Merge.kind("zz_profile"))
        assertNull(Merge.kind("abc123"))
    }

    @Test fun mergeRowFlagsWhatTheCloudLacks() {
        val local = JSONObject().put("subjects", JSONArray()).put("items", arr(item("a", 5), item("b", 5))).put("savedAt", 1).toString()
        val cloud = JSONObject().put("subjects", JSONArray()).put("items", arr(item("a", 5))).put("savedAt", 1).toString()
        val m = Merge.mergeRow("hw", local, cloud)!!
        assertTrue(m.need)       // local has item b that the cloud does not
        assertFalse(m.changed)   // nothing new came down
        val m2 = Merge.mergeRow("hw", cloud, local)!!
        assertTrue(m2.changed)
        assertFalse(m2.need)
    }

    @Test fun mergeRowWithNoLocalCopyTakesCloudAsIs() {
        val cloud = "{\"subjects\":[],\"items\":[{\"id\":\"a\",\"u\":1}],\"savedAt\":2}"
        val m = Merge.mergeRow("hw", null, cloud)!!
        assertEquals(cloud, m.json)
        assertFalse(m.need)
        assertNull(Merge.mergeRow("hw", null, "not json"))
        assertNull(Merge.mergeRow("hw", null, "{\"x\":1}"))
    }

    // ----- ranges -----
    @Test fun rangesCountAndNormalise() {
        assertEquals(30, Ranges.parse("1-30").n)
        assertEquals("1–20, 25–30", Ranges.parse("25-30, 1-20").norm)
        assertEquals(26, Ranges.parse("25-30, 1-20").n)
        assertEquals("1–10", Ranges.parse("1-5, 4-10").norm)
        assertEquals("5", Ranges.parse("5").norm)
        assertTrue(Ranges.parse("").ok)
        assertEquals(0, Ranges.parse("").n)
    }

    @Test fun badRangesAreRejected() {
        assertFalse(Ranges.parse("abc").ok)
        assertFalse(Ranges.parse("0-5").ok)
        assertFalse(Ranges.parse("9-3").ok)
        assertTrue(Ranges.parse("3 to 8").ok)
    }

    // ----- dates -----
    @Test fun dateHelpers() {
        assertEquals("2026-10-26", Dates.weekStart("2026-10-28")) // a Wednesday; Monday is the 26th
        assertEquals("2026-10-26", Dates.weekStart("2026-11-01")) // Sunday belongs to the week that began on the 26th
        assertEquals("2026-11-02", Dates.add("2026-10-26", 7))
        assertEquals(7, Dates.between("2026-10-26", "2026-11-02"))
        assertEquals("2026-10", Dates.shard("2026-10-26"))
        assertEquals("undated", Dates.shard(""))
        assertEquals("Monday", Dates.dowName("2026-10-26"))
        assertEquals("Sunday", Dates.dowName("2026-11-01"))
    }

    @Test fun durationAndClockText() {
        assertEquals("", Dates.hm(0))
        assertEquals("40m", Dates.hm(40))
        assertEquals("1h", Dates.hm(60))
        assertEquals("1h 35m", Dates.hm(95))
        assertEquals("2:05 PM", Dates.clock("14:05"))
        assertEquals("12:00 AM", Dates.clock("00:00"))
        assertEquals("12:30 PM", Dates.clock("12:30"))
        assertEquals("", Dates.clock(""))
    }

    // ----- planner -----
    private fun data(items: String, nodes: String = "[{\"id\":\"p\",\"k\":\"s\",\"n\":\"Physics\",\"o\":1,\"c\":3,\"u\":1},{\"id\":\"m\",\"k\":\"s\",\"n\":\"Maths\",\"o\":2,\"c\":0,\"u\":1}]"): DomainData {
        val hw = "{\"subjects\":[],\"items\":$items,\"savedAt\":1}"
        val sy = "{\"nodes\":$nodes,\"keys\":[],\"savedAt\":1}"
        return DomainData.from(mapOf("zz_hw_2026-10" to hw, "zz_syllabus" to sy))
    }

    @Test fun dayListOrder() {
        val d = data(
            "[{\"id\":\"a\",\"d\":\"2026-10-26\",\"t\":\"late\",\"o\":3,\"u\":1}," +
                "{\"id\":\"b\",\"d\":\"2026-10-26\",\"t\":\"early\",\"o\":9,\"u\":1,\"tm\":\"08:00\"}," +
                "{\"id\":\"c\",\"d\":\"2026-10-26\",\"t\":\"urgent\",\"o\":5,\"u\":1,\"pr\":1}," +
                "{\"id\":\"e\",\"d\":\"2026-10-26\",\"t\":\"first\",\"o\":1,\"u\":1}," +
                "{\"id\":\"z\",\"d\":\"2026-10-27\",\"t\":\"other day\",\"o\":1,\"u\":1}]",
        )
        assertEquals(listOf("urgent", "early", "first", "late"), Planner.day(d, "2026-10-26").map { it.title })
    }

    @Test fun deletedAndOrphanTasksAreHidden() {
        val d = data("[{\"id\":\"a\",\"d\":\"2026-10-26\",\"t\":\"gone\",\"x\":1,\"u\":1},{\"id\":\"b\",\"d\":\"2026-10-26\",\"t\":\"orphan\",\"s\":\"nope\",\"u\":1},{\"id\":\"c\",\"d\":\"2026-10-26\",\"t\":\"ok\",\"s\":\"p\",\"u\":1}]")
        assertEquals(listOf("ok"), Planner.day(d, "2026-10-26").map { it.title })
    }

    @Test fun overdueIsOldestFirstAndSkipsDone() {
        val d = data("[{\"id\":\"a\",\"d\":\"2026-10-24\",\"t\":\"A\",\"o\":2,\"u\":1},{\"id\":\"b\",\"d\":\"2026-10-22\",\"t\":\"B\",\"o\":1,\"u\":1},{\"id\":\"c\",\"d\":\"2026-10-23\",\"t\":\"C\",\"done\":true,\"u\":1},{\"id\":\"d\",\"d\":\"2026-10-26\",\"t\":\"D\",\"u\":1}]")
        assertEquals(listOf("B", "A"), Planner.overdue(d, "2026-10-26").map { it.title })
    }

    @Test fun minutesUseDurationThenQuestionCount() {
        val d = data("[{\"id\":\"a\",\"d\":\"2026-10-26\",\"t\":\"x\",\"du\":45,\"u\":1},{\"id\":\"b\",\"d\":\"2026-10-26\",\"t\":\"y\",\"rg\":\"1-10\",\"u\":1},{\"id\":\"c\",\"d\":\"2026-10-26\",\"t\":\"z\",\"u\":1}]")
        val s = Planner.stat(Planner.day(d, "2026-10-26"))
        assertEquals(3, s.n)
        assertEquals(45 + 30, s.minutes) // 10 questions x 3 min default
        assertEquals(10, s.questions)
    }

    @Test fun captionsMatchTheWebApp() {
        assertEquals("Plan anything", Planner.caption(com.ascend.app.domain.DayStat(0, 0, 0, 0), 0))
        assertEquals("2 overdue", Planner.caption(com.ascend.app.domain.DayStat(0, 0, 0, 0), 2))
        assertEquals("All done · 3", Planner.caption(com.ascend.app.domain.DayStat(3, 3, 0, 0), 1))
        assertEquals("1 of 3 done · 2 late", Planner.caption(com.ascend.app.domain.DayStat(3, 1, 0, 0), 2))
    }

    @Test fun titleFallsBackToSubjectAndRange() {
        val d = data("[{\"id\":\"a\",\"d\":\"2026-10-26\",\"t\":\"\",\"s\":\"p\",\"rg\":\"1-5\",\"u\":1}]")
        val r = Planner.day(d, "2026-10-26")[0]
        assertEquals("Physics · Q 1-5", r.title)
        assertEquals(DomainData.COLORS[3], r.color)
    }

    @Test fun profileReadsExamAndCapacity() {
        val prof = "{\"name\":\"Asha Rao\",\"u\":1,\"pe\":{\"exam\":\"2027-01-22\",\"en\":\"Target\",\"cap\":8,\"mpq\":4,\"u\":2}}"
        val d = DomainData.from(mapOf("zz_profile" to prof))
        assertEquals("Asha Rao", d.profile.name)
        assertEquals("2027-01-22", d.profile.exam)
        assertEquals("Target", d.profile.examName)
        assertEquals(8, d.profile.capHours)
        assertEquals(4, d.profile.minPerQ)
        assertNotNull(DomainData.from(mapOf("zz_profile" to "garbage")).profile)
    }

    @Test fun homeworkRowsFromSeveralMonthsAreMerged() {
        val a = "{\"subjects\":[],\"items\":[{\"id\":\"1\",\"d\":\"2026-10-26\",\"t\":\"old\",\"u\":1}],\"savedAt\":1}"
        val b = "{\"subjects\":[],\"items\":[{\"id\":\"1\",\"d\":\"2026-11-02\",\"t\":\"moved\",\"u\":5}],\"savedAt\":1}"
        val d = DomainData.from(mapOf("zz_hw_2026-10" to a, "zz_hw_2026-11" to b))
        assertEquals(1, d.items.size)
        assertEquals("moved", d.items[0].t)
    }

    // ----- plans -----
    private fun planItems() = "[" +
        "{\"id\":\"1\",\"d\":\"2026-10-20\",\"t\":\"a\",\"pl\":\"P1\",\"pn\":\"Mechanics\",\"done\":true,\"rg\":\"1-10\",\"o\":1,\"u\":1}," +
        "{\"id\":\"2\",\"d\":\"2026-10-22\",\"t\":\"b\",\"pl\":\"P1\",\"pn\":\"Mechanics\",\"rg\":\"1-10\",\"o\":2,\"u\":1}," +
        "{\"id\":\"3\",\"d\":\"2026-10-30\",\"t\":\"c\",\"pl\":\"P1\",\"pn\":\"Mechanics\",\"o\":3,\"u\":1}," +
        "{\"id\":\"4\",\"d\":\"2026-10-21\",\"t\":\"d\",\"pl\":\"P2\",\"pn\":\"Done plan\",\"done\":true,\"o\":1,\"u\":1}," +
        "{\"id\":\"5\",\"d\":\"2026-10-28\",\"t\":\"free\",\"du\":20,\"o\":1,\"u\":1}]"

    @Test fun planProgressAndStatus() {
        val p = Planner.plans(data(planItems()), "2026-10-26")
        assertEquals(listOf("P1", "P2"), p.map { it.id })       // unfinished plans come first
        val a = p[0]
        assertEquals("Mechanics", a.name)
        assertEquals("2026-10-20", a.first)
        assertEquals("2026-10-30", a.last)
        assertEquals(1, a.done)
        assertEquals(3, a.total)
        assertEquals(20, a.questions)
        assertEquals(10, a.questionsDone)
        assertEquals(1, a.overdue)
        assertEquals("late", a.status)
        assertEquals("fin", p[1].status)
        assertEquals("Behind", Planner.statusLabel(a.status))
    }

    @Test fun planIsAheadWhenMoreDoneThanDue() {
        val items = "[{\"id\":\"1\",\"d\":\"2026-10-26\",\"t\":\"a\",\"pl\":\"P\",\"done\":true,\"u\":1},{\"id\":\"2\",\"d\":\"2026-10-28\",\"t\":\"b\",\"pl\":\"P\",\"done\":true,\"u\":1},{\"id\":\"3\",\"d\":\"2026-10-30\",\"t\":\"c\",\"pl\":\"P\",\"u\":1}]"
        assertEquals("up", Planner.plans(data(items), "2026-10-26")[0].status)
        val ok = "[{\"id\":\"1\",\"d\":\"2026-10-26\",\"t\":\"a\",\"pl\":\"P\",\"done\":true,\"u\":1},{\"id\":\"3\",\"d\":\"2026-10-30\",\"t\":\"c\",\"pl\":\"P\",\"u\":1}]"
        assertEquals("ok", Planner.plans(data(ok), "2026-10-26")[0].status)
    }

    @Test fun spreadGivesEachTaskToTheLightestDay() {
        val d = data(planItems())
        val list = d.items.filter { it.pl == "P1" && !it.done }
        val m = Planner.spread(d, list, 3, "2026-10-26")
        assertEquals(2, m.size)
        assertTrue(m.values.all { it in listOf("2026-10-26", "2026-10-27", "2026-10-28") })
        // the 20-minute free task sits on the 28th, so the two plan tasks avoid that day
        assertEquals(setOf("2026-10-26", "2026-10-27"), m.values.toSet())
    }

    @Test fun monthGridStartsOnMondayAndHas42Days() {
        val g = Planner.monthGrid("2026-10-15")
        assertEquals(42, g.size)
        assertEquals("2026-09-28", g[0])      // 1 Oct 2026 is a Thursday; the grid begins on Monday 28 Sep
        assertTrue(g.contains("2026-10-31"))
    }
}

