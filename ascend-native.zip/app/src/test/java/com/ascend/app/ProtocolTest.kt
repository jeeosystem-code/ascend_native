package com.ascend.app

import com.ascend.app.sync.CloudRow
import com.ascend.app.sync.Protocol
import com.ascend.app.sync.Take
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolTest {
    private fun doc(id: String, data: String?, deleted: Boolean, upd: Long): JSONObject =
        JSONObject().put("name", "projects/p/databases/(default)/documents/users/u1/sessions/$id").put(
            "fields",
            JSONObject()
                .put("data", JSONObject().put("stringValue", data ?: ""))
                .put("deleted", JSONObject().put("booleanValue", deleted))
                .put("updated_at", JSONObject().put("integerValue", upd.toString())),
        )

    @Test fun parseRowReadsAllFields() {
        val r = Protocol.parseRow(doc("abc", "{\"x\":1}", false, 1700000000123))
        assertEquals("abc", r.id)
        assertEquals("{\"x\":1}", r.data)
        assertEquals(false, r.deleted)
        assertEquals(1700000000123, r.updatedAt)
    }

    @Test fun emptyDataBecomesNull() {
        assertNull(Protocol.parseRow(doc("t", "", true, 5)).data)
        assertEquals(true, Protocol.parseRow(doc("t", "", true, 5)).deleted)
    }

    @Test fun writeJsonMatchesWebAppShape() {
        val w = Protocol.writeJson("u1", "zz_profile", "{\"a\":2}", false, 99)
        val u = w.getJSONObject("update")
        assertEquals("projects/${Protocol.FB_PID}/databases/(default)/documents/users/u1/sessions/zz_profile", u.getString("name"))
        val f = u.getJSONObject("fields")
        assertEquals("{\"a\":2}", f.getJSONObject("data").getString("stringValue"))
        assertEquals(false, f.getJSONObject("deleted").getBoolean("booleanValue"))
        assertEquals("99", f.getJSONObject("updated_at").getString("integerValue"))
    }

    @Test fun tombstoneWriteHasEmptyData() {
        val f = Protocol.writeJson("u1", "x", null, true, 7).getJSONObject("update").getJSONObject("fields")
        assertEquals("", f.getJSONObject("data").getString("stringValue"))
        assertEquals(true, f.getJSONObject("deleted").getBoolean("booleanValue"))
    }

    @Test fun queryBodyFirstPageAndNextPage() {
        val first = JSONObject(Protocol.queryBody(10, null, null)).getJSONObject("structuredQuery")
        assertEquals(500, first.getInt("limit"))
        assertEquals("sessions", first.getJSONArray("from").getJSONObject(0).getString("collectionId"))
        assertEquals("10", first.getJSONObject("where").getJSONObject("fieldFilter").getJSONObject("value").getString("integerValue"))
        assertTrue(!first.has("startAt"))
        val next = JSONObject(Protocol.queryBody(10, 55, "projects/p/x/y")).getJSONObject("structuredQuery")
        val v = next.getJSONObject("startAt").getJSONArray("values")
        assertEquals("55", v.getJSONObject(0).getString("integerValue"))
        assertEquals("projects/p/x/y", v.getJSONObject(1).getString("referenceValue"))
        assertEquals(false, next.getJSONObject("startAt").getBoolean("before"))
    }

    @Test fun parseRowsSkipsEntriesWithoutDocument() {
        val a = JSONArray().put(JSONObject().put("readTime", "x")).put(JSONObject().put("document", doc("k", "{}", false, 3)))
        val rows = Protocol.parseRows(a.toString())
        assertEquals(1, rows.size)
        assertEquals("k", rows[0].id)
        assertTrue(Protocol.parseRows(null).isEmpty())
        assertTrue(Protocol.parseRows("[]").isEmpty())
    }

    @Test fun newestChangeWins() {
        val live = CloudRow("a", "n", "{}", false, 100)
        assertEquals(Take.PUT, Protocol.take(null, live))
        assertEquals(Take.PUT, Protocol.take(99, live))
        assertEquals(Take.SKIP, Protocol.take(100, live))
        assertEquals(Take.SKIP, Protocol.take(101, live))
    }

    @Test fun deletionsOnlyRemoveOlderOrEqualCopies() {
        val gone = CloudRow("a", "n", null, true, 100)
        assertEquals(Take.SKIP, Protocol.take(null, gone))
        assertEquals(Take.DELETE, Protocol.take(100, gone))
        assertEquals(Take.DELETE, Protocol.take(50, gone))
        assertEquals(Take.SKIP, Protocol.take(101, gone))
    }

    @Test fun rowWithoutDataIsIgnored() {
        assertEquals(Take.SKIP, Protocol.take(null, CloudRow("a", "n", null, false, 1)))
    }

    @Test fun errorTextsAreFriendly() {
        assertEquals("Wrong email or password.", Protocol.fbMsg("INVALID_LOGIN_CREDENTIALS", 400))
        assertEquals("That email already has an account. Sign in instead.", Protocol.fbMsg("EMAIL_EXISTS", 400))
        assertEquals("Use a password of at least 6 characters.", Protocol.fbMsg("WEAK_PASSWORD : Password should be at least 6 characters", 400))
        assertEquals("Firestore refused access. Check the security rules.", Protocol.fbMsg("Missing or insufficient permissions.", 403))
        assertEquals("Error 500", Protocol.fbMsg("", 500))
    }

    @Test fun errorBodyIsRead() {
        assertEquals("EMAIL_NOT_FOUND", Protocol.errorRaw("{\"error\":{\"code\":400,\"message\":\"EMAIL_NOT_FOUND\"}}"))
        assertEquals("", Protocol.errorRaw("not json"))
    }

    @Test fun deadRefreshTokensAreRecognised() {
        assertTrue(Protocol.isRefreshDead(400, "TOKEN_EXPIRED"))
        assertTrue(!Protocol.isRefreshDead(500, "TOKEN_EXPIRED"))
        assertTrue(!Protocol.isRefreshDead(400, "QUOTA"))
    }

    @Test fun writesAreSentInBatchesOf100() {
        val c = Protocol.chunks((1..250).toList())
        assertEquals(listOf(100, 100, 50), c.map { it.size })
    }

    @Test fun onlyNonSpecialIdsAreSessions() {
        assertTrue(Protocol.isSessionId("s_17000"))
        assertTrue(!Protocol.isSessionId("zz_profile"))
    }
}
