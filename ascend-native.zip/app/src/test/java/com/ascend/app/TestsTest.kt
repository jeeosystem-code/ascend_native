package com.ascend.app

import com.ascend.app.domain.Merge
import com.ascend.app.domain.Sec
import com.ascend.app.domain.Tl
import com.ascend.app.domain.TestRec
import com.ascend.app.domain.Folder
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TestsTest {
    private fun t(json: String) = TestRec(JSONObject(json))
    private val pattern = """"subs":["P","C"],"secs":[{"name":"A","count":2,"pos":4,"neg":1},{"name":"B","count":1,"pos":4,"neg":0}]"""

    @Test fun mergesFolderDocumentsByNewestChange() {
        val a = """{"folders":[{"id":"f1","k":"m","n":"Old","u":1}],"tests":[{"id":"t1","f":"f1","n":"A","u":5}],"savedAt":1}"""
        val b = """{"folders":[{"id":"f1","k":"m","n":"New","u":9},{"id":"f2","k":"s","n":"Phy","u":2}],"tests":[{"id":"t1","f":"f1","n":"B","u":3},{"id":"t2","f":"f2","n":"C","u":1}],"savedAt":2}"""
        val (f, ts) = Tl.fold(listOf(a, null, "junk", b, """{"folders":1}"""))
        assertEquals(listOf("New", "Phy"), f.map { it.getString("n") })
        assertEquals(listOf("A", "C"), ts.map { it.getString("n") })
        assertEquals("tl", Merge.kind("zz_tests")); assertEquals("tl", Merge.kind("zz_tests_f1")); assertNull(Merge.kind("zz_testsX"))
        val r = Merge.mergeRow("tl", a, b)!!
        assertTrue(r.need && r.changed)
        assertNull(Merge.mergeRow("tl", a, """{"folders":[]}"""))
        val same = Merge.mergeRow("tl", b, b)!!
        assertTrue(!same.need && !same.changed)
    }

    @Test fun numbersAndOrder() {
        val all = listOf(
            t("""{"id":"a","f":"f","n":"x","o":1,"d":"2026-01-01","no":"3"}"""),
            t("""{"id":"b","f":"f","n":"y","o":2,"d":"2026-01-02"}"""),
            t("""{"id":"c","f":"f","n":"z","o":3,"d":"2026-01-03"}"""),
            t("""{"id":"d","f":"f","n":"gone","o":4,"d":"2026-01-04","x":1}"""),
            t("""{"id":"e","f":"g","n":"other","o":0,"d":"2026-01-01"}"""),
        )
        assertEquals(1, Tl.autoNo(all, all[0])); assertEquals(2, Tl.autoNo(all, all[1])); assertEquals(3, Tl.autoNo(all, all[2]))
        assertEquals(3, Tl.num(all, all[0])); assertEquals(2, Tl.num(all, all[1]))
        assertEquals(listOf("c", "a", "b"), Tl.list(all, "f").map { it.id })      // 3, 3, 2 ; tie on number -> newer date first
        assertEquals(4, Tl.nextNo(all, "f")); assertEquals(2, Tl.nextNo(all, "g")); assertEquals(1, Tl.nextNo(all, "none"))
    }

    @Test fun questionsAndMarks() {
        val x = t("""{"id":"a","f":"f","n":"x",$pattern,"m":{"0.1":1,"0.2":3,"1.3":12,"1.1":4}}""")
        assertEquals(6, Tl.qs(x).size)
        assertEquals(listOf(1, 2, 3, 1, 2, 3), Tl.qs(x).map { it.no }); assertEquals(listOf(0, 0, 1, 0, 0, 1), Tl.qs(x).map { it.sec })
        val c = Tl.cnt(x)
        assertEquals(6, c.n); assertEquals(2, c.a); assertEquals(1, c.r); assertEquals(2, c.i); assertEquals(1, c.d)
        val p1 = Tl.cnt(x, 1)
        assertEquals(3, p1.n); assertEquals(0, p1.a); assertEquals(0, p1.r); assertEquals(2, p1.i); assertEquals(1, p1.d)
        assertEquals(24.0, Tl.max(x), 0.0)
        val up = t("""{"id":"u","f":"f","n":"up","subs":[],"secs":null,"d":"2030-01-01"}""")
        assertTrue(up.upcoming); assertTrue(Tl.qs(up).isEmpty()); assertEquals(0, Tl.cnt(up).n); assertEquals(0.0, Tl.max(up), 0.0)
        assertTrue(!x.upcoming); assertTrue(t("""{"id":"u"}""").upcoming)
    }

    @Test fun markBitsToggle() {
        val m = JSONObject()
        Tl.toggle(m, "0.1", 1); Tl.toggle(m, "0.1", 4)
        assertEquals(5, m.getInt("0.1"))
        Tl.toggle(m, "0.1", 1); assertEquals(4, m.getInt("0.1"))
        Tl.toggle(m, "0.1", 4); assertTrue(!m.has("0.1"))
    }

    @Test fun statusDaysAndDates() {
        assertEquals(0, Tl.st(t("""{"an":0}"""))); assertEquals(2, Tl.st(t("""{"an":2}"""))); assertEquals(0, Tl.st(t("""{"an":5}""")))
        assertEquals(3, Tl.days("2026-10-31", "2026-10-28")); assertEquals(-1, Tl.days("2026-10-27", "2026-10-28")); assertEquals(0, Tl.days("bad", "2026-10-28"))
        assertEquals("5 Mar", Tl.dl("2026-03-05", 2026)); assertEquals("5 Mar 2025", Tl.dl("2025-03-05", 2026)); assertEquals("", Tl.dl("", 2026))
    }

    @Test fun resultMathMatchesTheWebApp() {
        assertEquals(0, Tl.rsMin(100.0)); assertEquals(1, Tl.rsMin(1000.0)); assertEquals(4, Tl.rsMin(250000.0)); assertEquals(0, Tl.rsMin(50.0)); assertEquals(3, Tl.rsMin(1e5))
        assertEquals(5.0, Tl.rank(99.5, 1000.0, 1), 0.0); assertEquals(5.0, Tl.rank(87.5, 40.0, 1), 0.0)
        assertEquals(4.0, Tl.rank(99.97, 12345.0, 2), 0.0); assertEquals(10.0, Tl.rank(0.0, 10.0, 0), 0.0)
        assertEquals(1000.0, Tl.total(99.5, 5.0, 1)!!, 0.0); assertEquals(100.0, Tl.total(90.0, 10.0, 0)!!, 0.0)
        assertEquals(20000.0, Tl.total(97.85, 430.0, 2)!!, 0.0); assertNull(Tl.total(100.0, 3.0, 1))
        assertEquals("1,000", Tl.inr(1000)); assertEquals("12,34,567", Tl.inr(1234567)); assertEquals("999", Tl.inr(999)); assertEquals("12,345", Tl.inr(12345))
    }

    @Test fun resultFormFillsTheThirdField() {
        var s = Tl.RsState("", "5", "1000", "")
        s = Tl.rsSync(s, "ts")
        assertEquals("99.50", s.pc); assertEquals("pc", s.auto)
        s = Tl.rsSync(Tl.RsState("99.5", "", "1000", ""), "pc")
        assertEquals("5", s.rk); assertEquals("rk", s.auto)
        s = Tl.rsSync(Tl.RsState("99.5", "5", "", ""), "rk")
        assertEquals("1000", s.ts); assertEquals("ts", s.auto)
        // clearing one of the typed fields removes the auto-filled one
        val cleared = Tl.rsSync(Tl.RsState("99.50", "", "1000", "pc"), "rk")
        assertEquals("", cleared.pc); assertEquals("", cleared.auto)
        // editing the auto field turns it into a typed one
        val edited = Tl.rsSync(Tl.RsState("99.7", "5", "1000", "pc"), "pc")
        assertEquals("", edited.auto); assertEquals("99.7", edited.pc)
        assertEquals("", Tl.rsSync(Tl.RsState("", "", "", ""), "pc").auto)
    }

    @Test fun resultChecks() {
        assertEquals("Enter numbers only", Tl.rsCheck("", "abc", "", "", "", "").first)
        assertEquals("Full marks must be more than 0", Tl.rsCheck("0", "", "", "", "", "").first)
        assertEquals("Score can't be above full marks", Tl.rsCheck("100", "101", "", "", "", "").first)
        assertEquals("Total students must be a whole number", Tl.rsCheck("", "", "", "", "10.5", "").first)
        assertEquals("Rank must be a whole number", Tl.rsCheck("", "", "", "0", "", "").first)
        assertEquals("Rank can't be above total students", Tl.rsCheck("", "", "", "11", "10", "").first)
        assertEquals("Percentile is between 0 and 100", Tl.rsCheck("", "", "101", "", "", "").first)
        assertEquals("For 1,000 students enter percentile with at least 1 decimal", Tl.rsCheck("", "", "99", "", "1000", "").first)
        assertNull(Tl.rsCheck("", "", "99", "", "1000", "pc").first)
        val ok = Tl.rsCheck("300", "180,5", "", "", "", "")
        assertNull(ok.first); assertEquals(180.5, ok.second!!.sc!!, 0.0); assertEquals(300.0, ok.second!!.fm!!, 0.0); assertNull(ok.second!!.rk)
        assertTrue(!Tl.rsCheck("", "", "", "", "", "").second!!.any)
        assertEquals(Tl.parseNum("1e3"), 1000.0); assertTrue(Tl.parseNum("5d")!!.isNaN()); assertNull(Tl.parseNum(" "))
    }

    @Test fun resultRoundTrip() {
        val r = com.ascend.app.domain.Rs(300.0, 180.5, null, 99.5, 5.0)
        val back = com.ascend.app.domain.Rs.from(r.toJson())
        assertEquals(r, back)
        assertEquals(r, t("""{"id":"a","rs":${r.toJson()}}""").rs)
        assertNull(t("""{"id":"a"}""").rs)
    }
}
