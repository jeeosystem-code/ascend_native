package com.ascend.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** One saved document. Every kind of app data (plans, tests, homework ...) is kept as a JSON document under its own key. */
@Entity(tableName = "docs")
data class Doc(@PrimaryKey val key: String, val json: String, val updatedAt: Long)

@Dao
interface DocDao {
    @Query("SELECT * FROM docs WHERE `key` = :key")
    suspend fun get(key: String): Doc?

    @Query("SELECT * FROM docs WHERE `key` = :key")
    fun watch(key: String): Flow<Doc?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(doc: Doc)

    @Query("DELETE FROM docs WHERE `key` = :key")
    suspend fun delete(key: String)

    @Query("SELECT * FROM docs")
    suspend fun all(): List<Doc>
}

@Database(entities = [Doc::class, Row::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun docs(): DocDao
    abstract fun rows(): RowDao
}

class Store(private val dao: DocDao) {
    suspend fun get(key: String): String? = dao.get(key)?.json
    fun watch(key: String): Flow<String?> = dao.watch(key).map { it?.json }
    suspend fun put(key: String, json: String, now: Long = System.currentTimeMillis()) = dao.put(Doc(key, json, now))
    suspend fun delete(key: String) = dao.delete(key)
    suspend fun all(): List<Doc> = dao.all()
    suspend fun removeKeys(pred: (String) -> Boolean) { dao.all().filter { pred(it.key) }.forEach { dao.delete(it.key) } }
}

object Keys {
    const val THEME = "theme"        // "system" | "light" | "dark"
    const val SELF_TEST = "selftest"
    const val SESSION = "sbsess"
    const val OWNER = "owner"
    fun cursor(uid: String) = "sbpull:$uid"
}
