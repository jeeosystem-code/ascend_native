package com.ascend.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** One question of an attempt, the same array the web app stores: [sub, no, sec, state, bits, marks, seconds, pos, neg]. */
data class AQ(val sub: Int, val no: Int, val sec: Int, val st: Int, val bits: Int, val m: Double, val t: Int, val pos: Double, val neg: Double) {
    val key get() = "$sub.$no"
    /** "c" right, "p" partly right, "w" wrong, "s" skipped, "u" not reached. */
    val state: String get() = if (st == 1) (if (bits and 1 != 0) "w" else if (bits and 8 != 0) "p" else "c") else if (st == 2) "s" else "u"
    val lost: Double get() = when (state) { "w" -> pos + neg; "s", "u" -> pos; "p" -> pos - m; else -> 0.0 }
    val good get() = state == "c" || state == "p"

    fun toJson(): JSONArray = JSONArray().put(sub).put(no).put(sec).put(st).put(bits).put(m).put(t).put(pos).put(neg)

    companion object {
        fun from(a: JSONArray?): AQ? {
            if (a == null || a.length() < 9) return null
            return AQ(a.optInt(0), a.optInt(1), a.optInt(2), a.optInt(3), a.optInt(4), a.optDouble(5, 0.0), a.optInt(6), a.optDouble(7, 0.0), a.optDouble(8, 0.0))
        }
    }
}

data class AtStat(val n: Int, val c: Int, val w: Int, val p: Int, val s: Int, val u: Int, val att: Int, val t: Int, val fa: Int, val fc: Int, val sa: Int, val sc2: Int, val lost: Double, val acc: Int, val pct: Int)

/** One saved attempt of a test (k = "a"). Wraps the JSON so fields written by the web app survive. */
class Attempt(val j: JSONObject) {
    val id: String get() = j.optString("id")
    val tid: String get() = j.optString("tid")
    val mode: String get() = j.optString("mode", "e")
    val o: Long get() = j.optLong("o", 0)
    val dur: Long get() = j.optLong("dur", 0)
    val used: Int get() = j.optInt("used", 0)
    val nm: String get() = j.optString("nm")
    val sc: Double get() = j.optDouble("sc", 0.0)
    val mx: Double get() = j.optDouble("mx", 0.0)
    val subs: List<String> get() = strs(j.optJSONArray("subs"))
    val secs: List<String> get() = strs(j.optJSONArray("secs"))
    val q: List<AQ> get() = (0 until (j.optJSONArray("q")?.length() ?: 0)).mapNotNull { AQ.from(j.optJSONArray("q")!!.optJSONArray(it)) }
    fun rm(key: String): Int = j.optJSONObject("rm")?.optInt(key, 0) ?: 0
    fun nt(key: String): String = j.optJSONObject("nt")?.optString(key, "") ?: ""
    private fun strs(a: JSONArray?) = (0 until (a?.length() ?: 0)).map { a!!.optString(it) }
}

object At {
    val RM = listOf(1 to "Silly", 2 to "Language", 4 to "Time", 8 to "Approach", 16 to "Situation")
    const val MAX = 700000
    private const val P = "zz_att_"

    fun isAt(id: String) = id.startsWith(P)
    fun docId(tid: String, n: Int) = "${P}${tid}_$n"
    fun tidOf(id: String): String = id.removePrefix(P).replace(Regex("_\\d+$"), "")

    /** Question results from a finished or running session. */
    class Calc(val sc: Double, val mx: Double, val q: List<AQ>)

    fun fromSession(cfg: Cfg, res: List<Res?>): Calc {
        val qs = cfg.q
        var sc = 0.0; var mx = 0.0
        val out = ArrayList<AQ>()
        for (i in qs.indices) {
            val q = qs[i]; val r = res.getOrNull(i)
            val st = if (r?.st == "A") 1 else if (r?.st == "N") 2 else 0
            var bits = 0; var m = 0.0
            if (st == 1 && r != null) {
                if (r.w) { bits = bits or 1; m = -q.neg } else if (r.p > 0) { bits = bits or 8; m = r.p.toDouble() } else m = q.pos
            }
            if (r != null && r.d) bits = bits or 2
            if (r != null && r.f == 1) bits = bits or 4
            sc += m; mx += q.pos
            out.add(AQ(q.sub, q.no, q.sec, st, bits, m, Math.round((r?.t ?: 0L) / 1000.0).toInt(), q.pos, q.neg))
        }
        return Calc(sc, mx, out)
    }

    /** The record for a running or finished test session. Reasons and notes of an earlier save of the same attempt are kept. */
    fun record(cfg: Cfg, res: List<Res?>, usedMs: Long, old: JSONObject?, now: Long): JSONObject {
        val c = fromSession(cfg, res)
        val q = JSONArray(); c.q.forEach { q.put(it.toJson()) }
        val sa = JSONArray(); cfg.subs.forEach { sa.put(it) }
        val ca = JSONArray(); cfg.secs.forEach { ca.put(it.name) }
        val o = JSONObject(old?.toString() ?: "{}")
        o.put("id", cfg.id).put("k", "a").put("tid", cfg.tid).put("mode", cfg.tm).put("o", if (cfg.date > 0) cfg.date else now)
            .put("dur", cfg.dur).put("used", Math.round(usedMs / 1000.0).toInt()).put("nm", cfg.name).put("subs", sa).put("secs", ca)
            .put("base", cfg.baseId).put("sc", c.sc).put("mx", c.mx).put("q", q).put("u", now)
        if (!o.has("rm")) o.put("rm", JSONObject())
        return o
    }

    fun list(recs: List<JSONObject>, tid: String): List<Attempt> =
        recs.filter { it.optString("tid") == tid && it.optString("k") == "a" && !Merge.isX(it) }.map { Attempt(it) }.sortedBy { it.o }

    fun get(recs: List<JSONObject>, id: String): Attempt? = recs.firstOrNull { it.optString("id") == id && it.optString("k") == "a" && !Merge.isX(it) }?.let { Attempt(it) }

    /** Number of a full attempt (reviews of wrong questions are not counted), 1-based; 0 for a review. */
    fun no(recs: List<JSONObject>, a: Attempt): Int = list(recs, a.tid).filter { it.mode != "r" }.indexOfFirst { it.id == a.id } + 1

    fun stat(a: Attempt): AtStat {
        var c = 0; var w = 0; var p = 0; var s = 0; var u = 0; var att = 0; var t = 0; var fa = 0; var fc = 0; var sa = 0; var sc2 = 0; var lost = 0.0
        val q = a.q
        for (e in q) {
            when (e.state) { "c" -> c++; "w" -> w++; "p" -> p++; "s" -> s++; else -> u++ }
            t += e.t
            if (e.st == 1) {
                att++
                if (e.bits and 4 != 0) { fa++; if (e.good) fc++ } else { sa++; if (e.good) sc2++ }
            }
            lost += e.lost
        }
        val acc = if (att > 0) Math.round((c + p) * 100.0 / att).toInt() else 0
        val pct = if (a.mx != 0.0) Math.round(a.sc * 100.0 / a.mx).toInt() else 0
        return AtStat(q.size, c, w, p, s, u, att, t, fa, fc, sa, sc2, lost, acc, pct)
    }

    /** Marks lost per reason; losses with no reason are under key 0. A loss with several reasons is shared equally. */
    fun lostBy(a: Attempt): Map<Int, Double> {
        val out = LinkedHashMap<Int, Double>()
        out[0] = 0.0; RM.forEach { out[it.first] = 0.0 }
        for (e in a.q) {
            val l = e.lost
            if (l <= 0) continue
            val b = a.rm(e.key)
            if (b == 0) out[0] = out[0]!! + l
            else {
                val cnt = RM.count { b and it.first != 0 }
                RM.forEach { if (b and it.first != 0) out[it.first] = out[it.first]!! + l / cnt }
            }
        }
        return out
    }

    /** Latest result of every question of a test across its full and review attempts (a later attempt overrides). */
    fun latest(recs: List<JSONObject>, tid: String): Map<String, AQ> {
        val m = LinkedHashMap<String, AQ>()
        list(recs, tid).forEach { a -> a.q.forEach { m[it.key] = it } }
        return m
    }

    fun openKeys(recs: List<JSONObject>, tid: String): Set<String> = latest(recs, tid).filter { it.value.state in setOf("w", "s", "u") }.keys

    /** Splits the records of one test into cloud documents below the size limit. Paper records come first. */
    fun chunks(recs: List<JSONObject>): List<List<JSONObject>> {
        val l = recs.sortedWith { a, b ->
            val ka = a.optString("k"); val kb = b.optString("k")
            if (ka == kb) a.optLong("o", 0).compareTo(b.optLong("o", 0)) else if (ka == "p") -1 else 1
        }
        val out = ArrayList<ArrayList<JSONObject>>(); out.add(ArrayList())
        var sz = 0
        for (r in l) {
            val s = r.toString().length
            if (sz + s > MAX && out.last().isNotEmpty()) { out.add(ArrayList()); sz = 0 }
            out.last().add(r); sz += s
        }
        return out
    }
    // ---------- chapters (paper record, k = "p") ----------

    fun paper(recs: List<JSONObject>, tid: String): JSONObject? =
        recs.firstOrNull { it.optString("k") == "p" && it.optString("tid") == tid && !Merge.isX(it) }

    /** Chapter node id of question [key] ("sub.no") of a test, or "". */
    fun chapterOf(recs: List<JSONObject>, tid: String, key: String): String = paper(recs, tid)?.optJSONObject("c")?.optString(key, "") ?: ""

    /** Marks questions [nums] of subject [sub] with [chapter] (empty = remove the tag). Returns the new or changed paper record. */
    fun tag(recs: MutableList<JSONObject>, tid: String, sub: Int, nums: Collection<Int>, chapter: String, now: Long) {
        val p: JSONObject = recs.firstOrNull { it.optString("k") == "p" && it.optString("tid") == tid }
            ?: JSONObject().put("id", "p$tid").put("k", "p").put("tid", tid).put("o", 0).put("c", JSONObject()).put("u", 0).also { recs.add(it) }
        if (Merge.isX(p)) p.remove("x")
        val c = p.optJSONObject("c") ?: JSONObject().also { p.put("c", it) }
        nums.forEach { n -> if (chapter.isEmpty()) c.remove("$sub.$n") else c.put("$sub.$n", chapter) }
        p.put("u", now)
    }

    class ChRow(val id: String, var n: Int = 0, var c: Int = 0, var w: Int = 0, var s: Int = 0, var u: Int = 0, var t: Int = 0, var lost: Double = 0.0, val rm: MutableMap<Int, Int> = LinkedHashMap(), val tests: MutableSet<String> = LinkedHashSet()) {
        val att get() = c + w
        val acc get() = if (att > 0) Math.round(c * 100.0 / att).toInt() else 0
    }

    private fun addTo(o: ChRow, e: AQ, rm: Int) {
        o.n++; o.t += e.t; o.lost += e.lost
        when (e.state) { "c", "p" -> o.c++; "w" -> o.w++; "s" -> o.s++; else -> o.u++ }
        RM.forEach { if (rm and it.first != 0) o.rm[it.first] = (o.rm[it.first] ?: 0) + 1 }
    }

    /** Per chapter results of one attempt; questions with no valid chapter are counted in [Pair.second]. Weakest first. */
    fun chaptersOf(recs: List<JSONObject>, a: Attempt, valid: (String) -> Boolean): Pair<List<ChRow>, Int> {
        val g = LinkedHashMap<String, ChRow>(); var un = 0
        a.q.forEach { e ->
            val c = chapterOf(recs, a.tid, e.key)
            if (c.isEmpty() || !valid(c)) { un++; return@forEach }
            addTo(g.getOrPut(c) { ChRow(c) }, e, a.rm(e.key))
        }
        return weakFirst(g.values.toList()) to un
    }

    /** Weakest first. [report] = the chapter report order (no attempted question goes last, accuracy is rounded). */
    fun weakFirst(l: List<ChRow>, report: Boolean = false): List<ChRow> = l.sortedWith { x, y ->
        val d = if (report) (if (x.att > 0) x.acc else 101).compareTo(if (y.att > 0) y.acc else 101)
        else (if (x.att > 0) x.c.toDouble() / x.att else 0.0).compareTo(if (y.att > 0) y.c.toDouble() / y.att else 0.0)
        if (d != 0) d else y.lost.compareTo(x.lost)
    }

    /** One question's latest result in the mistake notebook. */
    class Nb(val t: TestRec, val key: String, val e: AQ, val a: Attempt)

    fun allLatest(recs: List<JSONObject>, tests: List<TestRec>, folderOk: (String) -> Boolean): List<Nb> {
        val out = ArrayList<Nb>()
        tests.forEach { t ->
            if (t.x || !folderOk(t.f) || t.upcoming) return@forEach
            val att = list(recs, t.id)
            val m = LinkedHashMap<String, Pair<AQ, Attempt>>()
            att.forEach { a -> a.q.forEach { m[it.key] = it to a } }
            m.forEach { (k, v) -> out.add(Nb(t, k, v.first, v.second)) }
        }
        return out
    }

    /** Chapter report over every test: latest result of each tagged question. Weakest chapters first. */
    fun chapterReport(recs: List<JSONObject>, tests: List<TestRec>, folderOk: (String) -> Boolean, valid: (String) -> Boolean): List<ChRow> {
        val g = LinkedHashMap<String, ChRow>()
        allLatest(recs, tests, folderOk).forEach { r ->
            val c = chapterOf(recs, r.t.id, r.key)
            if (c.isEmpty() || !valid(c)) return@forEach
            val o = g.getOrPut(c) { ChRow(c) }
            addTo(o, r.e, r.a.rm(r.key)); o.tests.add(r.t.n)
        }
        return weakFirst(g.values.toList(), true)
    }

    /** Plain text report of an attempt, for sharing. */
    fun reportText(a: Attempt, testName: String, date: String, chapterName: (String) -> String?, recs: List<JSONObject>): String {
        val s = stat(a)
        val sb = StringBuilder()
        sb.append(testName).append(" · ").append(date).append('\n')
        sb.append("Score ").append(Sess.num(a.sc)).append(" / ").append(Sess.num(a.mx)).append(" (").append(s.pct).append("%)\n")
        sb.append("Right ").append(s.c + s.p).append(" · Wrong ").append(s.w).append(" · Skipped ").append(s.s).append(" · Not reached ").append(s.u).append(" · Accuracy ").append(s.acc).append("%\n")
        if (a.used > 0) sb.append("Time ").append(a.used / 60).append(" min\n")
        val lb = lostBy(a); val tot = lb.values.sum()
        if (tot > 0) {
            sb.append("\nMarks lost ").append(Sess.num(Math.round(tot * 100) / 100.0)).append('\n')
            RM.forEach { (k, n) -> val v = lb[k] ?: 0.0; if (v > 0) sb.append("  ").append(n).append(": ").append(Sess.num(Math.round(v * 100) / 100.0)).append('\n') }
            val u = lb[0] ?: 0.0
            if (u > 0) sb.append("  Not tagged: ").append(Sess.num(Math.round(u * 100) / 100.0)).append('\n')
        }
        val (rows, _) = chaptersOf(recs, a) { chapterName(it) != null }
        if (rows.isNotEmpty()) {
            sb.append("\nChapters (weakest first)\n")
            rows.forEach { sb.append("  ").append(chapterName(it.id)).append(": ").append(if (it.att > 0) "${it.acc}%" else "–").append(" · ${it.c} right, ${it.w} wrong, ${it.s} skipped\n") }
        }
        return sb.toString().trimEnd()
    }
}
