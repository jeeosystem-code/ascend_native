package com.ascend.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** A test folder: "m" = mock tests (several subjects), "s" = tests of one subject. */
class Folder(val j: JSONObject) {
    val id: String get() = j.optString("id")
    val k: String get() = j.optString("k", "m")
    val n: String get() = j.optString("n")
    val sb: String get() = j.optString("sb")
    val o: Long get() = j.optLong("o", 0)
    val u: Long get() = j.optLong("u", 0)
    val x: Boolean get() = Merge.isX(j)
}

/** A saved test. [secs] is null for an upcoming test whose pattern is not known yet. */
class TestRec(val j: JSONObject) {
    val id: String get() = j.optString("id")
    val f: String get() = j.optString("f")
    val n: String get() = j.optString("n")
    val no: String get() = j.optString("no")
    val d: String get() = j.optString("d")
    val dur: Int get() = j.optInt("dur", 0)
    val o: Long get() = j.optLong("o", 0)
    val u: Long get() = j.optLong("u", 0)
    val an: Int get() = j.optInt("an", 0)
    val x: Boolean get() = Merge.isX(j)
    val subs: List<String> get() = (0 until (j.optJSONArray("subs")?.length() ?: 0)).map { j.optJSONArray("subs")!!.optString(it) }
    val secs: List<Sec>?
        get() {
            val a = j.optJSONArray("secs") ?: return null
            return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
                .map { Sec(it.optString("name"), it.optInt("count", 1), it.optDouble("pos", 0.0), it.optDouble("neg", 0.0), it.optBoolean("partial", false)) }
        }
    val upcoming get() = !j.has("secs") || j.isNull("secs")
    fun mark(key: String): Int = j.optJSONObject("m")?.optInt(key, 0) ?: 0
    val rs: Rs? get() = j.optJSONObject("rs")?.let { Rs.from(it) }
}

/** Result numbers of a test: full marks, score, total students, percentile, rank. Any of them may be missing. */
data class Rs(val fm: Double? = null, val sc: Double? = null, val ts: Double? = null, val pc: Double? = null, val rk: Double? = null) {
    val any get() = sc != null || pc != null || ts != null || fm != null || rk != null
    fun toJson(): JSONObject {
        val o = JSONObject()
        listOf("fm" to fm, "sc" to sc, "ts" to ts, "pc" to pc, "rk" to rk).forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) }
        return o
    }

    companion object {
        private fun d(j: JSONObject, k: String): Double? = if (j.has(k) && !j.isNull(k)) j.optDouble(k) else null
        fun from(j: JSONObject) = Rs(d(j, "fm"), d(j, "sc"), d(j, "ts"), d(j, "pc"), d(j, "rk"))
    }
}

/** One question slot of a test paper: number within its subject, subject index, section index. */
data class TQ(val no: Int, val sub: Int, val sec: Int)

object Tl {
    val STATUS = listOf("Pending", "In process", "Analysed")

    /** Reads every test document (the old single one and the per-folder ones) into one merged list of folders and tests. */
    fun fold(docs: Collection<String?>): Pair<List<JSONObject>, List<JSONObject>> {
        var fa: JSONArray? = null
        var ta: JSONArray? = null
        for (text in docs) {
            val d = try { JSONObject(text ?: continue) } catch (e: Exception) { continue }
            val f = d.optJSONArray("folders") ?: continue
            val t = d.optJSONArray("tests") ?: continue
            fa = if (fa == null) f else Merge.list(fa, f)
            ta = if (ta == null) t else Merge.list(ta, t)
        }
        fun lst(a: JSONArray?) = (0 until (a?.length() ?: 0)).mapNotNull { a!!.optJSONObject(it) }
        return lst(fa) to lst(ta)
    }

    fun folders(all: List<Folder>, k: String) = all.filter { !it.x && it.k == k }.sortedBy { it.o }
    fun folder(all: List<Folder>, id: String) = all.firstOrNull { it.id == id && !it.x }

    private fun alive(tests: List<TestRec>, fid: String) = tests.filter { !it.x && it.f == fid }

    fun autoNo(tests: List<TestRec>, t: TestRec): Int {
        val a = alive(tests, t.f).sortedWith(compareBy<TestRec>({ it.o }, { it.id }))
        return a.indexOfFirst { it.id == t.id } + 1
    }

    fun num(tests: List<TestRec>, t: TestRec): Int = if (t.no.isNotEmpty()) (t.no.trim().toIntOrNull() ?: autoNo(tests, t)) else autoNo(tests, t)

    fun nextNo(tests: List<TestRec>, fid: String): Int = (alive(tests, fid).maxOfOrNull { num(tests, it) } ?: 0) + 1

    /** Tests of a folder: highest number first, then newest date. */
    fun list(tests: List<TestRec>, fid: String): List<TestRec> =
        alive(tests, fid).sortedWith { a, b ->
            val dn = num(tests, b) - num(tests, a)
            if (dn != 0) dn else if (a.d != b.d) b.d.compareTo(a.d) else b.o.compareTo(a.o)
        }

    fun st(t: TestRec) = if (t.an in 1..2) t.an else 0

    fun qs(t: TestRec): List<TQ> {
        val secs = t.secs ?: return emptyList()
        val out = ArrayList<TQ>()
        t.subs.forEachIndexed { si, _ ->
            var no = 0
            secs.forEachIndexed { ci, sc -> repeat(sc.count) { no++; out.add(TQ(no, si, ci)) } }
        }
        return out
    }

    data class Cnt(val n: Int = 0, val a: Int = 0, val r: Int = 0, val i: Int = 0, val d: Int = 0)

    /** Totals of questions and of each mark: attempted (1), review (2), important (4), doubt (8). */
    fun cnt(t: TestRec, sub: Int? = null): Cnt {
        var n = 0; var a = 0; var r = 0; var i = 0; var d = 0
        for (q in qs(t)) {
            if (sub != null && q.sub != sub) continue
            n++
            val v = t.mark("${q.sub}.${q.no}")
            if (v and 1 != 0) a++
            if (v and 2 != 0) r++
            if (v and 4 != 0) i++
            if (v and 8 != 0) d++
        }
        return Cnt(n, a, r, i, d)
    }

    fun max(t: TestRec): Double = (t.secs?.sumOf { it.count * it.pos } ?: 0.0) * maxOf(t.subs.size, 1)

    /** Days from [today] to [day]: positive = in the future. */
    fun days(day: String, today: String): Int = if (Dates.valid(day) && Dates.valid(today)) Dates.between(today, day) else 0

    fun dl(k: String, thisYear: Int): String {
        if (!Dates.valid(k)) return ""
        val d = Dates.parse(k)
        return d.dayOfMonth.toString() + " " + Dates.monthName(k).take(3) + (if (d.year != thisYear) " " + d.year else "")
    }

    /** Flips one mark bit of a question; the entry disappears when no bit is left. */
    fun toggle(m: JSONObject, key: String, bit: Int) {
        val x = m.optInt(key, 0) xor bit
        if (x != 0) m.put(key, x) else m.remove(key)
    }

    // ---------- results: percentile, rank and total students give each other ----------
    fun rd(x: Double, d: Int): Double { val m = Math.pow(10.0, d.toDouble()); return Math.round(x * m) / m }
    fun pcOf(n: Double, k: Double, d: Int) = rd((n - k) * 100 / n, d)
    fun dec(s: String): Int { val m = Regex("\\.(\\d*)").find(s.replace(",", ".")); return m?.groupValues?.get(1)?.length ?: 0 }

    /** Decimals needed in a percentile to tell neighbouring ranks apart among [n] students. */
    fun rsMin(n: Double): Int = if (n > 0) maxOf(0, Math.ceil(Math.log10(n / 100) - 1e-12).toInt()) else 0

    fun rank(pc: Double, n: Double, d: Int): Double {
        val x = (100 - pc) * n / 100
        val c = ArrayList<Double>()
        listOf(Math.floor(x), Math.ceil(x)).forEach { v0 -> val v = Math.min(Math.max(v0, 1.0), n); if (!c.contains(v)) c.add(v) }
        c.sortBy { Math.abs(x - it) }
        for (v in c) if (pcOf(n, v, d) == rd(pc, d)) return v
        return c[0]
    }

    fun total(pc: Double, k: Double, d: Int): Double? {
        if (pc >= 100) return null
        val x = k * 100 / (100 - pc)
        val c = ArrayList<Double>()
        listOf(Math.floor(x), Math.ceil(x)).forEach { v0 -> val v = Math.max(v0, k); if (!c.contains(v)) c.add(v) }
        c.sortBy { Math.abs(x - it) }
        for (v in c) if (pcOf(v, k, d) == rd(pc, d)) return v
        return c[0]
    }

    private val NUM = Regex("^[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?$")

    /** Reads a typed number: null = empty, NaN = not a number. */
    fun parseNum(s: String?): Double? {
        val v = (s ?: "").replace(",", ".").trim()
        if (v.isEmpty()) return null
        return if (NUM.matches(v)) v.toDouble() else Double.NaN
    }

    private fun fmtNum(x: Double): String = if (x == Math.floor(x) && Math.abs(x) < 1e15) x.toLong().toString() else x.toString()

    data class RsState(val pc: String, val rk: String, val ts: String, val auto: String)

    /** After the user types in one of percentile ("pc"), rank ("rk") or total students ("ts"): fills the third from the other two. */
    fun rsSync(s: RsState, from: String): RsState {
        var auto = s.auto
        val f = mutableMapOf("pc" to s.pc, "rk" to s.rk, "ts" to s.ts)
        if (from == auto) auto = ""
        val v = f.mapValues { parseNum(it.value) }
        val user = listOf("pc", "rk", "ts").filter { it != auto && v[it] != null && !v[it]!!.isNaN() }
        if (auto.isNotEmpty() && user.size < 2) { f[auto] = ""; auto = "" }
        if (user.size == 2) {
            val miss = listOf("pc", "rk", "ts").first { it !in user }
            var out: String? = null
            val pc = v["pc"]; val rk = v["rk"]; val ts = v["ts"]
            var d = dec(f["pc"]!!)
            if (miss == "rk" && ts != null && ts >= 1 && Math.floor(ts) == ts && pc != null && pc in 0.0..100.0) out = fmtNum(rank(pc, ts, d))
            else if (miss == "pc" && ts != null && rk != null && ts >= 1 && rk >= 1 && rk <= ts && Math.floor(rk) == rk) {
                d = maxOf(2, rsMin(ts))
                out = String.format(java.util.Locale.ROOT, "%.${d}f", pcOf(ts, rk, d))
            } else if (miss == "ts" && rk != null && pc != null && rk >= 1 && Math.floor(rk) == rk && pc >= 0 && pc < 100) total(pc, rk, d)?.let { out = fmtNum(it) }
            if (out != null) { f[miss] = out!!; auto = miss }
            else if (auto.isNotEmpty()) { f[auto] = ""; auto = "" }
        }
        return RsState(f["pc"]!!, f["rk"]!!, f["ts"]!!, auto)
    }

    /** Checks the result form the way the web app does; returns an error text or null, and the parsed result. */
    fun rsCheck(fmS: String, scS: String, pcS: String, rkS: String, tsS: String, auto: String): Pair<String?, Rs?> {
        val fm = parseNum(fmS); val sc = parseNum(scS); val ts = parseNum(tsS); val pc = parseNum(pcS); val rk = parseNum(rkS)
        if (listOf(fm, sc, ts, pc, rk).any { it != null && it.isNaN() }) return "Enter numbers only" to null
        if (fm != null && fm <= 0) return "Full marks must be more than 0" to null
        if (fm != null && sc != null && sc > fm) return "Score can't be above full marks" to null
        if (ts != null && (ts < 1 || Math.floor(ts) != ts)) return "Total students must be a whole number" to null
        if (rk != null && (rk < 1 || Math.floor(rk) != rk)) return "Rank must be a whole number" to null
        if (rk != null && ts != null && rk > ts) return "Rank can't be above total students" to null
        if (pc != null && (pc < 0 || pc > 100)) return "Percentile is between 0 and 100" to null
        if (pc != null && ts != null && auto != "pc" && auto != "ts" && dec(pcS) < rsMin(ts)) {
            val nd = rsMin(ts)
            return "For ${inr(ts.toLong())} students enter percentile with at least $nd " + (if (nd == 1) "decimal" else "decimals") to null
        }
        return null to Rs(fm, sc, ts, pc, rk)
    }

    /** Indian digit grouping: 1234567 -> 12,34,567. */
    fun inr(n: Long): String {
        val s = Math.abs(n).toString()
        val out = if (s.length <= 3) s else {
            val last = s.takeLast(3)
            val rest = s.dropLast(3).reversed().chunked(2).joinToString(",").reversed()
            "$rest,$last"
        }
        return (if (n < 0) "-" else "") + out
    }

    fun nz(x: Double?) = x?.let { Sess.num(it) }
}
