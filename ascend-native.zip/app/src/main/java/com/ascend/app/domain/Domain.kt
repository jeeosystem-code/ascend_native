package com.ascend.app.domain

import com.ascend.app.data.Row
import com.ascend.app.data.RowDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the planner data up to date from the downloaded rows, and writes changes back as homework month documents. */
class Domain(private val rows: RowDao, private val onChanged: () -> Unit) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _data = MutableStateFlow<DomainData?>(null)
    val data: StateFlow<DomainData?> = _data
    private val lock = Mutex()

    init {
        rows.watchDomain()
            .map { list -> DomainData.from(list.filter { !it.deleted }.associate { it.id to it.data }) }
            .onEach { _data.value = it }
            .launchIn(scope)
    }

    private fun newId() = java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Long.toString((Math.random() * 1679616).toLong() + 46656, 36).takeLast(4)

    /**
     * Applies [change] to the homework items and saves the month documents it touched. [change] gets a copy of every
     * item (as JSON); it may edit items, or add new ones to the list. Every edited item must get a new "u".
     */
    suspend fun editHw(change: (MutableList<JSONObject>, Long) -> Unit) = lock.withLock {
        val now = System.currentTimeMillis()
        val current = DomainData.from(rows.homework().filter { !it.deleted }.associate { it.id to it.data })
        val list = current.items.map { JSONObject(it.j.toString()) }.toMutableList()
        val before = list.associate { it.optString("id") to (it.optLong("u", 0).toString() + ":" + (if (Merge.isX(it)) 1 else 0) + ":" + it.optString("d")) }
        change(list, now)
        val months = HashSet<String>()
        for (j in list) {
            val id = j.optString("id")
            val b = before[id]
            val a = j.optLong("u", 0).toString() + ":" + (if (Merge.isX(j)) 1 else 0) + ":" + j.optString("d")
            if (b != a) {
                months.add(Dates.shard(j.optString("d")))
                if (b != null) months.add(Dates.shard(b.substringAfterLast(':')))
            }
        }
        for (m in months) {
            val inMonth = list.filter { Dates.shard(it.optString("d")) == m }
            if (inMonth.isEmpty()) continue
            val arr = JSONArray()
            inMonth.forEach { arr.put(it) }
            val doc = JSONObject().put("subjects", JSONArray()).put("items", arr).put("savedAt", now).toString()
            if (doc.length > 900000) continue
            rows.put(Row("zz_hw_$m", doc, false, now, "put", now))
        }
        if (months.isNotEmpty()) onChanged()
    }

    suspend fun addTask(title: String, day: String, subject: String, time: String, minutes: Int, priority: Int, note: String) = editHw { list, now ->
        val j = JSONObject().put("id", newId()).put("s", subject).put("ch", "").put("ex", "").put("rg", "").put("cn", "").put("en", "")
            .put("d", day).put("t", title).put("done", false).put("o", now).put("u", now)
        if (time.isNotEmpty()) j.put("tm", time)
        if (minutes > 0) j.put("du", minutes)
        if (priority in 1..3) j.put("pr", priority)
        if (note.isNotBlank()) j.put("nt", note.trim())
        list.add(j)
    }

    suspend fun updateTask(id: String, title: String, day: String, subject: String, time: String, minutes: Int, priority: Int, note: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        if (title.isNotEmpty()) j.put("t", title)
        j.put("d", day).put("s", subject)
        if (time.isNotEmpty()) j.put("tm", time) else j.remove("tm")
        if (minutes > 0) j.put("du", minutes) else j.remove("du")
        if (priority in 1..3) j.put("pr", priority) else j.remove("pr")
        if (note.isNotBlank()) j.put("nt", note.trim()) else j.remove("nt")
        j.put("u", now)
    }

    suspend fun toggle(id: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("done", !j.optBoolean("done", false)).put("u", now)
    }

    suspend fun delete(id: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("x", 1).put("t", "").put("u", now)
    }

    suspend fun moveTo(id: String, day: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("d", day).put("u", now)
    }

    /** Moves the unfinished tasks of a plan so they finish by [day], spread evenly from today. */
    suspend fun finishPlan(planId: String, day: String) {
        val d = data.value ?: return
        val today = Dates.today()
        val list = d.items.filter { d.live(it) && it.pl == planId && !it.done }
        if (list.isEmpty() || day < today) return
        val moved = Planner.spread(d, list, Dates.between(today, day) + 1, today)
        editHw { items, now ->
            items.forEach { j ->
                val nd = moved[j.optString("id")]
                if (nd != null) j.put("d", nd).put("u", now)
            }
        }
    }

    /** Deletes a plan: finished tasks stay (without the plan label), unfinished ones are removed. */
    suspend fun deletePlan(planId: String) = editHw { items, now ->
        items.forEach { j ->
            if (j.optString("pl") == planId && !Merge.isX(j)) {
                if (j.optBoolean("done", false)) { j.remove("pl"); j.remove("pn") } else { j.put("x", 1).put("t", "") }
                j.put("u", now)
            }
        }
    }

    /** Saves the target exam and planner limits into the account profile (shared with the web app). */
    suspend fun saveExam(exam: String, name: String, capHours: Int, minPerQ: Int) = lock.withLock {
        val prev = rows.get("zz_profile")
        val cur = try { JSONObject(prev?.data ?: "") } catch (e: Exception) { JSONObject().put("name", "").put("photo", "") }
        val old = cur.optLong("u", 0)
        var u = System.currentTimeMillis()
        if (u <= old) u = old + 1
        cur.put("u", u)
        cur.put("pe", JSONObject().put("exam", exam).put("en", name.trim().take(24)).put("cap", capHours).put("mpq", minPerQ).put("u", u))
        rows.put(Row("zz_profile", cur.toString(), false, u, "put", u))
        onChanged()
    }
}
