package com.ascend.app.domain

import com.ascend.app.data.Row
import com.ascend.app.data.RowDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the planner data up to date from the downloaded rows, and writes changes back as homework month documents. */
class Domain(private val rows: RowDao, private val onChanged: () -> Unit) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _data = MutableStateFlow<DomainData?>(null)
    val data: StateFlow<DomainData?> = _data
    private val lock = Mutex()

    init {
        rows.watchDomain()
            .map { list -> DomainData.from(list.filter { !it.deleted }.associate { it.id to it.data }) }
            .onEach { _data.value = it }
            .launchIn(scope)
    }

    private fun newId() = java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Long.toString((Math.random() * 1679616).toLong() + 46656, 36).takeLast(4)

    /**
     * Applies [change] to the homework items and saves the month documents it touched. [change] gets a copy of every
     * item (as JSON); it may edit items, or add new ones to the list. Every edited item must get a new "u".
     */
    suspend fun editHw(change: (MutableList<JSONObject>, Long) -> Unit) = lock.withLock {
        val now = System.currentTimeMillis()
        val current = DomainData.from(rows.homework().filter { !it.deleted }.associate { it.id to it.data })
        val list = current.items.map { JSONObject(it.j.toString()) }.toMutableList()
        val before = list.associate { it.optString("id") to (it.optLong("u", 0).toString() + ":" + (if (Merge.isX(it)) 1 else 0) + ":" + it.optString("d")) }
        change(list, now)
        val months = HashSet<String>()
        for (j in list) {
            val id = j.optString("id")
            val b = before[id]
            val a = j.optLong("u", 0).toString() + ":" + (if (Merge.isX(j)) 1 else 0) + ":" + j.optString("d")
            if (b != a) {
                months.add(Dates.shard(j.optString("d")))
                if (b != null) months.add(Dates.shard(b.substringAfterLast(':')))
            }
        }
        for (m in months) {
            val inMonth = list.filter { Dates.shard(it.optString("d")) == m }
            if (inMonth.isEmpty()) continue
            val arr = JSONArray()
            inMonth.forEach { arr.put(it) }
            val doc = JSONObject().put("subjects", JSONArray()).put("items", arr).put("savedAt", now).toString()
            if (doc.length > 900000) continue
            rows.put(Row("zz_hw_$m", doc, false, now, "put", now))
        }
        if (months.isNotEmpty()) onChanged()
    }

    suspend fun addTask(title: String, day: String, subject: String, time: String, minutes: Int, priority: Int, note: String) = editHw { list, now ->
        val j = JSONObject().put("id", newId()).put("s", subject).put("ch", "").put("ex", "").put("rg", "").put("cn", "").put("en", "")
            .put("d", day).put("t", title).put("done", false).put("o", now).put("u", now)
        if (time.isNotEmpty()) j.put("tm", time)
        if (minutes > 0) j.put("du", minutes)
        if (priority in 1..3) j.put("pr", priority)
        if (note.isNotBlank()) j.put("nt", note.trim())
        list.add(j)
    }

    suspend fun updateTask(id: String, title: String, day: String, subject: String, time: String, minutes: Int, priority: Int, note: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        if (title.isNotEmpty()) j.put("t", title)
        j.put("d", day).put("s", subject)
        if (time.isNotEmpty()) j.put("tm", time) else j.remove("tm")
        if (minutes > 0) j.put("du", minutes) else j.remove("du")
        if (priority in 1..3) j.put("pr", priority) else j.remove("pr")
        if (note.isNotBlank()) j.put("nt", note.trim()) else j.remove("nt")
        j.put("u", now)
    }

    suspend fun toggle(id: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("done", !j.optBoolean("done", false)).put("u", now)
    }

    suspend fun delete(id: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("x", 1).put("t", "").put("u", now)
    }

    suspend fun moveTo(id: String, day: String) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == id } ?: return@editHw
        j.put("d", day).put("u", now)
    }

    /** Moves the unfinished tasks of a plan so they finish by [day], spread evenly from today. */
    suspend fun finishPlan(planId: String, day: String) {
        val d = data.value ?: return
        val today = Dates.today()
        val list = d.items.filter { d.live(it) && it.pl == planId && !it.done }
        if (list.isEmpty() || day < today) return
        val moved = Planner.spread(d, list, Dates.between(today, day) + 1, today)
        editHw { items, now ->
            items.forEach { j ->
                val nd = moved[j.optString("id")]
                if (nd != null) j.put("d", nd).put("u", now)
            }
        }
    }

    /** Deletes a plan: finished tasks stay (without the plan label), unfinished ones are removed. */
    suspend fun deletePlan(planId: String) = editHw { items, now ->
        items.forEach { j ->
            if (j.optString("pl") == planId && !Merge.isX(j)) {
                if (j.optBoolean("done", false)) { j.remove("pl"); j.remove("pn") } else { j.put("x", 1).put("t", "") }
                j.put("u", now)
            }
        }
    }

    /** Saves the target exam and planner limits into the account profile (shared with the web app). */
    suspend fun saveExam(exam: String, name: String, capHours: Int, minPerQ: Int) = lock.withLock {
        val prev = rows.get("zz_profile")
        val cur = try { JSONObject(prev?.data ?: "") } catch (e: Exception) { JSONObject().put("name", "").put("photo", "") }
        val old = cur.optLong("u", 0)
        var u = System.currentTimeMillis()
        if (u <= old) u = old + 1
        cur.put("u", u)
        cur.put("pe", JSONObject().put("exam", exam).put("en", name.trim().take(24)).put("cap", capHours).put("mpq", minPerQ).put("u", u))
        rows.put(Row("zz_profile", cur.toString(), false, u, "put", u))
        onChanged()
    }

    /** Saves (or replaces) one focus session entry in the shared revision log. */
    suspend fun saveFocus(e: FocusEntry) = lock.withLock {
        val now = System.currentTimeMillis()
        val prev = rows.get("zz_revlog")
        val cur = try { JSONObject(prev?.data ?: "") } catch (x: Exception) { JSONObject() }
        val m = cur.optJSONObject("m") ?: JSONObject()
        m.put(e.key, e.toJson())
        cur.put("m", m).put("savedAt", now)
        rows.put(Row("zz_revlog", cur.toString(), false, now, "put", now))
        onChanged()
    }

    /** The saved entry for a session key, for the timer to carry on from. */
    suspend fun focusEntry(key: String): FocusEntry? {
        val m: JSONObject? = try { JSONObject(rows.get("zz_revlog")?.data ?: "").optJSONObject("m") } catch (x: Exception) { null }
        return m?.optJSONObject(key)?.let { FocusEntry.from(key, it) }
    }

    /** After a practice session linked to a task: records which questions were attempted and finishes the task when all are covered. */
    suspend fun sessionDone(taskId: String, got: List<Int>, finish: Boolean = true) = editHw { list, now ->
        val j = list.firstOrNull { it.optString("id") == taskId } ?: return@editHw
        if (j.optBoolean("done", false)) return@editHw
        if (got.isNotEmpty()) {
            val have = Ranges.numbers(j.optString("at")).toMutableSet()
            have.addAll(got)
            j.put("at", Ranges.compress(have.toList())).put("u", now)
        }
        val all = Ranges.numbers(j.optString("rg"))
        val at = Ranges.numbers(j.optString("at")).toSet()
        val complete = if (all.isNotEmpty()) all.none { it !in at } else got.isNotEmpty()
        if (finish && complete) j.put("done", true).put("u", now)
    }

    /** Questions of a task still to do (those not yet attempted); all of them when nothing was done yet. */
    fun taskLeft(i: HwItem): List<Int> {
        val all = Ranges.numbers(i.rg)
        if (i.done) return emptyList()
        val at = Ranges.numbers(i.at).toSet()
        return all.filter { it !in at }
    }

    val sessionRows = rows.watchSessions()
    val draftRow = rows.watchDraft()

    /** Saves a finished (or edited) session under its own id, the way the web app does. */
    suspend fun saveSession(id: String, json: String) {
        val now = System.currentTimeMillis()
        rows.put(Row(id, json, false, now, "put", now))
        onChanged()
    }

    // ---------- attempts of saved tests (rows zz_att_<test>_<part>) ----------

    /** Edits the records of one test and writes them back in parts below the size limit, like the web app. */
    private suspend fun editAtt(tid: String, change: (MutableList<JSONObject>, Long) -> Unit) = lock.withLock {
        val now = System.currentTimeMillis()
        var merged = JSONArray()
        rows.attRows().filter { !it.deleted && it.data != null && At.tidOf(it.id) == tid }.forEach { r ->
            val d = try { JSONObject(r.data!!) } catch (e: Exception) { null } ?: return@forEach
            if (Merge.valid("at", d)) merged = Merge.list(merged, d.optJSONArray("recs"))
        }
        val recs = (0 until merged.length()).mapNotNull { merged.optJSONObject(it) }.filter { it.optString("tid") == tid }.map { JSONObject(it.toString()) }.toMutableList()
        val before = Merge.sig(JSONArray(recs))
        change(recs, now)
        if (Merge.sig(JSONArray(recs)) == before) return@withLock
        At.chunks(recs).forEachIndexed { i, part ->
            if (part.isEmpty()) return@forEachIndexed
            val doc = JSONObject().put("recs", JSONArray(part)).put("savedAt", now).toString()
            rows.put(Row(At.docId(tid, i + 1), doc, false, now, "put", now))
        }
        onChanged()
    }

    /** Saves (or refreshes) the attempt record of a test session. Does nothing for other sessions. */
    suspend fun syncAttempt(cfg: Cfg, res: List<Res?>, usedMs: Long) {
        if (!cfg.test || cfg.tid.isEmpty() || cfg.id.isEmpty()) return
        editAtt(cfg.tid) { recs, now ->
            val i = recs.indexOfFirst { it.optString("id") == cfg.id && it.optString("k") == "a" }
            if (i >= 0 && Merge.isX(recs[i])) return@editAtt
            val rec = At.record(cfg, res, usedMs, if (i >= 0) recs[i] else null, now)
            if (i >= 0) recs[i] = rec else recs.add(rec)
        }
    }

    /** Tags questions [nums] of subject [sub] of a test with a syllabus chapter (empty chapter = remove the tag). */
    suspend fun tagChapters(tid: String, sub: Int, nums: Collection<Int>, chapter: String) = editAtt(tid) { recs, now -> At.tag(recs, tid, sub, nums, chapter, now) }

    private suspend fun editAttempt(tid: String, id: String, f: (JSONObject) -> Unit) = editAtt(tid) { recs, now ->
        recs.firstOrNull { it.optString("id") == id && it.optString("k") == "a" && !Merge.isX(it) }?.let { f(it); it.put("u", now) }
    }

    /** Turns a mistake reason on or off for one question of an attempt. [bit] is one of the At.RM values. */
    suspend fun toggleReason(tid: String, id: String, key: String, bit: Int) = editAttempt(tid, id) { a ->
        val rm = a.optJSONObject("rm") ?: JSONObject().also { a.put("rm", it) }
        val v = rm.optInt(key, 0) xor bit
        if (v == 0) rm.remove(key) else rm.put(key, v)
    }

    suspend fun setNote(tid: String, id: String, key: String, text: String) = editAttempt(tid, id) { a ->
        val nt = a.optJSONObject("nt") ?: JSONObject().also { a.put("nt", it) }
        val v = text.trim().take(140)
        if (v.isEmpty()) nt.remove(key) else nt.put(key, v)
    }

    suspend fun deleteAttempt(tid: String, id: String) = editAttempt(tid, id) { a ->
        a.put("x", 1).put("q", JSONArray()).put("rm", JSONObject()).put("nt", JSONObject())
    }

    /** Keeps the running session so it can be resumed later. Uploaded with the next regular sync (no extra sync trigger). */
    suspend fun saveDraft(json: String) {
        val now = System.currentTimeMillis()
        rows.put(Row("zz_draft", json, false, now, "put", now))
    }

    suspend fun clearDraft() {
        if (rows.get("zz_draft") == null) return
        val now = System.currentTimeMillis()
        rows.put(Row("zz_draft", null, true, now, "del", now))
        onChanged()
    }

    // ---------- test library ----------

    private fun syName(t: String) = t.replace(Regex("\\s+"), " ").trim()

    /**
     * Applies [change] to the test folders and tests and saves one cloud document per folder that changed
     * (zz_tests_<folder id>), the same layout the web app uses.
     */
    suspend fun editTests(change: (MutableList<JSONObject>, MutableList<JSONObject>, Long) -> Unit) = lock.withLock {
        val now = System.currentTimeMillis()
        val (f0, t0) = Tl.fold(rows.testRows().filter { !it.deleted }.map { it.data })
        val folders = f0.map { JSONObject(it.toString()) }.toMutableList()
        val tests = t0.map { JSONObject(it.toString()) }.toMutableList()
        fun sig(o: JSONObject) = o.optLong("u", 0).toString() + ":" + (if (Merge.isX(o)) 1 else 0)
        val before = HashMap<String, String>()
        folders.forEach { before["f" + it.optString("id")] = sig(it) }
        tests.forEach { before["t" + it.optString("id")] = sig(it) }
        change(folders, tests, now)
        val hit = LinkedHashSet<String>()
        folders.forEach { if (before["f" + it.optString("id")] != sig(it)) hit.add(it.optString("id")) }
        tests.forEach { if (before["t" + it.optString("id")] != sig(it)) hit.add(it.optString("f")) }
        for (fid in hit) {
            val fo = folders.firstOrNull { it.optString("id") == fid } ?: continue
            val ta = JSONArray()
            tests.filter { it.optString("f") == fid }.forEach { ta.put(it) }
            val doc = JSONObject().put("folders", JSONArray().put(fo)).put("tests", ta).put("savedAt", now).toString()
            if (doc.length > 900000) continue
            rows.put(Row("zz_tests_$fid", doc, false, now, "put", now))
        }
        if (hit.isNotEmpty()) onChanged()
    }

    suspend fun saveFolder(id: String, k: String, name: String, sub: String): Boolean {
        val n = syName(name)
        if (n.isEmpty()) return false
        var sb = syName(sub)
        if (k == "s" && sb.isEmpty()) sb = n
        editTests { folders, _, now ->
            val ex = if (id.isNotEmpty()) folders.firstOrNull { it.optString("id") == id } else null
            if (ex != null) ex.put("n", n).put("sb", if (k == "s") sb else "").put("u", now)
            else folders.add(JSONObject().put("id", newId()).put("k", k).put("n", n).put("sb", if (k == "s") sb else "").put("o", now).put("u", now))
        }
        return true
    }

    suspend fun deleteFolder(id: String) = editTests { folders, tests, now ->
        folders.filter { it.optString("id") == id }.forEach { it.put("x", 1).put("u", now) }
        tests.filter { it.optString("f") == id && !Merge.isX(it) }.forEach { it.put("x", 1).put("u", now) }
    }

    /** Adds a test (or changes the pattern of [exId]); returns its id. An upcoming test has no pattern yet ([secs] null). */
    suspend fun saveTest(folderId: String, exId: String, name: String, date: String, durMin: Int, subs: List<String>, secs: List<Sec>?): String {
        var result = exId
        editTests { folders, tests, now ->
            val f = folders.firstOrNull { it.optString("id") == folderId && !Merge.isX(it) } ?: return@editTests
            val subA = JSONArray(); subs.forEach { subA.put(it) }
            val secV: Any = if (secs == null) JSONObject.NULL else JSONArray().also { a -> secs.forEach { a.put(JSONObject().put("name", it.name).put("count", it.count).put("pos", it.pos).put("neg", it.neg).put("partial", it.partial)) } }
            val ex = if (exId.isNotEmpty()) tests.firstOrNull { it.optString("id") == exId } else null
            if (ex != null) {
                if (name.isNotEmpty()) ex.put("n", name)
                ex.put("d", date).put("dur", durMin).put("subs", subA).put("secs", secV)
                if (!ex.has("m")) ex.put("m", JSONObject())
                ex.put("u", now)
            } else {
                val all = tests.map { TestRec(it) }
                val nx = Tl.nextNo(all, folderId)
                val id = newId()
                result = id
                tests.add(JSONObject().put("id", id).put("f", folderId).put("n", name.ifEmpty { "Test $nx" }).put("no", nx.toString()).put("d", date)
                    .put("subs", subA).put("secs", secV).put("dur", durMin).put("m", JSONObject()).put("o", now).put("u", now))
            }
        }
        return result
    }

    private suspend fun editTest(id: String, f: (JSONObject, Long) -> Unit) = editTests { _, tests, now ->
        tests.firstOrNull { it.optString("id") == id && !Merge.isX(it) }?.let { f(it, now); it.put("u", now) }
    }

    suspend fun toggleMark(id: String, key: String, bit: Int) = editTest(id) { t, _ ->
        val m = t.optJSONObject("m") ?: JSONObject().also { t.put("m", it) }
        Tl.toggle(m, key, bit)
    }

    suspend fun deleteTest(id: String) = editTest(id) { t, _ -> t.put("x", 1) }
    suspend fun setTestDate(id: String, d: String) = editTest(id) { t, _ -> t.put("d", d) }

    suspend fun saveResult(id: String, rs: Rs) = editTest(id) { t, _ -> if (rs.any) t.put("rs", rs.toJson()) else t.remove("rs") }

    /** Name, number and analysis status of a test (the number box empty = keep the automatic number). */
    suspend fun saveAnalysis(id: String, numText: String, status: Int, name: String) {
        val cur = data.value
        val t0 = cur?.tests?.firstOrNull { it.id == id } ?: return
        val digits = numText.filter { it.isDigit() }.take(4)
        val nn = name.replace(Regex("\\s+"), " ").trim().take(60)
        val auto = Tl.num(cur.tests, t0)
        editTest(id) { t, _ ->
            t.put("no", if (digits.isEmpty()) auto.toString() else (digits.toIntOrNull() ?: auto).toString())
            if (status in 1..2) t.put("an", status) else t.remove("an")
            if (nn.isNotEmpty() && nn != t.optString("n")) t.put("n", nn)
        }
        val plan = cur.items.firstOrNull { it.tl == id && !it.x }
        if (plan != null) {
            editHw { list, now ->
                val j = list.firstOrNull { it.optString("id") == plan.id } ?: return@editHw
                if (nn.isNotEmpty() && nn != t0.n) j.put("t", "Analyse · $nn").put("u", now)
                if (status == 2 && !j.optBoolean("done", false)) j.put("done", true).put("u", now)
            }
        }
    }

    /** Puts "Analyse · <test>" on the planner for [day] (or moves the existing one). */
    suspend fun planAnalysis(testId: String, day: String) {
        val cur = data.value ?: return
        val t = cur.tests.firstOrNull { it.id == testId } ?: return
        val f = Tl.folder(cur.folders, t.f)
        val sid = if (f != null && f.sb.isNotEmpty()) cur.subjectIdByName(f.sb) else ""
        editHw { list, now ->
            val ex = list.firstOrNull { it.optString("tl") == testId && !Merge.isX(it) }
            if (ex != null) ex.put("d", day).put("u", now).put("done", false)
            else list.add(JSONObject().put("id", newId()).put("s", sid).put("ch", "").put("ex", "").put("rg", "").put("cn", "").put("en", "")
                .put("d", day).put("t", "Analyse · " + t.n).put("done", false).put("o", now).put("u", now).put("tl", testId))
        }
    }

    suspend fun unplanAnalysis(testId: String) = editHw { list, now ->
        list.filter { it.optString("tl") == testId && !Merge.isX(it) }.forEach { it.put("x", 1).put("t", "").put("u", now) }
    }

    /** Gives every unnumbered test its current automatic number so later deletions do not renumber the rest. */
    suspend fun freezeNumbers() {
        val cur = data.value ?: return
        if (cur.tests.none { !it.x && it.no.isEmpty() && Tl.folder(cur.folders, it.f) != null }) return
        editTests { folders, tests, now ->
            for (f in folders) {
                if (Merge.isX(f)) continue
                val a = tests.filter { !Merge.isX(it) && it.optString("f") == f.optString("id") }
                    .sortedWith(compareBy<JSONObject>({ it.optLong("o", 0) }, { it.optString("id") }))
                val used = HashSet<Int>()
                a.forEach { t -> t.optString("no").trim().toIntOrNull()?.let { used.add(it) } }
                var n = 0
                for (t in a) {
                    if (t.optString("no").isNotEmpty()) continue
                    do { n++ } while (n in used)
                    used.add(n)
                    t.put("no", n.toString()).put("u", now)
                }
            }
        }
    }
}
