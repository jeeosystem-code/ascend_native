package com.ascend.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ascend.app.ui.theme.Tk

/** A translucent "glass" card: soft fill, thin edge, rounded corners. Android has no live blur, so this is flat glass. */
@Composable
fun Glass(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    tint: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val t = Tk.c
    val shape = RoundedCornerShape(22.dp)
    val fill = (tint ?: t.card).copy(alpha = if (t.dark) 0.82f else 0.78f)
    val m = if (onClick != null) modifier.clip(shape).clickable { onClick() } else modifier
    Surface(modifier = m, shape = shape, color = fill, border = BorderStroke(1.dp, t.line)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

/** Draws an icon from SVG path strings on a 24x24 grid (the same icons the web app uses). */
@Composable
fun SvgIcon(paths: List<String>, color: Color, size: Dp = 24.dp, stroke: Float = 1.8f) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 24f
        withTransform({ scale(s, s, Offset.Zero) }) {
            paths.forEach { d ->
                drawPath(
                    PathParser().parsePathString(d).toPath(), color,
                    style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
            }
        }
    }
}

object Icons {
    val home = listOf("M4 11l8-7 8 7v8.5a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z")
    val plan = listOf("M7 5h10a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z", "M8 3v4M16 3v4M4 10h16M9 15l2 2 4-4")
    val practice = listOf("M3.5 12a8.5 8.5 0 1 0 17 0a8.5 8.5 0 1 0-17 0", "M10 8.5v7l6-3.5z")
    val track = listOf("M5 20V12M12 20V5M19 20v-5")
    val more = listOf("M4.6 12a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0-2.8 0", "M10.6 12a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0-2.8 0", "M16.6 12a1.4 1.4 0 1 0 2.8 0a1.4 1.4 0 1 0-2.8 0")
    val sun = listOf("M8 12a4 4 0 1 0 8 0a4 4 0 1 0-8 0", "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4")
    val moon = listOf("M21 13.5A8.5 8.5 0 1 1 10.5 3a7 7 0 0 0 10.5 10.5z")
    val back = listOf("M15 5l-7 7 7 7")
}

@Composable
fun Hit(modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).clickable { onClick() }) { content() }
}
