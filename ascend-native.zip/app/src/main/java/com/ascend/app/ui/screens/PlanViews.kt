package com.ascend.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.domain.Dates
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.HwItem
import com.ascend.app.domain.Planner
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk

/** Day / Week / Month / Plans switch. The chosen one gets a soft accent tint. */
@Composable
fun ViewTabs(view: String, onPick: (String) -> Unit) {
    val t = Tk.c
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.line.copy(alpha = 0.45f)).padding(3.dp)) {
        listOf("d" to "Day", "w" to "Week", "m" to "Month", "p" to "Plans").forEach { (k, label) ->
            val on = view == k
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else Color.Transparent)
                    .clickable { onPick(k) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, color = if (on) t.accent else t.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun WeekView(d: DomainData, sel: String, today: String, onDay: (String) -> Unit) {
    val t = Tk.c
    val start = Dates.weekStart(sel)
    val days = (0..6).map { Dates.add(start, it) }
    val lists = days.map { Planner.day(d, it) }
    val total = lists.sumOf { it.size }
    val done = lists.sumOf { l -> l.count { it.item.done } }
    val mins = lists.sumOf { l -> l.sumOf { it.minutes } }
    Text("$done of $total done" + (if (mins > 0) " · " + Dates.hm(mins) else ""), color = t.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        days.forEachIndexed { n, k ->
            val l = lists[n]
            val s = Planner.stat(l)
            Glass(Modifier.fillMaxWidth(), onClick = { onDay(k) }, tint = if (k == today) t.accent else null) {
                Row {
                    Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(Dates.dowShort(k), color = t.muted, fontSize = 11.sp)
                        Text("${Dates.parse(k).dayOfMonth}", color = if (k == today) t.accent else t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f)) {
                        if (l.isEmpty()) Text("Free", color = t.muted, fontSize = 14.sp)
                        l.take(3).forEach { r ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Box(Modifier.width(3.dp).height(14.dp).clip(RoundedCornerShape(2.dp)).background(Color(r.color)))
                                Text(
                                    r.title, color = if (r.item.done) t.muted else t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(start = 8.dp),
                                )
                            }
                        }
                        if (l.size > 3) Text("+${l.size - 3} more", color = t.muted, fontSize = 12.sp)
                        if (l.isNotEmpty()) Text("${s.done}/${s.n}" + (if (s.minutes > 0) " · " + Dates.hm(s.minutes) else ""), color = t.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun MonthView(d: DomainData, anchor: String, sel: String, today: String, onShift: (Int) -> Unit, onDay: (String) -> Unit) {
    val t = Tk.c
    val grid = Planner.monthGrid(anchor)
    val month = Dates.parse(anchor).monthValue
    val count = HashMap<String, IntArray>()
    d.items.forEach { if (d.live(it)) { val c = count.getOrPut(it.d) { IntArray(2) }; c[0]++; if (it.done) c[1]++ } }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("‹", color = t.ink, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onShift(-1) }.padding(horizontal = 14.dp, vertical = 4.dp))
        Text(Dates.monthName(anchor) + " " + Dates.parse(anchor).year, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Text("›", color = t.ink, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onShift(1) }.padding(horizontal = 14.dp, vertical = 4.dp))
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth()) {
        listOf("M", "T", "W", "T", "F", "S", "S").forEach { Text(it, color = t.muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
    }
    Spacer(Modifier.height(4.dp))
    for (w in 0 until 6) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 7) {
                val k = grid[w * 7 + c]
                val inMonth = Dates.parse(k).monthValue == month
                val cnt = count[k]
                val allDone = cnt != null && cnt[0] == cnt[1]
                Column(
                    Modifier.weight(1f).padding(2.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (k == sel) t.accent.copy(alpha = 0.18f) else Color.Transparent)
                        .clickable { onDay(k) }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "${Dates.parse(k).dayOfMonth}", fontSize = 15.sp,
                        color = if (k == today) t.accent else if (inMonth) t.ink else t.muted.copy(alpha = 0.5f),
                        fontWeight = if (k == today) FontWeight.Bold else FontWeight.Medium,
                    )
                    Box(
                        Modifier.padding(top = 3.dp).size(6.dp).clip(CircleShape)
                            .background(if (cnt == null) Color.Transparent else if (allDone) t.good else if (k < today) t.bad.copy(alpha = 0.8f) else t.accent.copy(alpha = 0.8f)),
                    )
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Legend(t.good, "Done"); Legend(t.accent, "Planned"); Legend(t.bad, "Missed")
    }
}

@Composable
private fun Legend(c: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(c))
        Text(label, color = Tk.c.muted, fontSize = 12.sp, modifier = Modifier.padding(start = 5.dp))
    }
}

@Composable
private fun StatusChip(status: String) {
    val t = Tk.c
    val c = when (status) { "fin" -> t.good; "late" -> t.bad; "up" -> t.accent; else -> t.muted }
    Text(
        Planner.statusLabel(status), color = c, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
fun PlansView(d: DomainData, today: String, onOpen: (String) -> Unit) {
    val t = Tk.c
    val plans = Planner.plans(d, today)
    if (plans.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Text("No plans yet", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("Plans made in the web app show here. The plan wizard comes to the phone next.", color = t.muted, fontSize = 14.sp)
        }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        plans.forEach { p ->
            Glass(Modifier.fillMaxWidth(), onClick = { onOpen(p.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(dayLabel(p.first) + " – " + dayLabel(p.last), color = t.muted, fontSize = 12.5.sp)
                    }
                    StatusChip(p.status)
                }
                Spacer(Modifier.height(10.dp))
                val pc = if (p.total > 0) p.done.toFloat() / p.total else 0f
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.line)) {
                    Box(Modifier.fillMaxWidth(pc).height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.accent))
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${p.done}/${p.total} tasks" + (if (p.questions > 0) " · ${p.questionsDone}/${p.questions} questions" else "") + (if (p.overdue > 0) " · ${p.overdue} overdue" else ""),
                    color = if (p.overdue > 0) t.bad else t.muted, fontSize = 13.sp,
                )
            }
        }
    }
}

private fun dayLabel(k: String) = if (Dates.valid(k)) Dates.parse(k).dayOfMonth.toString() + " " + Dates.monthName(k).take(3) else ""

@Composable
fun PlanDetailView(
    d: DomainData, planId: String, today: String,
    onOpenTask: (HwItem) -> Unit, onDay: (String) -> Unit, onFinishBy: () -> Unit, deleteArmed: Boolean, onDelete: () -> Unit,
) {
    val t = Tk.c
    val p = Planner.plans(d, today).firstOrNull { it.id == planId }
    if (p == null) {
        Text("This plan no longer exists.", color = t.muted)
        return
    }
    val pend = p.items.filter { !it.done }
    val pm = pend.sumOf { Planner.minutes(it, d.profile.minPerQ).takeIf { m -> m > 0 } ?: 15 }
    val daysLeft = if (p.finished || !Dates.valid(p.last)) 0 else maxOf(0, Dates.between(today, p.last) + 1)
    val perDay = if (daysLeft > 0) Math.round(pm.toDouble() / daysLeft).toInt() else 0
    val pc = if (p.total > 0) Math.round(p.done * 100f / p.total) else 0
    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$pc%", color = t.ink, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            StatusChip(p.status)
        }
        Text("${p.done} of ${p.total} tasks · " + dayLabel(p.first) + " – " + dayLabel(p.last), color = t.muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            if (p.questions > 0) Stat("${p.questionsDone}/${p.questions}", "questions")
            Stat(if (p.finished) "–" else "$daysLeft", if (daysLeft == 1) "day left" else "days left")
            Stat(if (pm > 0) Dates.hm(pm) else "–", "left to do")
            if (perDay > 0 && !p.finished) Stat(Dates.hm(perDay), "per day")
        }
    }
    Spacer(Modifier.height(12.dp))
    // Pace: one bar per day of the plan (tap to open that day).
    val first = if (Dates.valid(p.first)) p.first else today
    val span = minOf(200, maxOf(1, Dates.between(first, if (Dates.valid(p.last)) p.last else first) + 1))
    val perDayMin = HashMap<String, IntArray>()
    p.items.forEach { val c = perDayMin.getOrPut(it.d) { IntArray(3) }; c[0] += Planner.minutes(it, d.profile.minPerQ).takeIf { m -> m > 0 } ?: 15; c[1]++; if (it.done) c[2]++ }
    val mx = maxOf(30, perDayMin.values.maxOfOrNull { it[0] } ?: 0)
    Glass(Modifier.fillMaxWidth()) {
        Text("Pace", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).height(70.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (n in 0 until span) {
                val k = Dates.add(first, n)
                val c = perDayMin[k]
                val color = if (c == null) t.line else if (c[1] == c[2]) t.good else if (k < today) t.bad.copy(alpha = 0.85f) else t.accent.copy(alpha = 0.85f)
                val h = if (c == null) 6 else maxOf(10, (c[0] * 64 / mx))
                Box(Modifier.width(9.dp).height(h.dp).clip(RoundedCornerShape(3.dp)).background(color).clickable { onDay(k) })
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { Legend(t.good, "Done"); Legend(t.accent, "Planned"); Legend(t.bad, "Missed") }
    }
    // Chapters in this plan
    val groups = LinkedHashMap<String, IntArray>()
    val names = HashMap<String, String>()
    p.items.forEach {
        val key = it.ch.ifEmpty { it.cn.ifEmpty { it.s.ifEmpty { "x" } } }
        val g = groups.getOrPut(key) { IntArray(2) }
        g[0]++; if (it.done) g[1]++
        if (!names.containsKey(key)) names[key] = it.cn.ifEmpty { d.nodes.firstOrNull { n -> n.id == it.ch }?.n ?: (d.subjectOf(it.s)?.name ?: "Other") }
    }
    if (groups.size > 1) {
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Text("Chapters · ${groups.size}", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            groups.entries.take(40).forEach { (k, g) ->
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(names[k] ?: "", color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text("${g[1]}/${g[0]}", color = t.muted, fontSize = 12.sp)
                }
                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(t.line)) {
                    Box(Modifier.fillMaxWidth(g[1].toFloat() / g[0]).height(4.dp).clip(RoundedCornerShape(2.dp)).background(t.accent))
                }
            }
        }
    }
    // Up next
    val next = pend.sortedWith(compareBy<HwItem>({ it.d }, { it.o })).take(5)
    if (next.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        Text("Up next · ${pend.size} left", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            next.forEach { i ->
                Glass(Modifier.fillMaxWidth(), onClick = { onOpenTask(i) }) {
                    Text(d.title(i), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        (if (i.d < today) "Missed · " else "") + dayLabel(i.d) + (Planner.minutes(i, d.profile.minPerQ).takeIf { m -> m > 0 }?.let { " · " + Dates.hm(it) } ?: ""),
                        color = if (i.d < today) t.bad else t.muted, fontSize = 12.5.sp,
                    )
                }
            }
        }
    }
    if (!p.finished) {
        Spacer(Modifier.height(14.dp))
        Glass(Modifier.fillMaxWidth(), onClick = onFinishBy) { Text("Finish by a date…", color = t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
    }
    Spacer(Modifier.height(8.dp))
    Glass(Modifier.fillMaxWidth(), onClick = onDelete) {
        Text(if (deleteArmed) "Tap again to delete this plan" else "Delete plan", color = t.bad, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Stat(big: String, small: String) {
    Column {
        Text(big, color = Tk.c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(small, color = Tk.c.muted, fontSize = 11.sp)
    }
}
