package com.ascend.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.domain.AQ
import com.ascend.app.domain.At
import com.ascend.app.domain.Attempt
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.Pomo
import com.ascend.app.domain.Sess
import com.ascend.app.domain.TestRec
import com.ascend.app.domain.Tl
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId

private val BLUE = Color(0xFF0A84FF)
private val AMBER = Color(0xFFF59E0B)
private val PURPLE = Color(0xFFA259F0)

fun dayOf(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toString()

fun qt(s: Int): String = if (s < 60) "${s}s" else (s / 60).toString() + "m" + (if (s % 60 != 0) " ${s % 60}s" else "")
fun hm(s: Int): String = if (s >= 60) Pomo.hm(Math.round(s / 60.0).toInt()) else "${s}s"

@Composable
private fun stCol(s: String): Color {
    val t = Tk.c
    return when (s) { "c" -> t.good; "p" -> BLUE; "w" -> t.bad; "s" -> AMBER; else -> t.muted }
}

private fun stLab(s: String) = when (s) { "c" -> "Right"; "p" -> "Partly right"; "w" -> "Wrong"; "s" -> "Skipped"; else -> "Not reached" }

@Composable
private fun Ring(pct: Int, size: Int = 76) {
    val t = Tk.c
    val col = t.accent
    val line = t.line
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size.dp)) {
            val w = 9.dp.toPx()
            drawArc(line, 0f, 360f, false, topLeft = Offset(w / 2, w / 2), size = Size(this.size.width - w, this.size.height - w), style = Stroke(w))
            drawArc(col, -90f, 360f * pct.coerceIn(0, 100) / 100f, false, topLeft = Offset(w / 2, w / 2), size = Size(this.size.width - w, this.size.height - w), style = Stroke(w, cap = StrokeCap.Round))
        }
        Text("$pct%", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Chip(n: Int, label: String, c: Color, mod: Modifier = Modifier) {
    val t = Tk.c
    Column(mod.clip(RoundedCornerShape(16.dp)).background(c.copy(alpha = 0.14f)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(n.toString(), color = c, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = t.ink, fontSize = 11.sp)
    }
}

@Composable
private fun NavRow(title: String, sub: String, color: Color? = null, trailing: String? = null, onClick: () -> Unit) {
    val t = Tk.c
    Glass(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (color != null) Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Column(Modifier.weight(1f).padding(horizontal = if (color != null) 12.dp else 0.dp)) {
                Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(sub, color = t.muted, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (trailing != null) Text(trailing, color = t.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            else Text("›", color = t.muted, fontSize = 22.sp)
        }
    }
}

@Composable
private fun Head(label: String) {
    Text(label, color = Tk.c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp, bottom = 2.dp))
}

/** The page of one test: attempts, start buttons, and links to marking. */
@Composable
fun TestHub(
    d: DomainData, t: TestRec, yr: Int, practice: PracticeController, onPractice: () -> Unit,
    onReport: (String) -> Unit, onMarks: () -> Unit, onAnalysis: () -> Unit, onPaper: () -> Unit,
) {
    val tk = Tk.c
    var mode by rememberSaveable { mutableStateOf("e") }
    val all = At.list(d.atts, t.id)
    val full = all.filter { it.mode != "r" }
    val last = full.lastOrNull()
    val best = full.maxByOrNull { it.sc }
    val open = At.openKeys(d.atts, t.id)
    val nq = Tl.qs(t).size

    fun start(m: String, only: Set<String>?, base: String) {
        val nm = if (m == "r") t.n + " · review" else t.n + (if (full.isNotEmpty()) " · attempt ${full.size + 1}" else "")
        val dur = if (m == "e" && t.dur > 0) t.dur * 60000L else 0L
        val cfg = Sess.attemptCfg(nm, t.subs, t.secs.orEmpty(), dur, t.id, m, base, only) ?: return
        practice.open(cfg)
        onPractice()
    }

    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ring(if (last != null && last.mx != 0.0) Math.max(0, Math.round(last.sc * 100.0 / last.mx).toInt()) else 0)
            Column(Modifier.padding(start = 16.dp)) {
                Text(if (last != null) Sess.num(last.sc) + " / " + Sess.num(last.mx) else "Not attempted", color = tk.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (full.isNotEmpty()) full.size.toString() + (if (full.size == 1) " attempt" else " attempts") + (if (best != null && full.size > 1) " · best " + Sess.num(best.sc) else "")
                    else "$nq questions · " + Sess.num(Tl.max(t)) + " marks",
                    color = tk.muted, fontSize = 13.sp,
                )
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(tk.line.copy(alpha = 0.45f)).padding(3.dp)) {
        listOf("e" to ("Exam" + (if (t.dur > 0) " · " + Pomo.hm(t.dur) else "")), "p" to "Practice").forEach { (k, label) ->
            val on = mode == k
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (on) tk.accent.copy(alpha = 0.18f) else Color.Transparent).clickable { mode = k }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, color = if (on) tk.accent else tk.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
    Spacer(Modifier.height(10.dp))
    Action2(if (full.isNotEmpty()) "Attempt again" else "Start attempt", tk.accent, tk.accent) { start(mode, null, "") }
    if (last != null && open.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        NavRow("Wrong & skipped", "Attempt only the ${open.size} you have not got right", trailing = open.size.toString()) { start("r", open, last.id) }
    }
    Spacer(Modifier.height(8.dp))
    NavRow("Paper & chapters", (At.paper(d.atts, t.id)?.optJSONObject("c")?.length() ?: 0).let { if (it > 0) "$it of $nq questions tagged" else "Assign chapters to questions" }, onClick = onPaper)
    Spacer(Modifier.height(8.dp))
    NavRow("Marks & review", "Tick questions and note your result", onClick = onMarks)
    Spacer(Modifier.height(8.dp))
    NavRow("Name, number and analysis", "Status: " + Tl.STATUS[Tl.st(t)], onClick = onAnalysis)
    if (all.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Head("ATTEMPTS · ${all.size}")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            all.reversed().forEach { a ->
                val s = At.stat(a)
                val ttl = if (a.mode == "r") "Review" else "Attempt " + At.no(d.atts, a) + (if (a.mode == "p") " · Practice" else if (a.mode == "l") " · Paper" else "")
                NavRow(ttl, Tl.dl(dayOf(a.o), yr) + " · " + Sess.num(a.sc) + "/" + Sess.num(a.mx) + " · " + s.pct + "%" + (if (a.used > 0) " · " + hm(a.used) else ""), if (a.mode == "r") PURPLE else BLUE) { onReport(a.id) }
            }
        }
    }
}

private val TABS = listOf("sum" to "Summary", "sub" to "Subjects", "chp" to "Chapters", "tim" to "Time", "qs" to "Questions")

/** The report of one attempt. */
@Composable
fun AttemptReport(
    d: DomainData, t: TestRec, a: Attempt, yr: Int,
    onReason: (String, Int) -> Unit, onNote: (String, String) -> Unit, onDelete: () -> Unit, onReview: (Set<String>, String) -> Unit,
    onPaper: () -> Unit = {},
) {
    val tk = Tk.c
    var tab by rememberSaveable { mutableStateOf("sum") }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TABS.forEach { (k, l) -> Pill(l, tab == k) { tab = k } }
    }
    Spacer(Modifier.height(12.dp))
    when (tab) {
        "sum" -> SummaryTab(d, t, a, onDelete, onReview, onPaper)
        "sub" -> SubjectsTab(t, a)
        "chp" -> ChaptersTab(d, a, onPaper = { tab = "sum"; onPaper() })
        "tim" -> TimeTab(a)
        else -> QuestionsTab(a, onReason, onNote)
    }
}

@Composable
private fun SummaryTab(d: DomainData, t: TestRec, a: Attempt, onDelete: () -> Unit, onReview: (Set<String>, String) -> Unit, onPaper: () -> Unit) {
    val tk = Tk.c
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val s = At.stat(a)
    var arm by remember { mutableStateOf(false) }
    LaunchedEffect(arm) { if (arm) { delay(3000); arm = false } }
    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ring(Math.max(0, s.pct))
            Column(Modifier.padding(start = 16.dp)) {
                Text(Sess.num(a.sc) + " / " + Sess.num(a.mx), color = tk.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text((if (a.used > 0) hm(a.used) + (if (a.dur > 0) " of " + hm((a.dur / 1000).toInt()) else "") else "Untimed") + " · ${s.acc}% accuracy", color = tk.muted, fontSize = 13.sp)
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip(s.c + s.p, "Correct", tk.good, Modifier.weight(1f)); Chip(s.w, "Wrong", tk.bad, Modifier.weight(1f))
        Chip(s.s, "Skipped", AMBER, Modifier.weight(1f)); Chip(s.u, "Left", tk.muted, Modifier.weight(1f))
    }
    val lb = At.lostBy(a)
    val tot = lb.values.sum()
    if (tot > 0) {
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Row { Text("Marks lost", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(Sess.num(Math.round(tot * 100) / 100.0) + " of " + Sess.num(a.mx), color = tk.muted, fontSize = 13.sp) }
            Spacer(Modifier.height(8.dp))
            val rows = At.RM.map { Triple(it.first, it.second, lb[it.first] ?: 0.0) } + Triple(0, "Not tagged", lb[0] ?: 0.0)
            rows.filter { it.third > 0 }.forEach { (k, name, v) ->
                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = if (k == 0) tk.muted else tk.ink, fontSize = 13.sp, modifier = Modifier.width(86.dp))
                    Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(tk.line)) {
                        Box(Modifier.fillMaxWidth((v / tot).toFloat().coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(4.dp)).background(if (k == 0) tk.muted else tk.accent))
                    }
                    Text(Sess.num(Math.round(v * 100) / 100.0), color = tk.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(44.dp), textAlign = TextAlign.End)
                }
            }
            if ((lb[0] ?: 0.0) > 0) Text("Open the Questions tab to tag the reasons.", color = tk.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    if (s.fa + s.sa > 0) {
        val fp = if (s.fa > 0) Math.round(s.fc * 100.0 / s.fa).toInt() else 0
        val sp = if (s.sa > 0) Math.round(s.sc2 * 100.0 / s.sa).toInt() else 0
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Text("First look vs coming back", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) { Text("First look", color = tk.muted, fontSize = 12.sp); Text("$fp%", color = tk.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("${s.fc} of ${s.fa} right", color = tk.muted, fontSize = 12.sp) }
                Column(Modifier.weight(1f)) { Text("On return", color = tk.muted, fontSize = 12.sp); Text(if (s.sa > 0) "$sp%" else "–", color = tk.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(if (s.sa > 0) "${s.sc2} of ${s.sa} right" else "none", color = tk.muted, fontSize = 12.sp) }
            }
            if (s.sa >= 3 && sp + 15 < fp) Text("Questions you left and came back to were right less often. Skipping them for good may save time.", color = tk.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            else if (s.sa >= 3 && sp > fp + 10) Text("Coming back paid off: you solved more on the second look.", color = tk.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
    val pv = At.list(d.atts, a.tid).filter { it.mode != "r" && it.o < a.o }.lastOrNull().takeIf { a.mode != "r" }
    if (pv != null) {
        val ps = At.stat(pv)
        val pm = pv.q.associate { it.key to it.state }
        var up = 0; var dn = 0
        a.q.forEach { e -> val p = pm[e.key] ?: return@forEach; val g = { x: String -> x == "c" || x == "p" }; if (g(e.state) && !g(p)) up++ else if (!g(e.state) && g(p)) dn++ }
        val dsc = a.sc - pv.sc
        val dt = a.used - pv.used
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Text("Against attempt " + At.no(d.atts, pv), color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { Text((if (dsc >= 0) "+" else "−") + Sess.num(Math.abs(dsc)), color = if (dsc >= 0) tk.good else tk.bad, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("marks", color = tk.muted, fontSize = 12.sp) }
                Column(Modifier.weight(1f)) { val da = s.acc - ps.acc; Text((if (da >= 0) "+" else "−") + Math.abs(da) + "%", color = if (da >= 0) tk.good else tk.bad, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("accuracy", color = tk.muted, fontSize = 12.sp) }
                Column(Modifier.weight(1f)) { Text((if (dt <= 0) "−" else "+") + hm(Math.abs(dt)), color = tk.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("time", color = tk.muted, fontSize = 12.sp) }
            }
            Text("$up questions improved" + (if (dn > 0) ", $dn got worse" else "") + ".", color = tk.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    val openQ = a.q.filter { it.state == "w" || it.state == "s" || it.state == "u" }
    Spacer(Modifier.height(14.dp))
    if (openQ.isNotEmpty()) {
        NavRow("Attempt wrong & skipped", "${openQ.size} questions, untimed") { onReview(openQ.map { it.key }.toSet(), a.id) }
        Spacer(Modifier.height(8.dp))
    }
    NavRow("Share report", "Send the score, marks lost and chapters as text") {
        val txt = At.reportText(a, t.n, Tl.dl(dayOf(a.o), java.time.LocalDate.now().year), { chapterNode(d, it)?.n }, d.atts)
        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Report – " + t.n)
            putExtra(android.content.Intent.EXTRA_TEXT, txt)
        }
        ctx.startActivity(android.content.Intent.createChooser(send, "Share report"))
    }
    Spacer(Modifier.height(8.dp))
    NavRow("Tag chapters", "Unlock the chapter analysis", onClick = onPaper)
    Spacer(Modifier.height(8.dp))
    Action2(if (arm) "Tap again to delete this attempt" else "Delete attempt", tk.bad) { if (arm) onDelete() else arm = true }
}

@Composable
private fun ChaptersTab(d: DomainData, a: Attempt, onPaper: () -> Unit) {
    val tk = Tk.c
    val (rows, un) = At.chaptersOf(d.atts, a) { chapterNode(d, it) != null }
    if (rows.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Text("No chapters yet", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Tag each question with its chapter and this report shows where marks were won and lost.", color = tk.muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Action2("Tag chapters", tk.accent, tk.accent, onPaper)
        }
        return
    }
    Glass(Modifier.fillMaxWidth()) {
        Row { Text("Chapters", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text("${rows.size} · weakest first", color = tk.muted, fontSize = 13.sp) }
        rows.forEach { o ->
            val col = if (o.att == 0) tk.muted else if (o.acc < 40) tk.bad else if (o.acc < 70) AMBER else tk.good
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(col))
                Text(chapterNode(d, o.id)?.n ?: "Chapter", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (o.att > 0) "${o.acc}%" else "–", color = col, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(tk.line)) { Box(Modifier.fillMaxWidth(if (o.att > 0) o.acc / 100f else 0f).height(5.dp).clip(RoundedCornerShape(3.dp)).background(col)) }
            Text(o.n.toString() + (if (o.n == 1) " question" else " questions") + " · ${o.c} right · ${o.w} wrong · ${o.s} skipped" + (if (o.lost > 0) " · −" + Sess.num(Math.round(o.lost * 100) / 100.0) else ""), color = tk.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
    if (un > 0) {
        Text("$un questions have no chapter yet.", color = tk.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.height(6.dp))
        Pill("Tag them", true, onPaper)
    }
}

@Composable
private fun SubjectsTab(t: TestRec, a: Attempt) {
    val tk = Tk.c
    val ns = Math.max(1, a.subs.size)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (si in 0 until ns) {
            val e = a.q.filter { it.sub == si }
            val sc = e.sumOf { it.m }; val mx = e.sumOf { it.pos }; val tm = e.sumOf { it.t }
            val c = e.count { it.good }; val w = e.count { it.state == "w" }; val s = e.count { it.state == "s" }
            val pct = if (mx != 0.0) Math.max(0, Math.round(sc * 100 / mx).toInt()) else 0
            val col = Color(DomainDataColors[si % DomainDataColors.size])
            Glass(Modifier.fillMaxWidth()) {
                Row { Text(a.subs.getOrNull(si) ?: t.subs.getOrNull(si) ?: "Questions", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(Sess.num(sc) + " / " + Sess.num(mx), color = tk.muted, fontSize = 13.sp) }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(tk.line)) { Box(Modifier.fillMaxWidth(pct / 100f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(col)) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip(c, "Correct", tk.good, Modifier.weight(1f)); Chip(w, "Wrong", tk.bad, Modifier.weight(1f)); Chip(s, "Skipped", AMBER, Modifier.weight(1f)) }
                Text(hm(tm) + " spent · " + (if (e.isNotEmpty()) qt(Math.round(tm.toDouble() / e.size).toInt()) else "–") + " per question", color = tk.muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 8.dp))
                val secs = e.groupBy { it.sec }
                if (secs.size > 1) secs.toSortedMap().forEach { (k, l) ->
                    val m2 = l.sumOf { it.m }; val x2 = l.sumOf { it.pos }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(a.secs.getOrNull(k)?.ifEmpty { null } ?: "Section ${k + 1}", color = tk.ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(Sess.num(m2) + "/" + Sess.num(x2), color = tk.muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

private val DomainDataColors = DomainData.COLORS

@Composable
private fun TimeTab(a: Attempt) {
    val tk = Tk.c
    val e = a.q
    val tm = e.sumOf { it.t }
    if (tm == 0) {
        Glass(Modifier.fillMaxWidth()) {
            Text("No time per question", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Only the total time is known for this attempt.", color = tk.muted, fontSize = 13.sp)
        }
        return
    }
    val cn = e.count { it.good }; val wn = e.count { it.state == "w" }
    val ct = e.filter { it.good }.sumOf { it.t }; val wt = e.filter { it.state == "w" }.sumOf { it.t }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(hm(tm) to "total", qt(Math.round(tm.toDouble() / e.size).toInt()) to "per question", (if (cn > 0) qt(Math.round(ct.toDouble() / cn).toInt()) else "–") to "when right", (if (wn > 0) qt(Math.round(wt.toDouble() / wn).toInt()) else "–") to "when wrong").forEach { (v, l) ->
            Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tk.line.copy(alpha = 0.4f)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(v, color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1); Text(l, color = tk.muted, fontSize = 10.5.sp, maxLines = 1)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    val mx = Math.max(1, e.maxOf { it.t })
    Glass(Modifier.fillMaxWidth()) {
        Text("Time on each question", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(96.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
            e.forEach { q ->
                Box(Modifier.width(8.dp).height(Math.max(4, 96 * q.t / mx).dp).clip(RoundedCornerShape(3.dp)).background(stCol(q.state)))
            }
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("c" to "Right", "w" to "Wrong", "s" to "Skipped").forEach { (k, l) ->
                Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(stCol(k))); Text(" $l", color = tk.muted, fontSize = 12.sp) }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth()) {
        Text("Took the longest", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        e.sortedByDescending { it.t }.take(5).forEach { q ->
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(stCol(q.state)))
                Text("  Q${q.no}" + (if (a.subs.size > 1) " · " + a.subs.getOrNull(q.sub) else ""), color = tk.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(stLab(q.state) + " · " + qt(q.t), color = tk.muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun QuestionsTab(a: Attempt, onReason: (String, Int) -> Unit, onNote: (String, String) -> Unit) {
    val tk = Tk.c
    var flt by rememberSaveable { mutableStateOf("all") }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("all" to "All", "w" to "Wrong", "s" to "Skipped", "nt" to "Not tagged").forEach { (k, l) -> Pill(l, flt == k) { flt = k } }
    }
    Spacer(Modifier.height(10.dp))
    val shown = a.q.filter { e ->
        val x = e.state; val rm = a.rm(e.key)
        when (flt) { "w" -> x == "w"; "s" -> x == "s" || x == "u"; "nt" -> rm == 0 && (x == "w" || x == "s"); else -> true }
    }
    if (shown.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) { Text("Nothing here", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold); Text("No question matches this filter.", color = tk.muted, fontSize = 13.sp) }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        shown.forEach { e ->
            val k = e.key
            val x = e.state
            val col = stCol(x)
            val rm = a.rm(k)
            val isOpen = open == k
            Glass(Modifier.fillMaxWidth(), onClick = { open = if (isOpen) null else k }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(col.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Text("${e.no}", color = col, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(stLab(x) + (if (x == "w" && e.neg != 0.0) " · −" + Sess.num(e.neg) else "") + (if (e.good) " · +" + Sess.num(e.m) else ""), color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text((if (a.subs.size > 1) (a.subs.getOrNull(e.sub) ?: "") + " · " else "") + qt(e.t), color = tk.muted, fontSize = 12.5.sp)
                    }
                    if (rm != 0) Text(At.RM.filter { rm and it.first != 0 }.joinToString(" ") { it.second.take(3) }, color = tk.accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                if (isOpen) {
                    var note by remember(k) { mutableStateOf(a.nt(k)) }
                    LaunchedEffect(note) { delay(600); if (note.trim().take(140) != a.nt(k)) onNote(k, note) }
                    Spacer(Modifier.height(10.dp))
                    Field(note, { note = it.take(140) }, "Why did this happen? One line", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        At.RM.forEach { (bit, name) -> Pill(name, rm and bit != 0) { onReason(k, bit) } }
                    }
                }
            }
        }
    }
}
