package com.ascend.app.practice

import com.ascend.app.data.Store
import com.ascend.app.domain.Cfg
import com.ascend.app.domain.Domain
import com.ascend.app.domain.HwItem
import com.ascend.app.domain.Live
import com.ascend.app.domain.Ranges
import com.ascend.app.domain.Sess
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Runs one practice session at a time. All the rules live in [Sess]; this class only holds the current state,
 * keeps the clock ticking, and saves: a draft every few seconds while you work, the finished session on the end.
 */
class PracticeController(private val store: Store, private val domain: Domain) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _live = MutableStateFlow<Live?>(null)
    val live: StateFlow<Live?> = _live
    private var ticker: Job? = null
    private var saveJob: Job? = null
    private var lastDraft = 0L

    companion object {
        const val KEY_MARKS = "marks"
    }

    private fun now() = System.currentTimeMillis()
    private fun newId() = "s" + java.lang.Long.toString(now(), 36) + java.lang.Long.toString((Math.random() * 1679616).toLong() + 46656, 36).takeLast(4)

    /** The marks last used (correct, wrong), default +4 / -1. */
    suspend fun marks(): Pair<Double, Double> {
        val j = try { org.json.JSONObject(store.get(KEY_MARKS) ?: "") } catch (e: Exception) { null }
        val p = j?.optDouble("pos", 4.0) ?: 4.0
        val n = j?.optDouble("neg", 1.0) ?: 1.0
        return (if (p >= 0) p else 4.0) to (if (n >= 0) n else 1.0)
    }

    fun rememberMarks(pos: Double, neg: Double) {
        scope.launch { store.put(KEY_MARKS, org.json.JSONObject().put("pos", pos).put("neg", neg).toString()) }
    }

    /** Opens the "ready" screen for a new session. */
    private val _report = MutableStateFlow<Pair<String, String>?>(null)
    /** Set when a finished test attempt should open its report on the Tests screen: (test id, attempt id). */
    val report: StateFlow<Pair<String, String>?> = _report
    fun showReport(tid: String, aid: String) { _report.value = tid to aid }
    fun reportShown() { _report.value = null }

    fun open(cfg: Cfg) {
        if (_live.value?.running == true) return
        _live.value = Sess.launch(cfg, now(), newId())
    }

    /** Opens a session for a planned task: the questions still to do, or all of them. */
    fun openTask(item: HwItem, name: String, marks: Pair<Double, Double>) {
        val all = Ranges.numbers(item.rg)
        if (all.isEmpty()) return
        val left = domain.taskLeft(item)
        val list = if (!item.done && left.isNotEmpty() && left.size < all.size) left else all
        open(Sess.hwCfgList(name, list, marks.first, marks.second, item.id))
    }

    fun resume(d: Sess.Draft) {
        if (_live.value?.running == true) return
        _live.value = Sess.resume(d, now())
        startTicker()
    }

    /** Shows the result of a saved session. */
    fun view(l: Live) {
        if (_live.value?.running == true) return
        _live.value = l
    }

    fun begin() {
        val l = _live.value ?: return
        if (!l.ready) return
        _live.value = Sess.begin(l, now())
        saveDraftSoon(true)
        startTicker()
    }

    fun answer(st: String) {
        val l = _live.value ?: return
        val n = Sess.answer(l, st, now())
        if (n === l) return
        _live.value = n
        if (n.ended) finished(n) else saveDraftSoon(true)
    }

    fun jump(i: Int) {
        val l = _live.value ?: return
        val n = Sess.jump(l, i, now())
        if (n === l) return
        _live.value = n
        saveDraftSoon(true)
    }

    fun togglePause() {
        val l = _live.value ?: return
        _live.value = Sess.setPaused(l, !l.paused, now())
    }

    fun finish() {
        val l = _live.value ?: return
        if (!l.running) return
        val n = Sess.end(l, now())
        _live.value = n
        finished(n)
    }

    /** "Save and go back": keeps the answers as a draft and the progress on the task, then closes the screen. */
    fun leaveAndSave() {
        val l = _live.value ?: return
        if (!l.running) { close(); return }
        scope.launch {
            val c = Sess.end(l, now()).copy(running = true, ended = false)   // only to commit the open question's time
            val draft = Sess.draftJson(l.copy(res = c.res), now())
            domain.saveDraft(draft)
            if (l.cfg.hw.isNotEmpty() && !l.cfg.test) domain.sessionDone(l.cfg.hw, got(l), finish = false)
        }
        _live.value = null
    }

    /** Closes the ready screen or the result and returns to the setup page. */
    fun close() {
        val l = _live.value ?: return
        if (l.running) return
        _live.value = null
    }

    fun toggleDoubt(i: Int) = edit { Sess.toggleDoubt(it, i) }
    fun cycleMark(i: Int) = edit { Sess.cycleMark(it, i) }

    private fun edit(f: (Live) -> Live) {
        val l = _live.value ?: return
        if (!l.ended) return
        val n = f(l)
        _live.value = n
        saveJob?.cancel()
        saveJob = scope.launch { delay(300); domain.saveSession(n.cfg.id, Sess.recordJson(n, now())); domain.syncAttempt(n.cfg, n.res, n.testUsed) }
    }

    private fun got(l: Live): List<Int> = l.res.mapIndexedNotNull { i, r -> if (r?.st == "A") l.q[i].no else null }

    private fun finished(l: Live) {
        scope.launch {
            domain.saveSession(l.cfg.id, Sess.recordJson(l, now()))
            domain.syncAttempt(l.cfg, l.res, l.testUsed)
            domain.clearDraft()
            if (l.cfg.hw.isNotEmpty() && !l.cfg.test) domain.sessionDone(l.cfg.hw, got(l))
        }
    }

    private fun saveDraftSoon(force: Boolean) {
        val l = _live.value ?: return
        if (!l.running || l.ended) return
        val t = now()
        if (!force && t - lastDraft < 10_000) return
        lastDraft = t
        scope.launch { domain.saveDraft(Sess.draftJson(l, t)) }
    }

    /** Called when the app goes to the background. */
    fun saveNow() = saveDraftSoon(true)

    private fun startTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (_live.value?.running == true) {
                val l = _live.value ?: break
                if (Sess.timeUp(l, now())) {
                    val n = Sess.end(l, now())
                    _live.value = n
                    finished(n)
                    break
                }
                saveDraftSoon(false)
                delay(250)
            }
        }
    }
}
