package com.ascend.app.domain

import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/** Focus timer settings, same defaults and limits as the web app. */
data class PomoSettings(
    val f: Int = 25, val s: Int = 5, val l: Int = 15, val e: Int = 4,
    val auto: Boolean = false, val snd: Boolean = true, val vib: Boolean = true, val wake: Boolean = true,
) {
    fun toJson(): String = JSONObject().put("f", f).put("s", s).put("l", l).put("e", e)
        .put("auto", auto).put("snd", snd).put("vib", vib).put("wake", wake).toString()

    fun bump(field: String, dir: Int): PomoSettings = when (field) {
        "f" -> copy(f = (f + 5 * dir).coerceIn(5, 180))
        "s" -> copy(s = (s + dir).coerceIn(1, 60))
        "l" -> copy(l = (l + 5 * dir).coerceIn(5, 90))
        else -> copy(e = (e + dir).coerceIn(1, 8))
    }

    companion object {
        fun parse(text: String?): PomoSettings {
            val d = PomoSettings()
            val j = try { JSONObject(text ?: "") } catch (x: Exception) { return d }
            return PomoSettings(
                f = j.optInt("f", d.f).coerceIn(5, 180), s = j.optInt("s", d.s).coerceIn(1, 60),
                l = j.optInt("l", d.l).coerceIn(5, 90), e = j.optInt("e", d.e).coerceIn(1, 8),
                auto = j.optBoolean("auto", d.auto), snd = j.optBoolean("snd", d.snd),
                vib = j.optBoolean("vib", d.vib), wake = j.optBoolean("wake", d.wake),
            )
        }
    }
}

/** One saved focus session, the same entry the web app keeps in the revision log under key "pm:<id>". */
data class FocusEntry(val key: String, val d: String, val t: Long, val m: Int, val b: Int, val lab: String, val f: Int, val u: Long) {
    fun toJson(): JSONObject = JSONObject().put("pm", 1).put("d", d).put("t", t).put("m", m).put("b", b).put("lab", lab).put("f", f).put("u", u)

    companion object {
        fun from(key: String, j: JSONObject): FocusEntry? {
            if (j.optInt("pm", 0) == 0 || Merge.isX(j)) return null
            return FocusEntry(key, j.optString("d"), j.optLong("t", 0), j.optInt("m", 0), j.optInt("b", 0), j.optString("lab"), j.optInt("f", 25), j.optLong("u", 0))
        }
    }
}

/** The running timer. Kept as plain data so it can be saved, restored after the app is killed, and tested. */
data class PomoRun(
    val ph: String = "idle", val run: Boolean = false, val end: Long = 0, val left: Long = 0, val tot: Long = 0,
    val n: Int = 0, val done: Int = 0, val wait: Boolean = false, val lab: String = "", val id: String = "", val ts: Long = 0,
    val hw: String = "", val sm: Int = 0, val cel: Int = 0, val cm: Int = 0, val cq: Int = 0,
    val am: Int = -1, val ab: Int = 0, val le: Int = -1,
) {
    val idle get() = ph == "idle"

    fun toJson(): String = JSONObject().put("ph", ph).put("run", run).put("end", end).put("left", left).put("tot", tot)
        .put("n", n).put("done", done).put("wait", wait).put("lab", lab).put("id", id).put("ts", ts).put("hw", hw)
        .put("sm", sm).put("cel", cel).put("cm", cm).put("cq", cq).put("am", am).put("ab", ab).put("le", le).toString()

    companion object {
        fun parse(text: String?): PomoRun {
            val j = try { JSONObject(text ?: "") } catch (x: Exception) { return PomoRun() }
            val ph = j.optString("ph", "idle")
            if (ph !in listOf("focus", "short", "long")) return PomoRun()
            return PomoRun(
                ph, j.optBoolean("run"), j.optLong("end"), j.optLong("left"), j.optLong("tot"), j.optInt("n"), j.optInt("done"),
                j.optBoolean("wait"), j.optString("lab"), j.optString("id"), j.optLong("ts"), j.optString("hw"), j.optInt("sm"),
                j.optInt("cel"), j.optInt("cm"), j.optInt("cq"), j.optInt("am", -1), j.optInt("ab"), j.optInt("le", -1),
            )
        }
    }
}

/** What one step of the timer produced: the new state, a session entry to save (if any), and a message to announce. */
data class PomoStep(val run: PomoRun, val entry: FocusEntry? = null, val alert: String? = null)

object Pomo {
    fun len(s: PomoSettings, ph: String): Long = (if (ph == "focus") s.f else if (ph == "short") s.s else s.l) * 60000L
    fun left(r: PomoRun, now: Long): Long = if (r.run) maxOf(0L, r.end - now) else r.left

    fun fmt(ms: Long): String {
        val s = maxOf(0L, (ms + 999) / 1000)
        val m = s / 60
        return (if (m < 10) "0" else "") + m + ":" + (if (s % 60 < 10) "0" else "") + s % 60
    }

    fun hm(m: Int): String = if (m >= 60) (m / 60).toString() + "h " + (if (m % 60 != 0) (m % 60).toString() + "m" else "") else "$m min"

    fun dayKey(ts: Long, zone: ZoneId): String = Instant.ofEpochMilli(ts).atZone(zone).toLocalDate().toString()

    /** Starts a fresh session: first focus block. */
    fun start(label: String, hw: String, id: String, s: PomoSettings, now: Long): PomoRun =
        begin(PomoRun(lab = label.trim().take(40), id = id, ts = now, hw = hw), "focus", s, now)

    fun begin(r: PomoRun, ph: String, s: PomoSettings, now: Long): PomoRun {
        val tot = len(s, ph)
        return r.copy(ph = ph, tot = tot, left = tot, run = true, end = now + tot, wait = false, cel = 0, le = -1)
    }

    /** Saves minutes into the session entry. [live] = the block is still running, so the minutes are added on top, not kept. */
    fun add(r: PomoRun, s: PomoSettings, old: FocusEntry?, min: Int, blk: Int, live: Boolean, now: Long, zone: ZoneId): Pair<PomoRun, FocusEntry?> {
        if (!live && !(min > 0 || blk > 0)) return r to null
        var x = r
        if (x.id.isEmpty()) x = x.copy(id = java.lang.Long.toString(now, 36), ts = now, am = 0, ab = 0)
        if (x.am < 0) x = x.copy(am = old?.m ?: 0, ab = old?.b ?: 0)
        if (!live) x = x.copy(am = x.am + min, ab = x.ab + blk)
        val m = x.am + (if (live) min else 0)
        val b = x.ab
        if (!(m > 0 || b > 0)) return x to null
        return x to FocusEntry("pm:" + x.id, dayKey(x.ts, zone), x.ts, m, b, x.lab, s.f, now)
    }

    /** Keeps the minutes of the running focus block saved as they pass. */
    fun live(r: PomoRun, s: PomoSettings, old: FocusEntry?, now: Long, zone: ZoneId, force: Boolean): PomoStep {
        if (r.ph != "focus" || r.wait || r.tot <= 0) return PomoStep(r)
        val el = ((r.tot - left(r, now)) / 60000L).toInt()
        if (el <= 0) return PomoStep(r)
        if (el == r.le && !force) return PomoStep(r)
        val (x, e) = add(r.copy(le = el), s, old, el, 0, true, now, zone)
        return PomoStep(x, e)
    }

    /** Play / pause / "start next phase" button. */
    fun toggle(r: PomoRun, s: PomoSettings, now: Long): PomoRun = when {
        r.idle -> r
        r.wait -> begin(r, r.ph, s, now)
        r.run -> r.copy(left = maxOf(0L, r.end - now), run = false)
        else -> r.copy(run = true, end = now + r.left)
    }

    /** A phase finished by itself ([full]) or was skipped. [q] picks the encouragement line shown on the finish page. */
    fun end(r0: PomoRun, s: PomoSettings, old: FocusEntry?, full: Boolean, now: Long, zone: ZoneId, q: Int): PomoStep {
        var r = r0.copy(le = -1)
        val el = Math.round((r.tot - left(r, now)) / 60000.0).toInt()
        val was = r.ph
        var entry: FocusEntry? = null
        if (was == "focus") {
            val (x, e) = if (full) add(r, s, old, s.f, 1, false, now, zone) else add(r, s, old, el, 0, false, now, zone)
            r = x
            entry = e
            if (full) r = r.copy(n = r.n + 1, done = r.done + 1)
        }
        val nx = if (was == "focus") (if (r.n >= s.e) "long" else "short") else "focus"
        if (was == "long") r = r.copy(n = 0)
        var alert: String? = null
        if (was == "focus") {
            r = r.copy(sm = r.sm + (if (full) s.f else el))
            if (full) {
                r = r.copy(cel = if (r.n >= s.e) 2 else 1, cm = s.f, cq = q)
            }
        }
        if (full) {
            alert = if (was == "focus") (if (r.cel == 2) "Session complete. Well done." else if (nx == "long") "Block done. Time for a long break." else "Block done. Take a short break.")
            else "Break over. Ready to focus?"
        }
        if (full && s.auto && was != "focus") return PomoStep(begin(r, nx, s, now), entry, alert)
        val tot = len(s, nx)
        return PomoStep(r.copy(ph = nx, tot = tot, left = tot, run = false, wait = true), entry, alert)
    }

    /** Ends the whole session from the stop button; saves the partly done focus block. */
    fun stop(r: PomoRun, s: PomoSettings, old: FocusEntry?, now: Long, zone: ZoneId): PomoStep {
        if (r.ph == "focus" && !r.wait) {
            val el = Math.round((r.tot - left(r, now)) / 60000.0).toInt()
            val (_, e) = add(r, s, old, el, 0, false, now, zone)
            return PomoStep(PomoRun(), e)
        }
        return PomoStep(PomoRun())
    }

    /** True when the running phase has reached its end. */
    fun due(r: PomoRun, now: Long) = r.run && r.end - now <= 0

    data class Totals(val m: Int, val b: Int)

    /** Today and last 7 days totals from saved sessions. */
    fun totals(list: Collection<FocusEntry>, today: String, now: Long): Pair<Totals, Totals> {
        var tm = 0; var tb = 0; var wm = 0; var wb = 0
        val lim = now - 6 * 86400000L
        for (x in list) {
            if (x.d == today) { tm += x.m; tb += x.b }
            if (x.t >= lim - 86400000L) { wm += x.m; wb += x.b }
        }
        return Totals(tm, tb) to Totals(wm, wb)
    }

    /** "Your longest session yet", "Your best focus day", "N days in a row" (at most two). */
    fun pills(list: Collection<FocusEntry>, r: PomoRun, today: String): List<String> {
        val by = HashMap<String, Int>()
        var mx = 0
        val cur = if (r.id.isNotEmpty()) "pm:" + r.id else ""
        for (e in list) {
            by[e.d] = (by[e.d] ?: 0) + e.m
            if (e.key != cur && e.m > mx) mx = e.m
        }
        var best = 0
        for ((d, v) in by) if (d != today && v > best) best = v
        var st = 0
        var d = today
        while ((by[d] ?: 0) > 0 && st < 400) { st++; d = Dates.add(d, -1) }
        val out = ArrayList<String>()
        if (mx > 0 && r.sm > mx) out.add("Your longest session yet")
        if (best > 0 && (by[today] ?: 0) > best) out.add("Your best focus day")
        if (st >= 2) out.add("$st days in a row")
        return out.take(2)
    }

    val QUOTES = listOf(
        "One focused hour beats three scattered ones.", "Small steps, taken daily, build rank-holders.",
        "Do the next question. Nothing else matters now.", "Discipline is remembering what you want.",
        "Your future self is watching this block.", "Start before you feel ready.",
        "Every solved problem makes the next one lighter.", "Be stubborn about the goal, flexible about the method.",
        "Mistakes are marks you haven't earned yet.", "Slow progress is still progress.",
        "The exam rewards consistency, not heroics.", "Today's effort is tomorrow's confidence.",
        "Switch off the noise. Switch on the question.", "You don't need motivation. You need the next step.",
    )
}
