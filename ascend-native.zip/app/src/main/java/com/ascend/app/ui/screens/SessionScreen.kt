package com.ascend.app.ui.screens

import android.content.Intent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Live
import com.ascend.app.domain.Sess
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.delay

@Composable
fun SessionScreen(practice: PracticeController, domain: Domain, l: Live, onHome: () -> Unit, onTests: () -> Unit = {}) {
    if (l.ended) ResultView(practice, l, onHome, onTests) else RunView(practice, l)
}

@Composable
private fun RunView(practice: PracticeController, l: Live) {
    val t = Tk.c
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(l.running, l.paused) { while (l.running && !l.paused) { now = System.currentTimeMillis(); delay(100) } }
    var leave by remember { mutableStateOf(false) }
    var arm by remember { mutableStateOf(false) }
    LaunchedEffect(arm) { if (arm) { delay(3000); arm = false } }
    var vs by remember { mutableStateOf(l.vs) }
    LaunchedEffect(l.idx) { vs = l.q[l.idx].sub }
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(l.running) {
        if (l.running) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    BackHandler { if (l.running) leave = true else practice.close() }

    val T = l.cfg.test
    val el = if (l.running) l.elapsed(now) else 0L
    val q = l.q[l.idx]
    val a = l.res.count { it?.st == "A" }
    val s = l.res.count { it?.st == "N" }
    val multi = l.cfg.subs.size > 1

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp).navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!l.running) Text("‹", color = t.ink, fontSize = 30.sp, modifier = Modifier.clip(CircleShape).clickable { practice.close() }.padding(end = 14.dp, top = 2.dp, bottom = 2.dp, start = 4.dp))
            Text(l.cfg.name, color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (T && l.running) {
                val left = Sess.testLeft(l, now)
                val low = left != null && left <= l.cfg.dur / 10
                Text(
                    if (left != null) Sess.fmt(maxOf(0L, (left + 999) / 1000 * 1000)) else Sess.fmt(now - l.testStart),
                    color = if (low) t.bad else t.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                )
            }
        }
        if (multi) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                l.cfg.subs.forEachIndexed { k, name ->
                    val tot = l.q.count { it.sub == k }
                    val dn = l.q.indices.count { l.q[it].sub == k && l.res[it]?.st != null }
                    val on = k == vs
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else t.line.copy(alpha = 0.5f))
                            .clickable { vs = k }.padding(horizontal = 14.dp, vertical = 8.dp),
                    ) { Text("$name  $dn/$tot", color = if (on) t.accent else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (l.running) "Q ${q.no} · ${l.idx + 1} of ${l.n}" else "${l.n} questions",
            color = t.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        )
        if (T && l.running) Text(
            Sess.qLabel(l, l.idx) + " · " + (l.cfg.secs.getOrNull(q.sec)?.name?.ifEmpty { null } ?: "Section ${q.sec + 1}") + " · " + Sess.sg(q.pos) + " / " + Sess.ng(q.neg),
            color = t.muted, fontSize = 13.sp,
        )
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 10.dp.toPx(); val inset = w / 2
                    val sz = Size(size.width - w, size.height - w)
                    drawArc(t.line, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
                    val p = ((el % 60000L) / 60000f)
                    if (l.running && p > 0.004f) drawArc(if (l.paused) t.muted else t.accent, -90f, 360f * p, false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Sess.fmt(el), color = if (l.paused) t.muted else t.ink, fontSize = 46.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (!l.running) "Ready when you are" else if (l.paused) "Paused" else l.res[l.idx].let { r -> if (r?.st != null) "Revisiting" else if ((r?.t ?: 0) > 0) "Continuing" else "Solving…" },
                        color = t.muted, fontSize = 13.sp,
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat3(a.toString(), "Attempted")
                Stat3(s.toString(), "Skipped")
                if (T) Stat3((l.n - a - s).toString(), "Left") else Stat3(Sess.num(Sess.score(l)), "Score")
            }
        }
        Spacer(Modifier.height(12.dp))
        if (!l.running) {
            Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { practice.begin() }) {
                Text("Start", color = t.accent, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Glass(Modifier.weight(1f), tint = t.good, onClick = { practice.answer("A") }) {
                    Text("Attempted", color = t.good, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
                Glass(Modifier.weight(1f), onClick = { practice.answer("N") }) {
                    Text("Not attempted", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Glass(Modifier.weight(1f), onClick = { practice.togglePause() }) {
                    Text(if (l.paused) "Resume" else "Pause", color = t.accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
                Glass(Modifier.weight(1f), onClick = { if (arm) { arm = false; practice.finish() } else arm = true }) {
                    Text(if (arm) "Tap again to finish" else "Finish", color = t.bad, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        // Question palette: 7 per row for the questions of the open subject.
        val idxs = l.q.indices.filter { l.q[it].sub == vs }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            idxs.chunked(7).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { i ->
                        val r = l.res[i]
                        val cur = i == l.idx && l.running
                        val bg = when {
                            r?.st == "A" -> t.good.copy(alpha = 0.28f)
                            r?.st == "N" -> t.muted.copy(alpha = 0.25f)
                            (r?.t ?: 0) > 0 -> t.accent.copy(alpha = 0.12f)
                            else -> t.line.copy(alpha = 0.5f)
                        }
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(bg)
                                .border(if (cur) 2.dp else 0.dp, if (cur) t.accent else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable(enabled = l.running) { practice.jump(i) },
                            contentAlignment = Alignment.Center,
                        ) { Text("${l.q[i].no}", color = t.ink, fontSize = 14.sp, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium) }
                    }
                    repeat(7 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
    if (leave) {
        AlertDialog(
            onDismissRequest = { leave = false },
            title = { Text("Leave this session?") },
            text = { Text("Your answers are kept. Save it to carry on later from the task or Practice.") },
            confirmButton = { TextButton(onClick = { leave = false }) { Text("Continue session") } },
            dismissButton = { TextButton(onClick = { leave = false; practice.leaveAndSave() }) { Text("Save and go back") } },
        )
    }
}

@Composable
private fun Stat3(big: String, small: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(big, color = Tk.c.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(small, color = Tk.c.muted, fontSize = 11.sp)
    }
}

@Composable
private fun Box2(label: String, big: String, small: String, modifier: Modifier) {
    val t = Tk.c
    Glass(modifier) {
        Text(label, color = t.muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Text(big, color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (small.isNotEmpty()) Text(small, color = t.muted, fontSize = 11.5.sp, maxLines = 2)
    }
}

@Composable
private fun ResultView(practice: PracticeController, l: Live, onHome: () -> Unit, onTests: () -> Unit) {
    val t = Tk.c
    val ctx = LocalContext.current
    BackHandler { practice.close() }
    val o = Sess.calc(l)
    val T = l.cfg.test
    val multi = l.cfg.subs.size > 1
    val acc = if (o.att > 0) Math.round(o.cor * 100.0 / o.att).toString() + "%" else "—"
    fun lab(i: Int) = if (multi) l.cfg.subs.getOrElse(l.q[i].sub) { "" }.take(2) + "·" + l.q[i].no else "Q" + l.q[i].no

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp).navigationBarsPadding()) {
        Text(if (T) "Test complete" else "Session complete", color = t.muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(l.cfg.name, color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(Sess.num(o.score), color = t.accent, fontSize = 56.sp, fontWeight = FontWeight.Bold)
        Text("out of " + Sess.num(Sess.maxMarks(l)) + " marks", color = t.muted, fontSize = 14.sp)
        Spacer(Modifier.height(14.dp))
        val boxes = listOf(
            Triple("Attempted", o.att.toString(), "${o.cor} correct · ${o.wr} wrong" + (if (o.pt > 0) " · ${o.pt} partial" else "")),
            Triple("Not attempted", o.sk.toString(), ""),
            Triple("Total time", Sess.fmt(if (T) l.testUsed else o.tot), ""),
            Triple("Avg / question", if (o.vis > 0) Sess.fmt(o.avg) else "—", if (o.vis > 0) "over ${o.vis} answered" else ""),
            Triple("Fastest", if (o.vis > 0) Sess.fmt(l.res[o.fi]!!.t) else "—", if (o.vis > 0) Sess.qLabel(l, o.fi) else ""),
            Triple("Slowest", if (o.vis > 0) Sess.fmt(l.res[o.si]!!.t) else "—", if (o.vis > 0) Sess.qLabel(l, o.si) else ""),
            Triple("Unanswered", o.un.toString(), ""),
            Triple("Accuracy", acc, ""),
        )
        boxes.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                pair.forEach { b -> Box2(b.first, b.second, b.third, Modifier.weight(1f)) }
            }
        }
        if (multi) {
            Text("Subject-wise", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            Glass(Modifier.fillMaxWidth()) {
                o.subs.forEachIndexed { k, S ->
                    Row(Modifier.padding(vertical = 4.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(l.cfg.subs.getOrElse(k) { "" }, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("${S.att} attempted · ${S.sk} not attempted · " + Sess.fmt(S.t), color = t.muted, fontSize = 12.sp)
                        }
                        Text(Sess.num(S.sc) + " / " + Sess.num(S.mx), color = t.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        val att = l.res.indices.filter { l.res[it]?.st == "A" }
        if (att.isNotEmpty()) {
            Text("Mark wrong answers · tap to change", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
            Chips(att.map { i ->
                val r = l.res[i]!!
                val g = if (r.w) " ✗" else if (r.p > 0) " +${r.p}" else " ✓"
                Triple(lab(i) + g, if (r.w) t.bad else if (r.p > 0) t.accent else t.good, i)
            }) { practice.cycleMark(it) }
        }
        val dn = l.res.count { it?.d == true }
        Text(if (dn > 0) "Your doubts · $dn" else "Mark your doubts", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp, bottom = 2.dp))
        Text("Tap the questions you were stuck on.", color = t.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        Chips(l.q.indices.map { i -> Triple(lab(i), if (l.res[i]?.d == true) t.accent else t.muted, i) }) { practice.toggleDoubt(it) }
        Text("Time per question", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
        val mt = maxOf(1L, l.res.maxOf { it?.t ?: 0L })
        Row(Modifier.fillMaxWidth().height(90.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
            l.res.forEach { r ->
                val frac = if (r == null || r.t <= 0) 0.04f else maxOf(0.05f, r.t.toFloat() / mt)
                val st = r?.st
                val c = when { st == null -> t.line; st == "N" -> t.muted; r?.w == true -> t.bad; else -> t.good }
                Box(Modifier.weight(1f).fillMaxHeight(frac).clip(RoundedCornerShape(2.dp)).background(c))
            }
        }
        Spacer(Modifier.height(18.dp))
        Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Report – " + l.cfg.name)
                putExtra(Intent.EXTRA_TEXT, Sess.reportText(l, dateText(l.cfg.date)))
            }
            ctx.startActivity(Intent.createChooser(send, "Share report"))
        }) { Text("Share report", color = t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        if (T && l.cfg.tid.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { practice.showReport(l.cfg.tid, l.cfg.id); practice.close(); onTests() }) {
                Text("Attempt report", color = t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Glass(Modifier.weight(1f), onClick = { practice.close() }) { Text("New session", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
            Glass(Modifier.weight(1f), onClick = { practice.close(); onHome() }) { Text("Home", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        }
        Spacer(Modifier.height(32.dp))
    }
}

/** Rows of small tappable labels (wrapping by hand, 4 per row). */
@Composable
private fun Chips(items: List<Triple<String, Color, Int>>, onTap: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (label, c, i) ->
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(c.copy(alpha = 0.16f)).clickable { onTap(i) }.padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(label, color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
