package com.ascend.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.sync.Account
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.launch

@Composable
private fun Action(label: String, primary: Boolean = false, danger: Boolean = false, onClick: () -> Unit) {
    val t = Tk.c
    Glass(modifier = Modifier.fillMaxWidth(), tint = if (primary) t.accent else null, onClick = onClick) {
        Text(
            label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            color = if (danger) t.bad else if (primary) t.accent else t.ink,
        )
    }
}

@Composable
fun AccountScreen(account: Account, onBack: () -> Unit) {
    val t = Tk.c
    val st by account.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var probe by remember { mutableStateOf("") }
    var confirmOut by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        PageHead("Account & backup", onBack)
        if (!st.ready) {
            Text("Loading…", color = t.muted)
        } else if (st.email == null) {
            Glass(modifier = Modifier.fillMaxWidth()) {
                Text("Sign in to back up your data and use it on other devices.", color = t.muted, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = email, onValueChange = { email = it }, singleLine = true, label = { Text("Email") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, singleLine = true, label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(),
                )
                if (st.message.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(st.message, color = if (st.message.endsWith("…")) t.muted else t.bad, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Action("Sign in", primary = true) { scope.launch { if (account.signIn(email, pw, false)) pw = "" } }
            Spacer(Modifier.height(8.dp))
            Action("Create account") { scope.launch { if (account.signIn(email, pw, true)) pw = "" } }
            Spacer(Modifier.height(8.dp))
            Action("Forgot password") { scope.launch { account.resetPassword(email) } }
        } else {
            Glass(modifier = Modifier.fillMaxWidth()) {
                Text(st.email ?: "", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                val line = when {
                    st.message.isNotEmpty() -> st.message
                    st.lastSync > 0 -> "Synced " + ago(st.lastSync)
                    else -> "Signed in"
                }
                Text(line, color = if (st.message.startsWith("Couldn't")) t.bad else t.muted, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                Text("${st.rows} items on this phone · ${st.sessions} saved sessions", color = t.muted, fontSize = 13.sp)
                if (st.pending > 0) Text("${st.pending} changes waiting to be sent", color = t.muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            Action(if (st.busy) "Syncing…" else "Sync now", primary = true) { if (!st.busy) scope.launch { account.sync() } }
            Spacer(Modifier.height(8.dp))
            Action("Restore everything from cloud") { if (!st.busy) scope.launch { account.restore() } }
            Spacer(Modifier.height(8.dp))
            Action("Cloud check") { scope.launch { probe = "Checking…"; probe = account.probe() } }
            if (probe.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(probe, color = if (probe.contains("FAILED")) t.bad else if (probe == "Checking…") t.muted else t.good, fontSize = 14.sp)
            }
            Spacer(Modifier.height(8.dp))
            Action("Sign out", danger = true) { scope.launch { if (!account.signOut(false)) confirmOut = true } }
            Spacer(Modifier.height(8.dp))
            Text("Signing out clears this phone's copy. Your cloud backup stays.", color = t.muted, fontSize = 12.sp)
        }
    }

    if (confirmOut) {
        AlertDialog(
            onDismissRequest = { confirmOut = false },
            title = { Text("Sign out anyway?") },
            text = { Text("Some changes haven't synced yet and will be lost.") },
            confirmButton = { TextButton(onClick = { scope.launch { account.signOut(true); confirmOut = false } }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { confirmOut = false }) { Text("Cancel") } },
        )
    }
}

private fun ago(t: Long): String {
    val m = ((System.currentTimeMillis() - t) / 60000).toInt()
    return if (m < 1) "just now" else "$m min ago"
}
