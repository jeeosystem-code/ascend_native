package com.ascend.app.sync

import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject

/** One row as it lives in the cloud: users/<uid>/sessions/<id> with fields data (a JSON string), deleted, updated_at. */
data class CloudRow(val id: String, val name: String, val data: String?, val deleted: Boolean, val updatedAt: Long)

enum class Take { PUT, DELETE, SKIP }

/** The cloud format shared with the web app. Everything here is pure (no network, no Android) so it can be unit-tested. */
object Protocol {
    const val FB_KEY = "AIzaSyAqLWkHBtlwkdOuz4nPzdE8kPPv8QlZD1Q"
    const val FB_PID = "jee-os-87b37"
    const val PAGE = 500
    const val BATCH = 100

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun authUrl(op: String) = "https://identitytoolkit.googleapis.com/v1/accounts:$op?key=${enc(FB_KEY)}"
    fun tokenUrl() = "https://securetoken.googleapis.com/v1/token?key=${enc(FB_KEY)}"
    fun base() = "https://firestore.googleapis.com/v1/projects/$FB_PID/databases/(default)/documents"
    fun userBase(uid: String) = base() + "/users/" + uid
    fun docName(uid: String, id: String) = "projects/$FB_PID/databases/(default)/documents/users/$uid/sessions/$id"
    fun docUrl(uid: String, id: String) = userBase(uid) + "/sessions/" + id

    fun parseRow(d: JSONObject): CloudRow {
        val f = d.optJSONObject("fields") ?: JSONObject()
        val name = d.optString("name")
        val data = f.optJSONObject("data")?.optString("stringValue").orEmpty().ifEmpty { null }
        val deleted = f.optJSONObject("deleted")?.optBoolean("booleanValue", false) ?: false
        val upd = f.optJSONObject("updated_at")?.opt("integerValue")?.toString()?.toLongOrNull() ?: 0L
        return CloudRow(name.substringAfterLast('/'), name, data, deleted, upd)
    }

    fun writeJson(uid: String, id: String, data: String?, deleted: Boolean, updatedAt: Long): JSONObject {
        val fields = JSONObject()
            .put("data", JSONObject().put("stringValue", data ?: ""))
            .put("deleted", JSONObject().put("booleanValue", deleted))
            .put("updated_at", JSONObject().put("integerValue", updatedAt.toString()))
        return JSONObject().put("update", JSONObject().put("name", docName(uid, id)).put("fields", fields))
    }

    fun commitBody(writes: List<JSONObject>): String {
        val a = JSONArray()
        writes.forEach { a.put(it) }
        return JSONObject().put("writes", a).toString()
    }

    /** Query for rows changed after [since], oldest first; [afterUpdated]/[afterName] continue after the last row of a full page. */
    fun queryBody(since: Long, afterUpdated: Long?, afterName: String?): String {
        val sq = JSONObject()
        sq.put("from", JSONArray().put(JSONObject().put("collectionId", "sessions")))
        sq.put(
            "where",
            JSONObject().put(
                "fieldFilter",
                JSONObject().put("field", JSONObject().put("fieldPath", "updated_at")).put("op", "GREATER_THAN")
                    .put("value", JSONObject().put("integerValue", since.toString())),
            ),
        )
        sq.put(
            "orderBy",
            JSONArray()
                .put(JSONObject().put("field", JSONObject().put("fieldPath", "updated_at")).put("direction", "ASCENDING"))
                .put(JSONObject().put("field", JSONObject().put("fieldPath", "__name__")).put("direction", "ASCENDING")),
        )
        sq.put("limit", PAGE)
        if (afterUpdated != null && afterName != null) {
            sq.put(
                "startAt",
                JSONObject().put(
                    "values",
                    JSONArray().put(JSONObject().put("integerValue", afterUpdated.toString())).put(JSONObject().put("referenceValue", afterName)),
                ).put("before", false),
            )
        }
        return JSONObject().put("structuredQuery", sq).toString()
    }

    fun parseRows(response: String?): List<CloudRow> {
        if (response.isNullOrBlank()) return emptyList()
        val a = JSONArray(response)
        val out = ArrayList<CloudRow>()
        for (i in 0 until a.length()) {
            val d = a.optJSONObject(i)?.optJSONObject("document") ?: continue
            out.add(parseRow(d))
        }
        return out
    }

    /** Newest change wins; a deletion only removes a local copy that is not newer than the deletion. */
    fun take(localUpdatedAt: Long?, c: CloudRow): Take {
        if (c.deleted) return if (localUpdatedAt != null && localUpdatedAt <= c.updatedAt) Take.DELETE else Take.SKIP
        if (c.data == null) return Take.SKIP
        return if (localUpdatedAt == null || localUpdatedAt < c.updatedAt) Take.PUT else Take.SKIP
    }

    /** Reads the readable error text out of a Firebase error body. */
    fun errorRaw(body: String): String {
        return try {
            val j = JSONObject(body)
            val e = j.optJSONObject("error")
            (e?.optString("message")?.ifEmpty { null } ?: e?.optString("status")?.ifEmpty { null } ?: j.optString("message")).orEmpty()
        } catch (x: Exception) {
            ""
        }
    }

    fun fbMsg(raw: String, status: Int): String {
        val m = raw
        return when {
            Regex("EMAIL_EXISTS").containsMatchIn(m) -> "That email already has an account. Sign in instead."
            Regex("INVALID_LOGIN_CREDENTIALS|INVALID_PASSWORD|EMAIL_NOT_FOUND").containsMatchIn(m) -> "Wrong email or password."
            Regex("WEAK_PASSWORD").containsMatchIn(m) -> "Use a password of at least 6 characters."
            Regex("INVALID_EMAIL").containsMatchIn(m) -> "That email doesn't look right."
            Regex("TOO_MANY_ATTEMPTS").containsMatchIn(m) -> "Too many tries. Wait a few minutes and try again."
            Regex("OPERATION_NOT_ALLOWED").containsMatchIn(m) -> "Email sign-in is switched off in Firebase."
            Regex("USER_DISABLED").containsMatchIn(m) -> "This account is disabled."
            Regex("API key not valid|API_KEY_INVALID", RegexOption.IGNORE_CASE).containsMatchIn(m) -> "The Firebase API key isn't valid."
            status == 403 || Regex("PERMISSION_DENIED|insufficient permissions", RegexOption.IGNORE_CASE).containsMatchIn(m) -> "Firestore refused access. Check the security rules."
            m.isNotEmpty() -> m
            else -> "Error $status"
        }
    }

    fun isRefreshDead(status: Int, raw: String) =
        status == 400 && Regex("TOKEN_EXPIRED|INVALID_REFRESH_TOKEN|USER_DISABLED|USER_NOT_FOUND|INVALID_GRANT").containsMatchIn(raw)

    fun <T> chunks(list: List<T>, n: Int = BATCH): List<List<T>> = list.chunked(n)

    /** Rows with this prefix are special documents of the web app; every other id is a saved practice session. */
    fun isSessionId(id: String) = !id.startsWith("zz_")
}
