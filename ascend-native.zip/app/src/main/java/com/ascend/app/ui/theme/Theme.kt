package com.ascend.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Colour tokens copied from the web app (light and dark). */
data class Tokens(
    val bg: Color, val card: Color, val ink: Color, val muted: Color, val line: Color,
    val accent: Color, val good: Color, val bad: Color, val dark: Boolean,
)

val LightTokens = Tokens(
    bg = Color(0xFFF4ECDD), card = Color(0xFFFFFAF0), ink = Color(0xFF1B1A17), muted = Color(0xFF8A8272),
    line = Color(0xFFE4D9C3), accent = Color(0xFF0A84FF), good = Color(0xFF3D7A4F), bad = Color(0xFFB85A3C), dark = false,
)
val DarkTokens = Tokens(
    bg = Color(0xFF12110E), card = Color(0xFF1C1A15), ink = Color(0xFFF4ECDD), muted = Color(0xFF8F8672),
    line = Color(0xFF2C2920), accent = Color(0xFF0A84FF), good = Color(0xFF7FBF8E), bad = Color(0xFFD98A6C), dark = true,
)

val LocalTokens = staticCompositionLocalOf { LightTokens }

object Tk {
    val c: Tokens @Composable get() = LocalTokens.current
}

@Composable
fun AscendTheme(dark: Boolean, content: @Composable () -> Unit) {
    val t = if (dark) DarkTokens else LightTokens
    val scheme = if (dark) {
        darkColorScheme(primary = t.accent, background = t.bg, surface = t.card, onBackground = t.ink, onSurface = t.ink)
    } else {
        lightColorScheme(primary = t.accent, background = t.bg, surface = t.card, onBackground = t.ink, onSurface = t.ink)
    }
    CompositionLocalProvider(LocalTokens provides t) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun systemDark(): Boolean = isSystemInDarkTheme()
