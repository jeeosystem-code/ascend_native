package com.ascend.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.At
import com.ascend.app.domain.Dates
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Folder
import com.ascend.app.domain.Sess
import com.ascend.app.domain.TestRec
import com.ascend.app.domain.Tl
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private val STATUS_COLORS = listOf(0xFF8E8E93, 0xFFFF9F0A, 0xFF30C25B)
private val BIT_COLORS = mapOf(1 to 0xFF30C25B, 2 to 0xFFFF9F0A, 4 to 0xFF0A84FF, 8 to 0xFFA259F0)

private class FolderDraft(val id: String, val k: String, var n: String, var sb: String)
private class TestDraft(val folderId: String, val exId: String, val date: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateDialog(initial: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val day = if (Dates.valid(initial)) initial else Dates.today()
    val st = rememberDatePickerState(initialSelectedDateMillis = LocalDate.parse(day).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val ms = st.selectedDateMillis
                if (ms != null) onPick(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate().toString())
                onDismiss()
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    ) { DatePicker(state = st) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestsScreen(domain: Domain, practice: PracticeController, onPractice: () -> Unit, onBack: () -> Unit) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    val data by domain.data.collectAsStateWithLifecycle()
    val today = Dates.today()
    val yr = Dates.parse(today).year
    var tab by rememberSaveable { mutableStateOf("m") }
    var folderId by rememberSaveable { mutableStateOf<String?>(null) }
    var folderForm by remember { mutableStateOf<FolderDraft?>(null) }
    var testForm by remember { mutableStateOf<TestDraft?>(null) }
    var recordId by rememberSaveable { mutableStateOf<String?>(null) }
    var hubId by rememberSaveable { mutableStateOf<String?>(null) }
    var repId by rememberSaveable { mutableStateOf<String?>(null) }
    var paperOpen by rememberSaveable { mutableStateOf(false) }
    var analysisId by remember { mutableStateOf<String?>(null) }
    val pend by practice.report.collectAsStateWithLifecycle()
    var resultId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(data != null) { if (data != null) domain.freezeNumbers() }
    LaunchedEffect(pend, data) {
        val p = pend
        if (p != null) {
            val tt = data?.tests?.firstOrNull { it.id == p.first && !it.x }
            if (tt != null) { tab = Tl.folder(data!!.folders, tt.f)?.k ?: tab; folderId = tt.f; hubId = tt.id; repId = p.second; practice.reportShown() }
            else if (data != null) practice.reportShown()
        }
    }
    BackHandler(enabled = paperOpen) { paperOpen = false }
    BackHandler(enabled = repId != null && !paperOpen) { repId = null }
    BackHandler(enabled = repId == null && hubId != null && !paperOpen) { hubId = null }
    BackHandler(enabled = repId == null && hubId == null && folderId != null) { folderId = null }

    val d = data
    val folder = d?.let { x -> folderId?.let { Tl.folder(x.folders, it) } }

    fun openTest(x: TestRec) {
        if (x.upcoming && Tl.days(x.d, today) <= 0) testForm = TestDraft(x.f, x.id, x.d) else if (x.upcoming) recordId = x.id else hubId = x.id
    }
    val hubT = d?.let { x -> hubId?.let { id -> x.tests.firstOrNull { it.id == id && !it.x } } }
    val repA = d?.let { x -> repId?.let { id -> At.get(x.atts, id) } }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
            if (d == null) {
                PageHead("Tests", onBack); Text("Loading…", color = t.muted)
            } else if (hubT != null && paperOpen) {
                PageHead("Paper", { paperOpen = false })
                Text(hubT.n, color = t.muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                PaperTagging(d, hubT) { sub, nums, ch -> scope.launch { domain.tagChapters(hubT.id, sub, nums, ch) } }
            } else if (hubT != null && repId != null) {
                val a = repA
                PageHead(if (a == null) hubT.n else if (a.mode == "r") "Review" else "Attempt " + At.no(d.atts, a), { repId = null })
                if (a == null) {
                    Text("Loading…", color = t.muted)
                    LaunchedEffect(repId) { delay(2500); repId = null }
                } else {
                    Text(hubT.n + " · " + Tl.dl(dayOf(a.o), yr), color = t.muted, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    AttemptReport(
                        d, hubT, a, yr, onPaper = { paperOpen = true },
                        onReason = { k, b -> scope.launch { domain.toggleReason(hubT.id, a.id, k, b) } },
                        onNote = { k, txt -> scope.launch { domain.setNote(hubT.id, a.id, k, txt) } },
                        onDelete = { scope.launch { domain.deleteAttempt(hubT.id, a.id) }; repId = null },
                        onReview = { keys, base ->
                            val full = At.list(d.atts, hubT.id)
                            val cfg = Sess.attemptCfg(hubT.n + " · review", hubT.subs, hubT.secs.orEmpty(), 0L, hubT.id, "r", base, keys)
                            if (cfg != null) { practice.open(cfg); onPractice() }
                        },
                    )
                }
            } else if (hubT != null) {
                PageHead(hubT.n, { hubId = null })
                Text((folder?.n?.let { "$it · " } ?: "") + Tl.dl(hubT.d, yr), color = t.muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                TestHub(d, hubT, yr, practice, onPractice, onReport = { repId = it }, onMarks = { recordId = hubT.id }, onAnalysis = { analysisId = hubT.id }, onPaper = { paperOpen = true })
            } else if (folder == null) {
                PageHead("Tests", onBack)
                FolderList(d, tab, { tab = it }, { folderId = it.id }, { folderForm = FolderDraft(it.id, it.k, it.n, it.sb) }, { folderForm = FolderDraft("", tab, "", "") })
            } else {
                PageHead(folder.n, { folderId = null })
                FolderView(d, folder, today, yr) { openTest(it) }
            }
            Spacer(Modifier.height(96.dp))
        }
        if (folder != null && hubT == null) {
            Box(
                Modifier.align(Alignment.BottomEnd).padding(20.dp).size(56.dp).clip(CircleShape).background(t.accent)
                    .clickable { testForm = TestDraft(folder.id, "", today) },
                contentAlignment = Alignment.Center,
            ) { Text("+", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light) }
        }
    }

    folderForm?.let { fd ->
        FolderSheet(fd, d, onClose = { folderForm = null }, onSave = { x ->
            scope.launch { if (domain.saveFolder(x.id, x.k, x.n, x.sb)) { tab = x.k; folderForm = null } }
        }, onDelete = { id -> scope.launch { domain.deleteFolder(id); if (folderId == id) folderId = null }; folderForm = null })
    }
    testForm?.let { td ->
        TestFormSheet(td, d, today, onClose = { testForm = null }) { name, date, subs, secs, dur ->
            scope.launch {
                val f = d?.let { Tl.folder(it.folders, td.folderId) } ?: return@launch
                val up = Tl.days(date, today) > 0
                val sub = if (f.k == "s") listOf(f.sb.ifEmpty { f.n }) else if (up) emptyList() else subs
                val id = domain.saveTest(td.folderId, td.exId, name, date, if (up) 0 else dur, sub, if (up) null else secs)
                testForm = null
                recordId = id
            }
        }
    }
    recordId?.let { rid ->
        val x = d?.tests?.firstOrNull { it.id == rid && !it.x }
        if (x == null || d == null) recordId = null
        else RecordSheet(
            d, x, today, yr, onClose = { recordId = null },
            onMark = { key, bit -> scope.launch { domain.toggleMark(rid, key, bit) } },
            onDate = { k -> scope.launch { domain.setTestDate(rid, k) } },
            onDelete = { scope.launch { domain.deleteTest(rid) }; recordId = null; hubId = null; repId = null },
            onResult = { resultId = rid }, onAnalysis = { analysisId = rid },
        )
    }
    analysisId?.let { aid ->
        val x = d?.tests?.firstOrNull { it.id == aid && !it.x }
        if (x == null || d == null) analysisId = null
        else AnalysisSheet(d, x, today, onClose = { analysisId = null }, onSave = { num, st, nm -> scope.launch { domain.saveAnalysis(aid, num, st, nm) }; analysisId = null },
            onPlan = { k -> scope.launch { domain.planAnalysis(aid, k) } }, onUnplan = { scope.launch { domain.unplanAnalysis(aid) } })
    }
    resultId?.let { rid ->
        val x = d?.tests?.firstOrNull { it.id == rid && !it.x }
        if (x == null) resultId = null
        else ResultSheet(x, onClose = { resultId = null }, onSave = { rs -> scope.launch { domain.saveResult(rid, rs) }; resultId = null })
    }
}

@Composable
private fun FolderList(d: DomainData, tab: String, onTab: (String) -> Unit, onOpen: (Folder) -> Unit, onEdit: (Folder) -> Unit, onNew: () -> Unit) {
    val t = Tk.c
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.line.copy(alpha = 0.45f)).padding(3.dp)) {
        listOf("m" to "Mock tests", "s" to "Subject tests").forEach { (k, label) ->
            val on = tab == k
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else Color.Transparent).clickable { onTab(k) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label + " · " + Tl.folders(d.folders, k).size, color = if (on) t.accent else t.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
    Spacer(Modifier.height(8.dp))
    Text(if (tab == "m") "Full-length tests with several subjects." else "Tests on a single subject.", color = t.muted, fontSize = 13.sp)
    Spacer(Modifier.height(12.dp))
    val fs = Tl.folders(d.folders, tab)
    if (fs.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Text(if (tab == "m") "No mock folders yet" else "No subject folders yet", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (tab == "m") "Make a folder for a series of full tests, for example a test series name." else "Make a folder for one subject, for example Physics unit tests.",
                color = t.muted, fontSize = 14.sp,
            )
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        fs.forEachIndexed { i, f ->
            val n = Tl.list(d.tests, f.id).size
            val col = Color(DomainData.COLORS[i % DomainData.COLORS.size])
            Glass(Modifier.fillMaxWidth(), onClick = { onOpen(f) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(4.dp).height(36.dp).clip(RoundedCornerShape(2.dp)).background(col))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(f.n, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text((if (f.k == "s" && f.sb.isNotEmpty() && f.sb != f.n) f.sb + " · " else "") + n + (if (n == 1) " test" else " tests"), color = t.muted, fontSize = 12.5.sp)
                    }
                    Text("Edit", color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onEdit(f) }.padding(10.dp))
                }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = onNew) {
        Text("+ New folder", color = t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
private fun FolderView(d: DomainData, f: Folder, today: String, yr: Int, onOpen: (TestRec) -> Unit) {
    val t = Tk.c
    val ts = Tl.list(d.tests, f.id)
    val col = Color(DomainData.COLORS[Math.max(0, Tl.folders(d.folders, f.k).indexOfFirst { it.id == f.id }) % DomainData.COLORS.size])
    Text(if (f.k == "m") "Mock test folder" else "Subject test" + (if (f.sb.isNotEmpty()) " · " + f.sb else ""), color = t.muted, fontSize = 13.sp)
    Spacer(Modifier.height(12.dp))
    var ta = 0; var tr = 0; var ti = 0
    ts.forEach { val c = Tl.cnt(it); ta += c.a; tr += c.r; ti += c.i }
    if (ts.isNotEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(ts.size to "Tests", ta to "Attempted", tr to "Review", ti to "Important").forEach { (v, l) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(v.toString(), color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(l, color = t.muted, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    } else {
        Glass(Modifier.fillMaxWidth()) {
            Text("No tests yet", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("Tap + to add a test with its paper pattern, then mark each question.", color = t.muted, fontSize = 14.sp)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ts.forEach { x ->
            val c = Tl.cnt(x)
            val dy = Tl.days(x.d, today)
            val up = x.upcoming
            val no = Tl.num(d.tests, x).toString()
            val sc = x.rs?.sc
            val sub = Tl.dl(x.d, yr) + " · " + (if (up) (if (dy > 0) (if (dy == 1) "Tomorrow" else "Upcoming") else "Add pattern")
            else "${c.a}/${c.n}" + (if (sc != null) " · " + Sess.num(sc) + (x.rs?.fm?.let { "/" + Sess.num(it) } ?: "") else ""))
            Glass(Modifier.fillMaxWidth(), onClick = { onOpen(x) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(col.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                        Text(no, color = col, fontSize = if (no.length > 2) 15.sp else 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(9.dp).clip(CircleShape).background(Color(STATUS_COLORS[Tl.st(x)])))
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(x.n, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(sub, color = t.muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (!up && c.r > 0) Text("${c.r}", color = Color(0xFFFF9F0A), fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
                    if (!up && c.i > 0) Text("${c.i}", color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp))
                    if (up && dy > 0) Text("${dy}d", color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
                }
                if (!up && c.n > 0) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(t.line)) {
                        Box(Modifier.fillMaxWidth(c.a.toFloat() / c.n).height(4.dp).clip(RoundedCornerShape(2.dp)).background(col))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetBox(onClose: () -> Unit, content: @Composable () -> Unit) {
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Tk.c.card) {
        Column(Modifier.imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding()) { content() }
    }
}

@Composable
fun Action2(label: String, color: Color, tint: Color? = null, onClick: () -> Unit) {
    Glass(Modifier.fillMaxWidth(), tint = tint, onClick = onClick) {
        Text(label, color = color, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
private fun FolderSheet(fd: FolderDraft, d: DomainData?, onClose: () -> Unit, onSave: (FolderDraft) -> Unit, onDelete: (String) -> Unit) {
    val t = Tk.c
    var n by remember { mutableStateOf(fd.n) }
    var sb by remember { mutableStateOf(fd.sb) }
    var arm by remember { mutableStateOf(false) }
    LaunchedEffect(arm) { if (arm) { delay(3000); arm = false } }
    SheetBox(onClose) {
        Text(if (fd.k == "m") "Mock test" else "Subject test", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(if (fd.id.isEmpty()) "New folder" else "Edit folder", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Field(n, { n = it.take(40) }, "Folder name", Modifier.fillMaxWidth())
        if (fd.k == "s") {
            Spacer(Modifier.height(8.dp))
            Field(sb, { sb = it.take(24) }, "Subject", Modifier.fillMaxWidth())
            val names = d?.subjects?.map { it.name }?.distinctBy { it.lowercase() }.orEmpty()
            if (names.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    names.forEach { s -> Pill(s, sb.equals(s, true)) { sb = s } }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Action2(if (n.isBlank()) "Name the folder" else "Save", if (n.isBlank()) t.muted else t.accent, if (n.isBlank()) null else t.accent) { if (n.isNotBlank()) onSave(FolderDraft(fd.id, fd.k, n, sb)) }
        if (fd.id.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Action2(if (arm) "Tap again to delete the folder and its tests" else "Delete folder", t.bad) { if (arm) onDelete(fd.id) else arm = true }
        }
    }
}

@Composable
private fun TestFormSheet(td: TestDraft, d: DomainData?, today: String, onClose: () -> Unit, onSubmit: (String, String, List<String>, List<com.ascend.app.domain.Sec>, Int) -> Unit) {
    val t = Tk.c
    val f = d?.let { Tl.folder(it.folders, td.folderId) }
    val ex = d?.tests?.firstOrNull { it.id == td.exId }
    var date by remember { mutableStateOf(td.date) }
    var pick by remember { mutableStateOf(false) }
    val up = Tl.days(date, today) > 0
    val yr = Dates.parse(today).year
    SheetBox(onClose) {
        Text(f?.n ?: "Tests", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(if (ex != null) "Paper pattern" else "New test", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(if (f?.k == "m") "Mock test · pattern for every subject" else ((f?.sb?.ifEmpty { f.n } ?: "") + " · one subject"), color = t.muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth(), onClick = { pick = true }) {
            Text("Test date", color = t.muted, fontSize = 12.sp)
            Text(Tl.dl(date, yr), color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        if (up) {
            var name by remember { mutableStateOf(ex?.n ?: "") }
            Field(name, { name = it.take(60) }, "Test name (optional)", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("The paper pattern and question marking open on the test day.", color = t.muted, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Action2("Add test", t.accent, t.accent) { onSubmit(name, date, emptyList(), emptyList(), 0) }
        } else {
            val init = if (ex != null && !ex.upcoming) PatternInit(ex.n, ex.dur, if (f?.k == "m") ex.subs else emptyList(), ex.secs.orEmpty()) else null
            PatternForm(f?.k == "m", init, if (ex != null) "Save pattern" else "Add test") { name, subs, secs, dur -> onSubmit(name.ifEmpty { ex?.n ?: "" }, date, subs, secs, dur) }
        }
    }
    if (pick) DateDialog(date, { date = it }) { pick = false }
}

@Composable
private fun RecordSheet(
    d: DomainData, x: TestRec, today: String, yr: Int, onClose: () -> Unit,
    onMark: (String, Int) -> Unit, onDate: (String) -> Unit, onDelete: () -> Unit, onResult: () -> Unit, onAnalysis: () -> Unit,
) {
    val t = Tk.c
    val f = Tl.folder(d.folders, x.f)
    var sub by remember { mutableStateOf(0) }
    var tool by remember { mutableStateOf(1) }
    var arm by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    LaunchedEffect(arm) { if (arm) { delay(3000); arm = false } }
    SheetBox(onClose) {
        Text((f?.n?.let { "$it · " } ?: "") + Tl.dl(x.d, yr), color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(x.n, color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (x.upcoming) {
            val dy = Tl.days(x.d, today)
            Spacer(Modifier.height(16.dp))
            Glass(Modifier.fillMaxWidth()) {
                Text(Math.max(dy, 0).toString(), color = t.accent, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                Text(if (dy == 1) "day to go" else "days to go", color = t.ink, fontSize = 15.sp)
                Text("The paper pattern and question marking open on the test day.", color = t.muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            Action2("Change date", t.accent) { pick = true }
        } else {
            val c = Tl.cnt(x)
            Text(
                "${c.a} of ${c.n} attempted" + (if (c.r > 0) " · ${c.r} for review" else "") + (if (c.i > 0) " · ${c.i} important" else "") + (if (c.d > 0) " · ${c.d} doubts" else ""),
                color = t.muted, fontSize = 13.sp,
            )
            val subs = x.subs
            if (subs.size > 1) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    subs.forEachIndexed { k, s -> val u = Tl.cnt(x, k); Pill("$s  ${u.a}/${u.n}", k == sub) { sub = k } }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1 to "Attempted", 2 to "Review", 4 to "Important", 8 to "Doubt").forEach { (b, label) ->
                    val col = Color(BIT_COLORS[b]!!)
                    val n = when (b) { 1 -> c.a; 2 -> c.r; 4 -> c.i; else -> c.d }
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (tool == b) col.copy(alpha = 0.22f) else t.line.copy(alpha = 0.5f))
                            .border(if (tool == b) 1.5.dp else 0.dp, if (tool == b) col else Color.Transparent, RoundedCornerShape(14.dp))
                            .clickable { tool = b }.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(n.toString(), color = col, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(label, color = t.ink, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                when (tool) { 1 -> "Tap the questions you attempted."; 2 -> "Tap the questions to mark for review."; 4 -> "Tap the most important questions."; else -> "Tap the questions you have a doubt in." },
                color = t.muted, fontSize = 13.sp,
            )
            Spacer(Modifier.height(8.dp))
            val secs = x.secs.orEmpty()
            val qs = Tl.qs(x).filter { it.sub == sub }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                qs.groupBy { it.sec }.forEach { (si, list) ->
                    if (secs.size > 1) Text(secs.getOrNull(si)?.name?.ifEmpty { null } ?: "Section ${si + 1}", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                    list.chunked(7).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { q ->
                                val key = "${q.sub}.${q.no}"
                                val v = x.mark(key)
                                val tc = Color(BIT_COLORS[tool]!!)
                                Box(
                                    Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                                        .background(if (v and tool != 0) tc.copy(alpha = 0.28f) else t.line.copy(alpha = 0.5f))
                                        .border(if (v and tool != 0) 1.5.dp else 0.dp, if (v and tool != 0) tc else Color.Transparent, RoundedCornerShape(10.dp))
                                        .clickable { onMark(key, tool) },
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("${q.no}", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        listOf(1, 2, 4, 8).forEach { b -> if (v and b != 0) Box(Modifier.size(5.dp).clip(CircleShape).background(Color(BIT_COLORS[b]!!))) }
                                    }
                                }
                            }
                            repeat(7 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            val rs = x.rs
            if (rs != null && rs.any) {
                Glass(Modifier.fillMaxWidth(), onClick = onResult) {
                    Text("Result", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        listOfNotNull(
                            rs.sc?.let { "Score " + Sess.num(it) + (rs.fm?.let { f2 -> " / " + Sess.num(f2) } ?: "") },
                            rs.pc?.let { Sess.num(it) + " percentile" }, rs.rk?.let { "Rank " + Tl.inr(it.toLong()) },
                        ).joinToString(" · ").ifEmpty { "Full marks " + Sess.num(rs.fm ?: 0.0) },
                        color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            } else Action2("Add result", t.accent, null, onResult)
        }
        Spacer(Modifier.height(8.dp))
        Action2("Name, number and analysis", t.ink, null, onAnalysis)
        Spacer(Modifier.height(8.dp))
        Action2(if (arm) "Tap again to delete the test" else "Delete test", t.bad) { if (arm) onDelete() else arm = true }
    }
    if (pick) DateDialog(x.d, { onDate(it) }) { pick = false }
}

@Composable
private fun AnalysisSheet(d: DomainData, x: TestRec, today: String, onClose: () -> Unit, onSave: (String, Int, String) -> Unit, onPlan: (String) -> Unit, onUnplan: () -> Unit) {
    val t = Tk.c
    val f = Tl.folder(d.folders, x.f)
    var st by remember { mutableStateOf(Tl.st(x)) }
    var num by remember { mutableStateOf(if (x.no.isNotEmpty()) x.no else "") }
    var nm by remember { mutableStateOf(x.n) }
    var pick by remember { mutableStateOf(false) }
    val plan = d.items.firstOrNull { it.tl == x.id && !it.x }
    val auto = Tl.num(d.tests, x)
    SheetBox(onClose) {
        Text(f?.n ?: "Tests", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text("Analysis", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tl.STATUS.forEachIndexed { i, label ->
                val c = Color(STATUS_COLORS[i])
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (st == i) c.copy(alpha = 0.2f) else t.line.copy(alpha = 0.5f))
                        .border(if (st == i) 1.5.dp else 0.dp, if (st == i) c else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { st = i }.padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = if (st == i) c else t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth(), onClick = { pick = true }) {
            Text("Assign", color = t.muted, fontSize = 12.sp)
            Text(
                if (plan != null) (if (plan.done) "Done · " else "Planned · ") + Tl.dl(plan.d, Dates.parse(today).year) else "Plan analysis",
                color = if (plan != null) t.ink else t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        if (plan != null) {
            Text("Remove from homework", color = t.bad, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onUnplan() }.padding(10.dp))
        }
        Spacer(Modifier.height(8.dp))
        Field(nm, { nm = it.take(60) }, "Test name", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Field(num, { num = it.filter(Char::isDigit).take(4) }, "Number (empty = $auto)", Modifier.fillMaxWidth(), numeric = true)
        Spacer(Modifier.height(16.dp))
        Action2("Save", t.accent, t.accent) { onSave(num, st, nm) }
    }
    if (pick) DateDialog(plan?.d ?: today, { onPlan(it); if (st == 0) st = 1 }) { pick = false }
}

@Composable
private fun ResultSheet(x: TestRec, onClose: () -> Unit, onSave: (com.ascend.app.domain.Rs) -> Unit) {
    val t = Tk.c
    val r = x.rs
    fun fv(v: Double?) = v?.let { Sess.num(it) } ?: ""
    var fm by remember { mutableStateOf(if (r?.fm != null) fv(r.fm) else (Tl.max(x).takeIf { it > 0 }?.let { Sess.num(it) } ?: "")) }
    var sc by remember { mutableStateOf(fv(r?.sc)) }
    var pc by remember { mutableStateOf(r?.pc?.let { it.toString().removeSuffix(".0") } ?: "") }
    var rk by remember { mutableStateOf(fv(r?.rk)) }
    var ts by remember { mutableStateOf(fv(r?.ts)) }
    var auto by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    fun sync(from: String, npc: String, nrk: String, nts: String) {
        val s = Tl.rsSync(Tl.RsState(npc, nrk, nts, auto), from)
        pc = s.pc; rk = s.rk; ts = s.ts; auto = s.auto; err = ""
    }
    val tsN = Tl.parseNum(ts)
    val need = if (tsN != null && !tsN.isNaN() && tsN >= 1) Tl.rsMin(tsN) else 0
    SheetBox(onClose) {
        Text(x.n, color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text("Result", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(fm, { fm = it.take(8); err = "" }, "Full marks", Modifier.weight(1f), decimal = true)
            Field(sc, { sc = it.take(8); err = "" }, "Your score", Modifier.weight(1f), decimal = true)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(pc, { sync("pc", it.take(9), rk, ts) }, "Percentile" + (if (auto == "pc") " (auto)" else ""), Modifier.weight(1f), decimal = true)
            Field(rk, { sync("rk", pc, it.filter(Char::isDigit).take(8), ts) }, "Rank" + (if (auto == "rk") " (auto)" else ""), Modifier.weight(1f), numeric = true)
        }
        Spacer(Modifier.height(8.dp))
        Field(ts, { sync("ts", pc, rk, it.filter(Char::isDigit).take(8)) }, "Total students" + (if (auto == "ts") " (auto)" else ""), Modifier.fillMaxWidth(), numeric = true)
        if (need > 0) {
            Spacer(Modifier.height(6.dp))
            Text("At least $need " + (if (need == 1) "decimal" else "decimals") + " in percentile for " + Tl.inr(tsN!!.toLong()) + " students", color = t.muted, fontSize = 12.sp)
        }
        if (err.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(err, color = t.bad, fontSize = 13.sp) }
        Spacer(Modifier.height(16.dp))
        Action2("Save result", t.accent, t.accent) {
            val (e, res) = Tl.rsCheck(fm, sc, pc, rk, ts, auto)
            if (e != null) err = e else if (res != null) onSave(res)
        }
    }
}
