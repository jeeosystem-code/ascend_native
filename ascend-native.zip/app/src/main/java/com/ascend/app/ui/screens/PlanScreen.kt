package com.ascend.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.activity.compose.BackHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.Dates
import com.ascend.app.domain.Domain
import com.ascend.app.domain.HwItem
import com.ascend.app.domain.Planner
import com.ascend.app.domain.PlanRow
import com.ascend.app.ui.Glass
import com.ascend.app.ui.Icons
import com.ascend.app.ui.SvgIcon
import com.ascend.app.ui.theme.Tk
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlinx.coroutines.launch

private val CHECK = listOf("M5 12.5l4.5 4.5L19 7.5")

/** The round tick button on a task. Done = soft green fill. */
@Composable
fun Tick(done: Boolean, onClick: () -> Unit) {
    val t = Tk.c
    Box(
        Modifier.size(44.dp).clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(26.dp).clip(CircleShape)
                .background(if (done) t.good else Color.Transparent)
                .border(2.dp, if (done) t.good else t.muted.copy(alpha = 0.55f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { if (done) SvgIcon(CHECK, Color.White, 16.dp, 2.4f) }
    }
}

@Composable
fun TaskRow(r: PlanRow, showDate: Boolean = false, onTick: () -> Unit, onOpen: () -> Unit) {
    val t = Tk.c
    val i = r.item
    Glass(modifier = Modifier.fillMaxWidth(), onClick = onOpen, tint = if (i.done) t.good else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(Color(r.color)))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(r.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val meta = listOf(
                    if (showDate && Dates.valid(i.d)) Dates.dowShort(i.d) + " " + Dates.parse(i.d).dayOfMonth else "",
                    r.sub,
                    Dates.clock(i.tm),
                    Dates.hm(r.minutes),
                ).filter { it.isNotEmpty() }.joinToString(" · ")
                if (meta.isNotEmpty()) Text(meta, color = t.muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Tick(i.done, onTick)
        }
    }
}

private class Draft(
    val id: String?,
    val title: String,
    val day: String,
    val subject: String,
    val time: String,
    val minutes: Int,
    val priority: Int,
    val note: String,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanScreen(domain: Domain, addOnOpen: Boolean) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    val data by domain.data.collectAsStateWithLifecycle()
    var sel by rememberSaveable { mutableStateOf(Dates.today()) }
    var draft by remember { mutableStateOf<Draft?>(null) }
    var consumed by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(addOnOpen) {
        if (addOnOpen && !consumed) {
            consumed = true
            draft = Draft(null, "", sel, "", "", 0, 0, "")
        }
    }
    val today = Dates.today()
    var view by rememberSaveable { mutableStateOf("d") }
    var openPlan by rememberSaveable { mutableStateOf<String?>(null) }
    var monthAnchor by rememberSaveable { mutableStateOf(today) }
    var finishBy by remember { mutableStateOf(false) }
    var delArm by remember { mutableStateOf(false) }
    BackHandler(enabled = openPlan != null) { openPlan = null; delArm = false }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
            ViewTabs(view) { view = it; openPlan = null; delArm = false }
            Spacer(Modifier.height(14.dp))
            if (view != "d") Text(
                when (view) { "w" -> "Week"; "m" -> "Month"; else -> if (openPlan != null) "Plan" else "Plans" },
                color = t.ink, fontSize = 34.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 10.dp),
            )
            if (view == "d") Text(
                buildAnnotatedString {
                    append(if (sel == today) "Today" else Dates.dowName(sel))
                    append("\n")
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = t.accent)) {
                        append("${Dates.parse(sel).dayOfMonth} ${Dates.monthName(sel).take(3)}.")
                    }
                },
                color = t.ink, fontSize = 38.sp, fontWeight = FontWeight.Bold, lineHeight = 42.sp,
            )
            if (view == "d") Spacer(Modifier.height(14.dp))
            if (view == "d") WeekStrip(sel, today, data, onPick = { sel = it }, onShift = { sel = Dates.add(sel, it) }, onToday = { sel = today })
            if (view == "d") Spacer(Modifier.height(14.dp))

            val d = data
            if (d == null) {
                Text("Loading…", color = t.muted)
            } else if (view == "w") {
                WeekView(d, sel, today) { k -> sel = k; view = "d" }
            } else if (view == "m") {
                MonthView(
                    d, monthAnchor, sel, today,
                    onShift = { n -> monthAnchor = Dates.parse(monthAnchor).withDayOfMonth(1).plusMonths(n.toLong()).toString() },
                    onDay = { k -> sel = k; view = "d" },
                )
            } else if (view == "p") {
                val pid = openPlan
                if (pid == null) PlansView(d, today) { openPlan = it; delArm = false }
                else PlanDetailView(
                    d, pid, today,
                    onOpenTask = { draft = draftOf(it) },
                    onDay = { k -> sel = k; view = "d" },
                    onFinishBy = { finishBy = true },
                    deleteArmed = delArm,
                    onDelete = {
                        if (delArm) { scope.launch { domain.deletePlan(pid) }; openPlan = null; delArm = false } else delArm = true
                    },
                )
            } else {
                val list = Planner.day(d, sel)
                val stat = Planner.stat(list)
                if (stat.minutes > 0) LoadBar(stat.minutes, d.profile.capHours)
                if (list.isEmpty()) {
                    Glass(Modifier.fillMaxWidth()) {
                        Text("Nothing planned", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text("Tap + to add a task for this day.", color = t.muted, fontSize = 14.sp)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    list.forEach { r ->
                        TaskRow(r, onTick = { scope.launch { domain.toggle(r.item.id) } }, onOpen = { draft = draftOf(r.item) })
                    }
                }
                val over = if (sel == today) Planner.overdue(d, today) else emptyList()
                if (over.isNotEmpty()) {
                    Spacer(Modifier.height(22.dp))
                    Text("Overdue · ${over.size}", color = t.bad, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        over.forEach { r ->
                            TaskRow(r, showDate = true, onTick = { scope.launch { domain.toggle(r.item.id) } }, onOpen = { draft = draftOf(r.item) })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Glass(Modifier.fillMaxWidth(), onClick = {
                        scope.launch { over.forEach { domain.moveTo(it.item.id, today) } }
                    }) { Text("Move all overdue to today", color = t.accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Spacer(Modifier.height(96.dp))
        }
        if (view == "d" || view == "w" || view == "m")
        // Add button: sits in the corner above the dock; the list has spare room underneath so nothing is covered.
        Box(
            Modifier.align(Alignment.BottomEnd).padding(20.dp).size(56.dp).clip(CircleShape)
                .background(t.accent).clickable { draft = Draft(null, "", sel, "", "", 0, 0, "") },
            contentAlignment = Alignment.Center,
        ) { Text("+", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light) }
    }

    val pidFin = openPlan
    if (finishBy && pidFin != null) {
        val st = rememberDatePickerState(initialSelectedDateMillis = LocalDate.parse(today).plusDays(7).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { finishBy = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { ms ->
                        val k = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate().toString()
                        scope.launch { domain.finishPlan(pidFin, k) }
                    }
                    finishBy = false
                }) { Text("Spread tasks to this day") }
            },
            dismissButton = { TextButton(onClick = { finishBy = false }) { Text("Cancel") } },
        ) { DatePicker(state = st) }
    }

    val dr = draft
    if (dr != null) {
        TaskSheet(
            dr, data,
            onClose = { draft = null },
            onSave = { x ->
                scope.launch {
                    if (x.id == null) domain.addTask(x.title, x.day, x.subject, x.time, x.minutes, x.priority, x.note)
                    else domain.updateTask(x.id, x.title, x.day, x.subject, x.time, x.minutes, x.priority, x.note)
                }
                sel = x.day
                draft = null
            },
            onDelete = { id -> scope.launch { domain.delete(id) }; draft = null },
        )
    }
}

private fun draftOf(i: HwItem) = Draft(i.id, i.t, if (Dates.valid(i.d)) i.d else Dates.today(), i.s, i.tm, i.du, i.pr, i.nt)

@Composable
private fun LoadBar(minutes: Int, capHours: Int) {
    val t = Tk.c
    val cap = capHours * 60
    val p = if (cap > 0) minutes.toFloat() / cap else 0f
    Column(Modifier.padding(bottom = 12.dp)) {
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.line)) {
            Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(if (p > 1f) t.bad else t.accent))
        }
        Spacer(Modifier.height(4.dp))
        Text("Planned ${Dates.hm(minutes)} of $capHours h", color = t.muted, fontSize = 12.sp)
    }
}

@Composable
private fun WeekStrip(sel: String, today: String, data: DomainData?, onPick: (String) -> Unit, onShift: (Int) -> Unit, onToday: () -> Unit) {
    val t = Tk.c
    val start = Dates.weekStart(sel)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("‹", color = t.ink, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onShift(-7) }.padding(horizontal = 12.dp, vertical = 4.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
            for (n in 0..6) {
                val k = Dates.add(start, n)
                val on = k == sel
                val has = data != null && data.items.any { data.live(it) && it.d == k && !it.done }
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) t.accent.copy(alpha = 0.16f) else Color.Transparent)
                        .clickable { onPick(k) }.padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(Dates.dowShort(k).take(1), color = t.muted, fontSize = 11.sp)
                    Text("${Dates.parse(k).dayOfMonth}", color = if (on) t.accent else if (k == today) t.ink else t.ink.copy(alpha = 0.8f), fontSize = 16.sp, fontWeight = if (k == today || on) FontWeight.Bold else FontWeight.Medium)
                    Box(Modifier.padding(top = 2.dp).size(5.dp).clip(CircleShape).background(if (has) t.accent.copy(alpha = 0.7f) else Color.Transparent))
                }
            }
        }
        Text("›", color = t.ink, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onShift(7) }.padding(horizontal = 12.dp, vertical = 4.dp))
    }
    if (sel != today) {
        Text("Back to today", color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(10.dp)).clickable { onToday() }.padding(6.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TaskSheet(d: Draft, data: DomainData?, onClose: () -> Unit, onSave: (Draft) -> Unit, onDelete: (String) -> Unit) {
    val t = Tk.c
    var title by remember { mutableStateOf(d.title) }
    var day by remember { mutableStateOf(d.day) }
    var subject by remember { mutableStateOf(d.subject) }
    var time by remember { mutableStateOf(d.time) }
    var minutes by remember { mutableStateOf(d.minutes) }
    var priority by remember { mutableStateOf(d.priority) }
    var note by remember { mutableStateOf(d.note) }
    var pickDate by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    var arm by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onClose, containerColor = t.card) {
        Column(Modifier.imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
            Text(if (d.id == null) "New task" else "Edit task", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = title, onValueChange = { title = it }, label = { Text("What to do") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            )
            Spacer(Modifier.height(10.dp))
            val subs = data?.subjects.orEmpty()
            if (subs.isNotEmpty()) {
                Label("Subject")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("None", subject.isEmpty(), null) { subject = "" }
                    subs.forEach { s -> Chip(s.name, data?.canonical(subject) == s.id, Color(DomainData.color(s))) { subject = s.id } }
                }
                Spacer(Modifier.height(10.dp))
            }
            Label("Date and time")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(Dates.dowShort(day) + " " + Dates.parse(day).dayOfMonth + " " + Dates.monthName(day).take(3), true, null) { pickDate = true }
                Chip(if (time.isEmpty()) "No time" else Dates.clock(time), time.isNotEmpty(), null) { pickTime = true }
                if (time.isNotEmpty()) Chip("Clear", false, null) { time = "" }
            }
            Spacer(Modifier.height(10.dp))
            Label("How long")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("None", minutes == 0, null) { minutes = 0 }
                listOf(15, 30, 45, 60, 90, 120).forEach { m -> Chip(Dates.hm(m), minutes == m, null) { minutes = m } }
            }
            Spacer(Modifier.height(10.dp))
            Label("Priority")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Normal", priority == 0, null) { priority = 0 }
                Chip("High", priority == 1, null) { priority = 1 }
                Chip("Medium", priority == 2, null) { priority = 2 }
                Chip("Low", priority == 3, null) { priority = 3 }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            val ok = title.trim().isNotEmpty()
            Glass(Modifier.fillMaxWidth(), tint = if (ok) t.accent else null, onClick = {
                if (ok) onSave(Draft(d.id, title.replace(Regex("\\s+"), " ").trim(), day, subject, time, minutes, priority, note))
            }) { Text(if (ok) "Save" else "Type a task first", color = if (ok) t.accent else t.muted, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (d.id != null) {
                Spacer(Modifier.height(8.dp))
                Glass(Modifier.fillMaxWidth(), onClick = { if (arm) onDelete(d.id) else arm = true }) {
                    Text(if (arm) "Tap again to delete" else "Delete task", color = t.bad, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    if (pickDate) {
        val st = rememberDatePickerState(initialSelectedDateMillis = LocalDate.parse(day).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { pickDate = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { day = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString() }
                    pickDate = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickDate = false }) { Text("Cancel") } },
        ) { DatePicker(state = st) }
    }
    if (pickTime) {
        val h0 = time.substringBefore(":").toIntOrNull() ?: 9
        val m0 = time.substringAfter(":", "0").toIntOrNull() ?: 0
        val st = rememberTimePickerState(initialHour = h0, initialMinute = m0, is24Hour = false)
        AlertDialog(
            onDismissRequest = { pickTime = false },
            confirmButton = {
                TextButton(onClick = {
                    time = "%02d:%02d".format(st.hour, st.minute)
                    pickTime = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickTime = false }) { Text("Cancel") } },
            text = { TimePicker(state = st) },
        )
    }
}

@Composable
private fun Label(s: String) {
    Text(s, color = Tk.c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
private fun Chip(label: String, on: Boolean, color: Color?, onClick: () -> Unit) {
    val t = Tk.c
    val c = color ?: t.accent
    Box(
        Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) c.copy(alpha = 0.18f) else t.line.copy(alpha = 0.5f))
            .border(1.dp, if (on) c.copy(alpha = 0.6f) else Color.Transparent, RoundedCornerShape(14.dp))
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 9.dp),
    ) { Text(label, color = if (on) c else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
}
