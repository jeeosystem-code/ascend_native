package com.ascend.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** One homework / planner task. Wraps the raw JSON so fields this app does not know are kept when saving. */
class HwItem(val j: JSONObject) {
    val id: String get() = j.optString("id")
    val d: String get() = j.optString("d")
    val s: String get() = j.optString("s")
    val t: String get() = j.optString("t")
    val rg: String get() = j.optString("rg")
    val cn: String get() = j.optString("cn")
    val ch: String get() = j.optString("ch")
    val tm: String get() = j.optString("tm")
    val du: Int get() = j.optInt("du", 0)
    val pr: Int get() = j.optInt("pr", 0)
    val o: Long get() = j.optLong("o", 0)
    val u: Long get() = j.optLong("u", 0)
    val pl: String get() = j.optString("pl")
    val pn: String get() = j.optString("pn")
    val nt: String get() = j.optString("nt")
    val at: String get() = j.optString("at")
    val tl: String get() = j.optString("tl")
    val done: Boolean get() = j.optBoolean("done", false)
    val x: Boolean get() = Merge.isX(j)
    val rv: Boolean get() = j.optBoolean("rv", false) || j.optInt("rv", 0) != 0
}

class SyNode(val j: JSONObject) {
    val id: String get() = j.optString("id")
    val k: String get() = j.optString("k")
    val n: String get() = j.optString("n")
    val p: String get() = j.optString("p")
    val o: Long get() = j.optLong("o", 0)
    val c: Int get() = j.optInt("c", 0)
    val x: Boolean get() = Merge.isX(j)
}

data class Subject(val id: String, val name: String, val colorIndex: Int)

data class Profile(val name: String = "", val exam: String = "", val examName: String = "Exam", val capHours: Int = 6, val minPerQ: Int = 3)

/** Everything the planner needs, built from the downloaded rows. */
class DomainData(
    val items: List<HwItem>, val nodes: List<SyNode>, val legacySubjects: List<JSONObject>, val profile: Profile,
    val focus: List<FocusEntry> = emptyList(),
    val folders: List<Folder> = emptyList(), val tests: List<TestRec> = emptyList(),
    val atts: List<JSONObject> = emptyList(),
) {
    val subjects: List<Subject>
    private val canon = HashMap<String, String>()

    init {
        val sy = nodes.filter { it.k == "s" && !it.x }.sortedBy { it.o }
        val list = ArrayList<Subject>()
        val have = HashSet<String>()
        sy.forEach { list.add(Subject(it.id, it.n, it.c)); have.add(norm(it.n)) }
        legacySubjects.filter { !Merge.isX(it) && !have.contains(norm(it.optString("n"))) && items.any { i -> !i.x && i.s == it.optString("id") } }
            .sortedBy { it.optLong("o", 0) }
            .forEach { list.add(Subject(it.optString("id"), it.optString("n"), it.optInt("c", 0))) }
        subjects = list
        legacySubjects.filter { !Merge.isX(it) }.forEach { l ->
            sy.firstOrNull { norm(it.n) == norm(l.optString("n")) }?.let { canon[l.optString("id")] = it.id }
        }
    }

    private fun norm(n: String) = n.replace(Regex("\\s+"), " ").trim().lowercase()

    fun canonical(id: String) = canon[id] ?: id
    fun subjectOf(id: String): Subject? {
        if (id.isEmpty()) return null
        val c = canonical(id)
        return subjects.firstOrNull { it.id == c }
    }

    /** A task is shown when it is live and its subject (if any) still exists. */
    fun live(i: HwItem) = !i.x && (i.s.isEmpty() || subjectOf(i.s) != null)

    fun title(i: HwItem): String {
        if (i.t.isNotEmpty()) return i.t
        val base = subjectOf(i.s)?.name ?: ""
        val q = if (i.rg.isNotEmpty()) "Q ${i.rg}" else ""
        return listOf(base, q).filter { it.isNotEmpty() }.joinToString(" · ")
    }

    /** Syllabus subject whose name matches [name] (ignoring case and extra spaces); empty when none. */
    fun subjectIdByName(name: String): String {
        val nm = norm(name)
        return nodes.firstOrNull { it.k == "s" && !it.x && norm(it.n) == nm }?.id ?: ""
    }

    /** Title with the subject in front when the title does not already mention it. */
    fun full(i: HwItem): String {
        val sn = subjectOf(i.s)?.name
        val t = title(i)
        return if (sn != null && !t.lowercase().contains(sn.lowercase())) "$sn · $t" else t
    }

    fun subLine(i: HwItem): String {
        val t = title(i)
        return listOf(subjectOf(i.s)?.name ?: "", if (i.cn.isNotEmpty() && !t.contains(i.cn)) i.cn else "").filter { it.isNotEmpty() }.joinToString(" · ")
    }

    companion object {
        val COLORS = listOf(0xFFFF9F0A, 0xFF30C25B, 0xFFFF4D6D, 0xFF0A84FF, 0xFFA259F0, 0xFF1AB0C8, 0xFF5E5CE6, 0xFFFF6B3D)
        fun color(s: Subject?): Long = if (s == null) 0xFF0A84FF else COLORS[((s.colorIndex % 8) + 8) % 8]

        val EMPTY = DomainData(emptyList(), emptyList(), emptyList(), Profile())

        private fun arr(a: JSONArray?): List<JSONObject> = (0 until (a?.length() ?: 0)).mapNotNull { a!!.optJSONObject(it) }

        /** Builds the view from raw rows (id -> JSON text). Homework rows are merged item by item, newest change wins. */
        fun from(rows: Map<String, String?>): DomainData {
            var hw: JSONObject? = null
            var sy: JSONObject? = null
            for ((id, data) in rows) {
                if (data == null) continue
                val k = Merge.kind(id) ?: continue
                val d = try { JSONObject(data) } catch (e: Exception) { continue }
                if (!Merge.valid(k, d)) continue
                if (k == "hw") hw = if (hw == null) d else Merge.merge("hw", hw, d)
                else sy = if (sy == null) d else Merge.merge("sy", sy, d)
            }
            var prof = Profile()
            rows["zz_profile"]?.let { raw ->
                try {
                    val p = JSONObject(raw)
                    val pe = p.optJSONObject("pe")
                    prof = Profile(
                        name = p.optString("name"),
                        exam = pe?.optString("exam").orEmpty().takeIf { Dates.valid(it) } ?: "",
                        examName = pe?.optString("en").orEmpty().ifEmpty { "Exam" },
                        capHours = (pe?.optInt("cap", 6) ?: 6).takeIf { it in 1..14 } ?: 6,
                        minPerQ = (pe?.optInt("mpq", 3) ?: 3).takeIf { it in 1..30 } ?: 3,
                    )
                } catch (e: Exception) {
                }
            }
            val fl = ArrayList<FocusEntry>()
            try {
                val m = rows["zz_revlog"]?.let { JSONObject(it) }?.optJSONObject("m")
                if (m != null) for (k in m.keys()) m.optJSONObject(k)?.let { j -> FocusEntry.from(k, j)?.let { fl.add(it) } }
            } catch (e: Exception) {
            }
            val tdocs = rows.filter { Merge.kind(it.key) == "tl" }.values
            val (tf, tt) = Tl.fold(tdocs)
            var atRecs = JSONArray()
            for ((id, data) in rows) {
                if (data == null || Merge.kind(id) != "at") continue
                val d = try { JSONObject(data) } catch (e: Exception) { continue }
                if (!Merge.valid("at", d)) continue
                atRecs = Merge.list(atRecs, d.optJSONArray("recs"))
            }
            return DomainData(arr(hw?.optJSONArray("items")).map { HwItem(it) }, arr(sy?.optJSONArray("nodes")).map { SyNode(it) }, arr(hw?.optJSONArray("subjects")), prof, fl, tf.map { Folder(it) }, tt.map { TestRec(it) }, arr(atRecs))
        }
    }
}
