package com.ascend.app

/** Pure helpers kept free of Android classes so they can be unit-tested. */
object Logic {
    /** "morning" before 12:00, "afternoon" before 17:00, otherwise "evening" (same rule as the web app). */
    fun dayPart(hour: Int): String = if (hour < 12) "morning" else if (hour < 17) "afternoon" else "evening"

    fun firstName(full: String): String = full.trim().split(Regex("\\s+")).firstOrNull().orEmpty()

    fun greetingTail(hour: Int, name: String): String {
        val n = firstName(name)
        return dayPart(hour) + (if (n.isNotEmpty()) ", $n" else "") + "."
    }

    fun themeIsDark(mode: String?, systemDark: Boolean): Boolean = when (mode) {
        "light" -> false
        "dark" -> true
        else -> systemDark
    }
}
