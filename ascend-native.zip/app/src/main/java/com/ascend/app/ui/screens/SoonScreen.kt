package com.ascend.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.ui.Glass
import com.ascend.app.ui.Hit
import com.ascend.app.ui.Icons
import com.ascend.app.ui.SvgIcon
import com.ascend.app.ui.theme.Tk

/** Page header with an optional back arrow; page titles stay on one line. */
@Composable
fun PageHead(title: String, onBack: (() -> Unit)?) {
    val t = Tk.c
    Row(Modifier.padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            Hit(onClick = onBack, modifier = Modifier.padding(end = 8.dp)) { Column(Modifier.padding(8.dp)) { SvgIcon(Icons.back, t.ink) } }
        }
        Text(title, color = t.ink, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun SoonScreen(title: String, note: String, onBack: (() -> Unit)? = null) {
    val t = Tk.c
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead(title, onBack)
        Glass {
            Text("Coming soon", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(note, color = t.muted, fontSize = 14.sp)
        }
    }
}
