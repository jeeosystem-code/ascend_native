package com.ascend.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.Logic
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import java.util.Calendar

@Composable
fun HomeScreen(onGo: (String) -> Unit) {
    val t = Tk.c
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val tail = Logic.greetingTail(hour, "")
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text("Ascend", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            buildAnnotatedString {
                append("Good ")
                withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = t.accent)) { append(tail) }
            },
            color = t.ink, fontSize = 40.sp, fontWeight = FontWeight.Bold, lineHeight = 44.sp,
        )
        Spacer(Modifier.height(8.dp))
        Text("Your plan, practice and progress live here.", color = t.muted, fontSize = 15.sp)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            QuickAction("Practice", Modifier.weight(1f)) { onGo("prac") }
            QuickAction("Add task", Modifier.weight(1f)) { onGo("plan") }
        }
    }
}

@Composable
private fun QuickAction(label: String, modifier: Modifier, onClick: () -> Unit) {
    Glass(modifier = modifier, onClick = onClick) {
        Text(label, color = Tk.c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
