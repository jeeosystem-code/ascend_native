package com.ascend.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.Logic
import com.ascend.app.domain.Dates
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Planner
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import java.util.Calendar

@Composable
fun HomeScreen(domain: Domain, onGo: (String) -> Unit) {
    val t = Tk.c
    val data by domain.data.collectAsStateWithLifecycle()
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val tail = Logic.greetingTail(hour, data?.profile?.name.orEmpty())
    val today = Dates.today()
    val list = data?.let { Planner.day(it, today) }.orEmpty()
    val over = data?.let { Planner.overdue(it, today).size } ?: 0
    val stat = Planner.stat(list)
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text("Ascend", color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text(
            buildAnnotatedString {
                append("Good ")
                withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = t.accent)) { append(tail) }
            },
            color = t.ink, fontSize = 40.sp, fontWeight = FontWeight.Bold, lineHeight = 44.sp,
        )
        Spacer(Modifier.height(8.dp))
        val exam = data?.profile?.exam.orEmpty()
        val days = if (exam.isNotEmpty()) Dates.between(today, exam) else -1
        Text(
            if (days >= 0) "$days ${if (days == 1) "day" else "days"} to ${data?.profile?.examName}" else "Your plan, practice and progress live here.",
            color = t.muted, fontSize = 15.sp,
        )
        Spacer(Modifier.height(20.dp))
        Glass(Modifier.fillMaxWidth(), onClick = { onGo("plan") }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Today", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(if (data == null) "" else Planner.caption(stat, over), color = if (over > 0) t.bad else t.muted, fontSize = 13.sp)
            }
            val next = list.filter { !it.item.done }.take(4)
            if (data != null && next.isEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(if (stat.n > 0) "Everything for today is done." else "Nothing planned yet. Tap to plan your day.", color = t.ink, fontSize = 16.sp)
            }
            next.forEach { r ->
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(4.dp).height(20.dp).clip(RoundedCornerShape(2.dp)).background(Color(r.color)))
                    Text(r.title, color = t.ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    Text(Dates.clock(r.item.tm), color = t.muted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            QuickAction("Focus", Modifier.weight(1f)) { onGo("foc") }
            QuickAction("Practice", Modifier.weight(1f)) { onGo("prac") }
            QuickAction("Add task", Modifier.weight(1f)) { onGo("plan?add=true") }
        }
    }
}

@Composable
private fun QuickAction(label: String, modifier: Modifier, onClick: () -> Unit) {
    Glass(modifier = modifier, onClick = onClick) {
        Text(label, color = Tk.c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
