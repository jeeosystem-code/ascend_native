package com.ascend.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.At
import com.ascend.app.domain.Domain
import com.ascend.app.domain.DomainData
import com.ascend.app.domain.Sess
import com.ascend.app.domain.SyNode
import com.ascend.app.domain.TestRec
import com.ascend.app.domain.Tl
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.launch

fun chapterNode(d: DomainData, id: String): SyNode? = d.nodes.firstOrNull { it.id == id && !it.x && it.k == "c" }

private fun norm(s: String) = s.trim().lowercase().replace(Regex("\\s+"), " ")

/** Question numbers of one subject of a pattern. */
private fun perSub(t: TestRec): Int = t.secs.orEmpty().sumOf { it.count }

/** Tag each question of a paper with its syllabus chapter. */
@Composable
fun PaperTagging(d: DomainData, t: TestRec, onTag: (Int, List<Int>, String) -> Unit) {
    val tk = Tk.c
    val ns = Math.max(1, t.subs.size)
    val n = perSub(t)
    var sub by rememberSaveable { mutableStateOf(0) }
    var sel by remember { mutableStateOf(setOf<Int>()) }
    var anchor by remember { mutableStateOf(0) }
    var anchorOn by remember { mutableStateOf(true) }
    var single by rememberSaveable { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    val si = Math.min(sub, ns - 1)
    fun chOf(q: Int) = At.chapterOf(d.atts, t.id, "$si.$q")
    val tagged = (0 until ns).sumOf { s -> (1..n).count { At.chapterOf(d.atts, t.id, "$s.$it").isNotEmpty() } }

    fun tap(q: Int) {
        if (single) { sel = if (q in sel) sel - q else sel + q; return }
        if (anchor != 0 && anchor != q) {
            val a = Math.min(anchor, q); val b = Math.max(anchor, q)
            sel = if (anchorOn) sel + (a..b) else sel - (a..b).toSet()
            anchor = 0
        } else if (anchor == q) anchor = 0
        else { anchor = q; anchorOn = q !in sel }
    }

    if (ns > 1) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            t.subs.forEachIndexed { k, s -> Pill(s + "  " + (1..n).count { At.chapterOf(d.atts, t.id, "$k.$it").isNotEmpty() } + "/" + n, k == si) { sub = k; sel = emptySet(); anchor = 0 } }
        }
        Spacer(Modifier.height(10.dp))
    }
    Glass(Modifier.fillMaxWidth()) {
        Row { Text("Questions", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text("$tagged of ${ns * n} tagged", color = tk.muted, fontSize = 13.sp) }
        Spacer(Modifier.height(4.dp))
        Text(if (single) "Tap questions one by one." else "Tap a first and a last question to select all between.", color = tk.muted, fontSize = 12.5.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Range", !single) { single = false; anchor = 0 }
            Pill("One by one", single) { single = true; anchor = 0 }
        }
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..n).chunked(7).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { q ->
                        val on = q in sel; val tg = chOf(q).isNotEmpty(); val an = anchor == q
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                                .background(if (on) tk.accent.copy(alpha = 0.28f) else if (tg) tk.good.copy(alpha = 0.16f) else tk.line.copy(alpha = 0.5f))
                                .border(if (on || an) 1.5.dp else 0.dp, if (on) tk.accent else if (an) tk.ink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { tap(q) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("$q", color = tk.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (tg) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp).size(5.dp).clip(CircleShape).background(tk.good))
                        }
                    }
                    repeat(7 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
    val used = (1..n).mapNotNull { q -> chOf(q).takeIf { it.isNotEmpty() && chapterNode(d, it) != null } }.groupingBy { it }.eachCount()
    if (used.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Text("Chapters used", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("Tap one to select its questions.", color = tk.muted, fontSize = 12.5.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                used.forEach { (id, c) -> Pill((chapterNode(d, id)?.n ?: "Chapter") + " · " + c, false) { sel = (1..n).filter { chOf(it) == id }.toSet(); anchor = 0 } }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${sel.size} chosen", color = tk.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Pill(if (sel.isEmpty()) "All" else "None", false) { sel = if (sel.isEmpty()) (1..n).toSet() else emptySet(); anchor = 0 }
        Pill("Chapter", sel.isNotEmpty()) { if (sel.isNotEmpty()) pick = true }
    }
    if (pick) ChapterPicker(d, t.subs.getOrNull(si) ?: "", sel.size, { pick = false }) { id ->
        onTag(si, sel.sorted(), id); sel = emptySet(); anchor = 0; pick = false
    }
}

@Composable
private fun ChapterPicker(d: DomainData, subName: String, count: Int, onClose: () -> Unit, onPick: (String) -> Unit) {
    val tk = Tk.c
    var q by remember { mutableStateOf("") }
    val subjects = d.nodes.filter { it.k == "s" && !it.x }.sortedBy { it.o }
    val own = subjects.filter { norm(it.n) == norm(subName) }
    val shown = own.ifEmpty { subjects }
    SheetBox(onClose) {
        Text("$subName · $count selected", color = tk.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text("Choose chapter", color = tk.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Field(q, { q = it }, "Search chapter", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        var any = false
        shown.forEach { s ->
            val ks = d.nodes.filter { it.k == "c" && !it.x && it.p == s.id && (q.isBlank() || it.n.lowercase().contains(q.trim().lowercase())) }.sortedBy { it.o }
            if (ks.isEmpty()) return@forEach
            any = true
            if (shown.size > 1) Text(s.n, color = tk.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
            ks.forEach { c ->
                Text(c.n, color = tk.ink, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(c.id) }.padding(vertical = 12.dp, horizontal = 6.dp))
            }
        }
        if (!any) Text(if (subjects.isEmpty()) "Add chapters in the Syllabus first, then tag questions here." else "No chapter matches.", color = tk.muted, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Action2("Remove chapter from selected", tk.bad) { onPick("") }
    }
}

/** Mistake notebook and chapter report across all tests. */
@Composable
fun ReportsScreen(domain: Domain, practice: PracticeController, onPractice: () -> Unit, onBack: () -> Unit) {
    val tk = Tk.c
    val d by domain.data.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf("nb") }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead("Reports", onBack)
        val x = d
        if (x == null) { Text("Loading…", color = tk.muted); return@Column }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Mistake notebook", tab == "nb") { tab = "nb" }
            Pill("Chapter report", tab == "cr") { tab = "cr" }
        }
        Spacer(Modifier.height(12.dp))
        if (tab == "nb") Notebook(x, practice, onPractice) else ChapterReport(x)
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun Notebook(d: DomainData, practice: PracticeController, onPractice: () -> Unit) {
    val tk = Tk.c
    var f by rememberSaveable { mutableStateOf("all") }
    var rf by rememberSaveable { mutableStateOf(0) }
    val all = At.allLatest(d.atts, d.tests) { fid -> Tl.folder(d.folders, fid) != null }.filter { it.e.state == "w" || it.e.state == "s" }
    val cw = all.count { it.e.state == "w" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(all.size to "open", cw to "wrong", all.size - cw to "skipped").forEach { (v, l) ->
            Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tk.line.copy(alpha = 0.4f)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$v", color = tk.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(l, color = tk.muted, fontSize = 11.sp)
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("all" to "All", "w" to "Wrong", "s" to "Skipped").forEach { (k, l) -> Pill(l, f == k) { f = k } }
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        (listOf(0 to "Any reason") + At.RM + listOf(-1 to "Not tagged")).forEach { (k, l) -> Pill(l, rf == k) { rf = k } }
    }
    Spacer(Modifier.height(12.dp))
    if (all.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Text("Nothing to fix", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Wrong and skipped questions from your attempts collect here. Get one right in a later attempt and it leaves the list.", color = tk.muted, fontSize = 13.sp)
        }
        return
    }
    val list = all.filter { r ->
        val rm = r.a.rm(r.key)
        (f == "all" || r.e.state == f) && (rf == 0 || (if (rf == -1) rm == 0 else rm and rf != 0))
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.groupBy { it.t.id }.entries.sortedByDescending { it.value.size }.forEach { (tid, rows) ->
            val t = rows[0].t
            Glass(Modifier.fillMaxWidth()) {
                Row { Text(t.n, color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${rows.size}", color = tk.muted, fontSize = 13.sp) }
                rows.forEach { r ->
                    val rm = r.a.rm(r.key)
                    val tags = At.RM.filter { rm and it.first != 0 }.joinToString(", ") { it.second }
                    val c = chapterNode(d, At.chapterOf(d.atts, tid, r.key))?.n
                    val nt = r.a.nt(r.key)
                    val col = if (r.e.state == "w") tk.bad else Color(0xFFF59E0B)
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(col.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Text("${r.e.no}", color = col, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                        Column(Modifier.padding(start = 10.dp)) {
                            Text((if (r.e.state == "w") "Wrong" else "Skipped") + (if (t.subs.size > 1) " · " + t.subs.getOrNull(r.e.sub) else ""), color = tk.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(listOfNotNull(c, tags.ifEmpty { null } ?: (if (nt.isEmpty()) "No reason noted" else null), nt.ifEmpty { null }).joinToString(" · "), color = tk.muted, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Pill("Attempt these ${rows.size}", true) {
                    val cfg = Sess.attemptCfg(t.n + " · review", t.subs, t.secs.orEmpty(), 0L, t.id, "r", "", rows.map { it.key }.toSet())
                    if (cfg != null) { practice.open(cfg); onPractice() }
                }
            }
        }
    }
}

@Composable
private fun ChapterReport(d: DomainData) {
    val tk = Tk.c
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val rows = At.chapterReport(d.atts, d.tests, { fid -> Tl.folder(d.folders, fid) != null }, { chapterNode(d, it) != null })
    if (rows.isEmpty()) {
        Glass(Modifier.fillMaxWidth()) {
            Text("No chapter data yet", color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Open a test, tag its questions with chapters (Paper & chapters) and attempt it. Every test then adds to this report.", color = tk.muted, fontSize = 13.sp)
        }
        return
    }
    val lost = rows.sumOf { it.lost }; val qn = rows.sumOf { it.n }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(rows.size.toString() to "chapters", qn.toString() to "questions", Sess.num(Math.round(lost * 100) / 100.0) to "marks lost").forEach { (v, l) ->
            Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tk.line.copy(alpha = 0.4f)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(v, color = tk.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(l, color = tk.muted, fontSize = 11.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { o ->
            val node = chapterNode(d, o.id) ?: return@forEach
            val sn = d.nodes.firstOrNull { it.id == node.p }
            val col = if (o.att == 0) tk.muted else if (o.acc < 40) tk.bad else if (o.acc < 70) Color(0xFFF59E0B) else tk.good
            val isOpen = open == o.id
            Glass(Modifier.fillMaxWidth(), onClick = { open = if (isOpen) null else o.id }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(col))
                    Text(node.n, color = tk.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (o.att > 0) "${o.acc}%" else "–", color = col, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(tk.line)) { Box(Modifier.fillMaxWidth(if (o.att > 0) o.acc / 100f else 0f).height(5.dp).clip(RoundedCornerShape(3.dp)).background(col)) }
                Text((sn?.n?.let { "$it · " } ?: "") + o.n + (if (o.n == 1) " question" else " questions") + " · ${o.c} right · ${o.w} wrong · ${o.s} skipped", color = tk.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                if (isOpen) {
                    Text(qt(if (o.n > 0) Math.round(o.t.toDouble() / o.n).toInt() else 0) + " per question · −" + Sess.num(Math.round(o.lost * 100) / 100.0) + " marks · " + o.tests.size + (if (o.tests.size == 1) " test" else " tests"), color = tk.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    val rmTxt = At.RM.filter { (o.rm[it.first] ?: 0) > 0 }.joinToString(" · ") { it.second + " " + o.rm[it.first] }
                    Text(rmTxt.ifEmpty { "No reasons noted yet." }, color = tk.muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}
