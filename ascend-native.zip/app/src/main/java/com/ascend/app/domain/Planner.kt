package com.ascend.app.domain

/** A task as shown in the planner list. */
data class PlanRow(val item: HwItem, val title: String, val sub: String, val color: Long, val minutes: Int, val questions: Int)

data class DayStat(val n: Int, val done: Int, val minutes: Int, val questions: Int)

/** Planner rules ported from the web app (day list order, overdue, totals). */
object Planner {
    fun prRank(p: Int) = if (p in 1..3) 4 - p else 0

    fun questions(i: HwItem): Int {
        val r = if (i.rg.isNotEmpty()) Ranges.parse(i.rg) else null
        return if (r != null && r.ok) r.n else 0
    }

    fun minutes(i: HwItem, mpq: Int): Int {
        if (i.du > 0) return i.du
        val q = questions(i)
        return if (q > 0) Math.round(q.toDouble() * mpq).toInt() else 0
    }

    private fun row(d: DomainData, i: HwItem) = PlanRow(i, d.title(i), d.subLine(i), DomainData.color(d.subjectOf(i.s)), minutes(i, d.profile.minPerQ), questions(i))

    /** The tasks of one day: higher priority first, then timed tasks by time, then in the order they were added. */
    fun day(d: DomainData, key: String): List<PlanRow> =
        d.items.filter { d.live(it) && it.d == key }.map { row(d, it) }.sortedWith { a, b ->
            val pd = prRank(b.item.pr) - prRank(a.item.pr)
            if (pd != 0) return@sortedWith pd
            val at = a.item.tm.isNotEmpty()
            val bt = b.item.tm.isNotEmpty()
            if (at != bt) return@sortedWith if (at) -1 else 1
            if (a.item.tm != b.item.tm) return@sortedWith a.item.tm.compareTo(b.item.tm)
            a.item.o.compareTo(b.item.o)
        }

    /** Unfinished tasks from before [today], oldest first. */
    fun overdue(d: DomainData, today: String): List<PlanRow> =
        d.items.filter { d.live(it) && !it.done && Dates.valid(it.d) && it.d < today }
            .sortedWith(compareBy<HwItem>({ it.d }, { it.o })).map { row(d, it) }

    fun stat(list: List<PlanRow>) = DayStat(list.size, list.count { it.item.done }, list.sumOf { it.minutes }, list.sumOf { it.questions })

    /** "2 of 5 done", "All done · 5", "3 overdue", or "Plan anything" — the line shown on Home. */
    fun caption(s: DayStat, overdue: Int): String = when {
        s.n == 0 -> if (overdue > 0) "$overdue overdue" else "Plan anything"
        s.done == s.n -> "All done · ${s.n}"
        else -> "${s.done} of ${s.n} done" + (if (overdue > 0) " · $overdue late" else "")
    }
}
