package com.ascend.app.domain

/** A task as shown in the planner list. */
data class PlanRow(val item: HwItem, val title: String, val sub: String, val color: Long, val minutes: Int, val questions: Int)

data class DayStat(val n: Int, val done: Int, val minutes: Int, val questions: Int)

/** Planner rules ported from the web app (day list order, overdue, totals). */
object Planner {
    fun prRank(p: Int) = if (p in 1..3) 4 - p else 0

    fun questions(i: HwItem): Int {
        val r = if (i.rg.isNotEmpty()) Ranges.parse(i.rg) else null
        return if (r != null && r.ok) r.n else 0
    }

    fun minutes(i: HwItem, mpq: Int): Int {
        if (i.du > 0) return i.du
        val q = questions(i)
        return if (q > 0) Math.round(q.toDouble() * mpq).toInt() else 0
    }

    private fun row(d: DomainData, i: HwItem) = PlanRow(i, d.title(i), d.subLine(i), DomainData.color(d.subjectOf(i.s)), minutes(i, d.profile.minPerQ), questions(i))

    /** The tasks of one day: higher priority first, then timed tasks by time, then in the order they were added. */
    fun day(d: DomainData, key: String): List<PlanRow> =
        d.items.filter { d.live(it) && it.d == key }.map { row(d, it) }.sortedWith { a, b ->
            val pd = prRank(b.item.pr) - prRank(a.item.pr)
            if (pd != 0) return@sortedWith pd
            val at = a.item.tm.isNotEmpty()
            val bt = b.item.tm.isNotEmpty()
            if (at != bt) return@sortedWith if (at) -1 else 1
            if (a.item.tm != b.item.tm) return@sortedWith a.item.tm.compareTo(b.item.tm)
            a.item.o.compareTo(b.item.o)
        }

    /** Unfinished tasks from before [today], oldest first. */
    fun overdue(d: DomainData, today: String): List<PlanRow> =
        d.items.filter { d.live(it) && !it.done && Dates.valid(it.d) && it.d < today }
            .sortedWith(compareBy<HwItem>({ it.d }, { it.o })).map { row(d, it) }

    fun stat(list: List<PlanRow>) = DayStat(list.size, list.count { it.item.done }, list.sumOf { it.minutes }, list.sumOf { it.questions })

    /** "2 of 5 done", "All done · 5", "3 overdue", or "Plan anything" — the line shown on Home. */
    fun caption(s: DayStat, overdue: Int): String = when {
        s.n == 0 -> if (overdue > 0) "$overdue overdue" else "Plan anything"
        s.done == s.n -> "All done · ${s.n}"
        else -> "${s.done} of ${s.n} done" + (if (overdue > 0) " · $overdue late" else "")
    }

    /** A study plan: all tasks that share a plan id, with progress and a status (finished / behind / ahead / on track). */
    data class Plan(
        val id: String, val name: String, val items: List<HwItem>,
        val first: String, val last: String, val done: Int, val total: Int,
        val questions: Int, val questionsDone: Int, val overdue: Int, val status: String,
    ) {
        val finished get() = done == total
    }

    fun plans(d: DomainData, today: String): List<Plan> {
        val g = LinkedHashMap<String, MutableList<HwItem>>()
        d.items.forEach { if (d.live(it) && it.pl.isNotEmpty()) g.getOrPut(it.pl) { ArrayList() }.add(it) }
        val out = g.map { (id, items) ->
            var a = "9999"
            var z = "0000"
            var dn = 0
            var q = 0
            var qd = 0
            var od = 0
            var due = 0
            items.forEach {
                if (it.d < a) a = it.d
                if (it.d > z) z = it.d
                val n = questions(it)
                q += n
                if (it.done) { dn++; qd += n } else if (it.d < today) od++
                if (it.d <= today) due++
            }
            val fin = dn == items.size
            val st = if (fin) "fin" else if (od > 0) "late" else if (dn > due) "up" else "ok"
            Plan(id, items.firstOrNull { it.pn.isNotEmpty() }?.pn ?: "Plan", items, a, z, dn, items.size, q, qd, od, st)
        }
        return out.sortedWith { x, y -> if (x.finished != y.finished) (if (x.finished) 1 else -1) else x.first.compareTo(y.first) }
    }

    fun statusLabel(st: String) = when (st) { "fin" -> "Finished"; "late" -> "Behind"; "up" -> "Ahead"; else -> "On track" }

    /**
     * Moves unfinished [list] tasks over [n] days starting at [from], always giving the next task to the lightest day.
     * Returns task id -> new day. Other unfinished tasks already on those days count as load.
     */
    fun spread(d: DomainData, list: List<HwItem>, n: Int, from: String): Map<String, String> {
        val days = (0 until n).map { Dates.add(from, it) }
        val load = HashMap<String, Int>().also { m -> days.forEach { m[it] = 0 } }
        val ids = list.map { it.id }.toSet()
        d.items.forEach { if (!it.x && !it.done && it.id !in ids && load.containsKey(it.d)) load[it.d] = load[it.d]!! + (minutes(it, d.profile.minPerQ).takeIf { m -> m > 0 } ?: 15) }
        val out = LinkedHashMap<String, String>()
        list.sortedWith(compareBy<HwItem>({ it.d }, { it.o })).forEach {
            var best = days[0]
            days.forEach { k -> if (load[k]!! < load[best]!!) best = k }
            out[it.id] = best
            load[best] = load[best]!! + (minutes(it, d.profile.minPerQ).takeIf { m -> m > 0 } ?: 15)
        }
        return out
    }

    /** The 6 x 7 grid of days shown for the month that holds [anchor], starting on a Monday. */
    fun monthGrid(anchor: String): List<String> {
        val first = Dates.parse(anchor).withDayOfMonth(1).toString()
        val start = Dates.weekStart(first)
        return (0 until 42).map { Dates.add(start, it) }
    }
}
