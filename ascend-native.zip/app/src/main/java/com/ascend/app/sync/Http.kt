package com.ascend.app.sync

import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A failed web call. [status] is the HTTP code, [raw] the Firebase error text, message is the friendly sentence. */
class ApiError(val status: Int, val raw: String, message: String) : Exception(message)

object Http {
    /** Sends one request on a background thread and returns the response text (null when empty). Throws [ApiError] for HTTP errors. */
    suspend fun call(method: String, url: String, json: String? = null, form: String? = null, bearer: String? = null): String? =
        withContext(Dispatchers.IO) {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.requestMethod = method
                c.connectTimeout = 20000
                c.readTimeout = 30000
                if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
                val body = form ?: json
                if (body != null) {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", if (form != null) "application/x-www-form-urlencoded" else "application/json")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val raw = Protocol.errorRaw(text)
                    throw ApiError(code, raw, Protocol.fbMsg(raw, code))
                }
                text.ifEmpty { null }
            } finally {
                c.disconnect()
            }
        }
}
