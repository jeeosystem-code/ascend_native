package com.ascend.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** One question slot of a session: number, subject index, section index, marks, and the highest partial mark. */
data class QSpec(val no: Int, val sub: Int, val sec: Int, val pos: Double, val neg: Double, val pm: Int)

/** A section of a test pattern. */
data class Sec(val name: String = "", val count: Int = 10, val pos: Double = 4.0, val neg: Double = 1.0, val partial: Boolean = false) {
    val canPartial get() = pos >= 2 && Math.floor(pos) == pos
    val pm get() = if (partial && canPartial) (pos - 1).toInt() else 0
}

/**
 * What happened on one question. [st] is "A" (attempted), "N" (not attempted) or null (not answered yet); [t] is
 * the time spent in ms; [w] = wrong; [p] = partial marks (0 = none); [v] = visits; [f] = answered on first visit (1/0);
 * [d] = marked as a doubt. [extra] keeps fields this app does not know, so the web app's data is never cut.
 */
data class Res(
    val st: String? = null, val t: Long = 0, val w: Boolean = false, val p: Int = 0, val v: Int = 0,
    val f: Int? = null, val d: Boolean = false, val extra: JSONObject? = null,
) {
    fun toJson(): JSONObject {
        val o = JSONObject(extra?.toString() ?: "{}")
        o.put("st", st ?: JSONObject.NULL).put("t", t).put("w", w).put("p", p)
        if (v > 0) o.put("v", v) else o.remove("v")
        if (f != null) o.put("f", f) else o.remove("f")
        if (d) o.put("d", true) else o.remove("d")
        return o
    }

    companion object {
        private val KNOWN = setOf("st", "t", "w", "p", "v", "f", "d")
        fun from(j: JSONObject?): Res? {
            if (j == null) return null
            var extra: JSONObject? = null
            for (k in j.keys()) if (k !in KNOWN) { if (extra == null) extra = JSONObject(); extra.put(k, j.get(k)) }
            return Res(
                st = if (j.isNull("st")) null else j.optString("st").ifEmpty { null },
                t = j.optLong("t", 0), w = j.optBoolean("w", false), p = j.optInt("p", 0), v = j.optInt("v", 0),
                f = if (j.has("f") && !j.isNull("f")) j.optInt("f") else null, d = j.optBoolean("d", false) || j.optInt("d", 0) != 0, extra = extra,
            )
        }
    }
}

/** Session setup. Wraps the raw JSON so extra fields written by the web app survive a save. */
class Cfg(val j: JSONObject) {
    val kind: String get() = j.optString("kind", "hw")
    val name: String get() = j.optString("name")
    val id: String get() = j.optString("id")
    val date: Long get() = j.optLong("date", 0)
    val dur: Long get() = j.optLong("dur", 0)   // test time limit in ms; 0 = no limit
    val hw: String get() = j.optString("hw")
    val rng: String get() = j.optString("rng")
    val test get() = kind == "test"
    val tid: String get() = j.optString("tid")
    val tm: String get() = j.optString("tm", "e")
    val baseId: String get() = j.optString("base")
    val subs: List<String> get() = (0 until (j.optJSONArray("subs")?.length() ?: 0)).map { j.optJSONArray("subs")!!.optString(it) }
    val secs: List<Sec>
        get() = (0 until (j.optJSONArray("secs")?.length() ?: 0)).mapNotNull { j.optJSONArray("secs")!!.optJSONObject(it) }
            .map { Sec(it.optString("name"), it.optInt("count", 1), it.optDouble("pos", 0.0), it.optDouble("neg", 0.0), it.optBoolean("partial", false)) }
    val q: List<QSpec>
        get() {
            val a = j.optJSONArray("Q") ?: return emptyList()
            return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
                .map { QSpec(it.optInt("no"), it.optInt("sub"), it.optInt("sec"), it.optDouble("pos", 0.0), it.optDouble("neg", 0.0), it.optInt("pm", 0)) }
        }

    fun with(id: String, date: Long): Cfg {
        val c = JSONObject(j.toString())
        if (c.optString("id").isEmpty()) c.put("id", id)
        if (c.optLong("date", 0) == 0L) c.put("date", date)
        return Cfg(c)
    }

    fun put(key: String, value: Any): Cfg = Cfg(JSONObject(j.toString()).put(key, value))
}

/** A running (or finished) session, held as plain data so every step can be tested. */
data class Live(
    val cfg: Cfg, val q: List<QSpec>, val res: List<Res?>, val idx: Int = 0,
    val ready: Boolean = true, val running: Boolean = false, val paused: Boolean = false, val ended: Boolean = false,
    val base: Long = 0, val start: Long = 0, val pausedAt: Long = 0, val loadedAt: Long = 0,
    val testStart: Long = 0, val testUsed: Long = 0, val vs: Int = 0,
) {
    val n get() = q.size
    fun elapsed(now: Long): Long = base + (if (paused) pausedAt else now) - start
}

object Sess {
    // ---------- formatting ----------
    fun fmt(ms: Long): String {
        var s = Math.round(ms / 1000.0)
        val h = s / 3600
        val m = s % 3600 / 60
        s %= 60
        fun p(x: Long) = (if (x < 10) "0" else "") + x
        return if (h > 0) "$h:${p(m)}:${p(s)}" else "${p(m)}:${p(s)}"
    }

    fun num(x: Double): String {
        val r = Math.round(x * 100) / 100.0
        return if (r == Math.floor(r) && Math.abs(r) < 1e15) r.toLong().toString() else r.toString()
    }

    fun sg(x: Double) = (if (x > 0) "+" else "") + num(x)
    fun ng(x: Double) = if (x > 0) "−" + num(x) else "0"

    // ---------- setup ----------
    fun validateHw(from: Int?, to: Int?, pos: Double?, neg: Double?): String {
        if (from == null || to == null || from < 1 || to < 1) return "Enter a valid question range (starting from 1 or more)."
        if (to < from) return "The last question must be the same as or after the first."
        if (to - from + 1 > 300) return "Please keep a session to 300 questions or fewer."
        if (pos == null || pos < 0) return "Enter the marks for a correct answer."
        if (neg == null || neg < 0) return "Enter the negative marks (use 0 for none)."
        return ""
    }

    private fun base(kind: String, name: String, q: List<QSpec>): JSONObject {
        val a = JSONArray()
        q.forEach { a.put(JSONObject().put("no", it.no).put("sub", it.sub).put("sec", it.sec).put("pos", it.pos).put("neg", it.neg).put("pm", it.pm)) }
        return JSONObject().put("kind", kind).put("name", name).put("Q", a).put("subs", JSONArray()).put("secs", JSONArray()).put("dur", 0)
    }

    /** An attempt of a saved test: every question of its pattern, or only the keys "sub.no" in [only]. Null when nothing is left to attempt. */
    fun attemptCfg(name: String, subs: List<String>, secs: List<Sec>, durMs: Long, tid: String, tm: String, baseId: String, only: Set<String>?): Cfg? {
        val q = ArrayList<QSpec>()
        subs.forEachIndexed { si, _ ->
            var no = 0
            secs.forEachIndexed { ci, sc -> repeat(sc.count) { no++; if (only == null || "$si.$no" in only) q.add(QSpec(no, si, ci, sc.pos, sc.neg, sc.pm)) } }
        }
        if (q.isEmpty()) return null
        val j = base("test", name.trim().ifEmpty { "Untitled test" }, q)
        val sa = JSONArray(); subs.forEach { sa.put(it) }
        val ca = JSONArray(); secs.forEach { ca.put(JSONObject().put("name", it.name).put("count", it.count).put("pos", it.pos).put("neg", it.neg).put("partial", it.partial)) }
        j.put("subs", sa).put("secs", ca).put("dur", durMs).put("tid", tid).put("tm", tm).put("base", baseId)
        return Cfg(j)
    }

    /** A homework-style session over a question range. */
    fun hwCfg(name: String, from: Int, to: Int, pos: Double, neg: Double, hw: String = ""): Cfg {
        val q = (from..to).map { QSpec(it, 0, 0, pos, neg, 0) }
        val j = base("hw", name.trim().ifEmpty { "Untitled task" }, q).put("from", from).put("to", to).put("pos", pos).put("neg", neg)
        if (hw.isNotEmpty()) j.put("hw", hw)
        return Cfg(j)
    }

    /** A homework-style session over an explicit list of question numbers (used when continuing a task). */
    fun hwCfgList(name: String, list: List<Int>, pos: Double, neg: Double, hw: String): Cfg {
        val q = list.map { QSpec(it, 0, 0, pos, neg, 0) }
        return Cfg(base("hw", name, q).put("from", list.first()).put("to", list.last()).put("pos", pos).put("neg", neg).put("rng", Ranges.compress(list)).put("hw", hw))
    }

    fun validateTest(subs: List<String>, multi: Boolean, secs: List<Sec>, durText: String): String {
        if (durText.isNotEmpty() && (durText.toIntOrNull() ?: 0) < 1) return "Enter the test duration in minutes, or leave it empty."
        if (multi && subs.isEmpty()) return "Add at least one subject."
        if (secs.isEmpty()) return "Add at least one section."
        var tot = 0
        secs.forEachIndexed { i, s ->
            if (s.count < 1) return "Section ${i + 1}: enter the number of questions."
            if (s.pos < 0) return "Section ${i + 1}: enter the marks for a correct answer."
            if (s.neg < 0) return "Section ${i + 1}: enter the negative marks (0 for none)."
            tot += s.count
        }
        if (tot * (if (multi) subs.size else 1) > 300) return "Please keep a test to 300 questions or fewer."
        return ""
    }

    fun testCfg(name: String, subs: List<String>, secs: List<Sec>, durMin: Int): Cfg {
        val q = ArrayList<QSpec>()
        val list = if (subs.isEmpty()) listOf("") else subs
        list.forEachIndexed { si, _ ->
            var no = 0
            secs.forEachIndexed { ci, sc -> repeat(sc.count) { no++; q.add(QSpec(no, si, ci, sc.pos, sc.neg, sc.pm)) } }
        }
        val j = base("test", name.trim().ifEmpty { "Untitled test" }, q)
        val sa = JSONArray(); subs.forEach { sa.put(it) }
        val ca = JSONArray(); secs.forEach { ca.put(JSONObject().put("name", it.name).put("count", it.count).put("pos", it.pos).put("neg", it.neg).put("partial", it.partial)) }
        j.put("subs", sa).put("secs", ca).put("dur", durMin * 60000L)
        return Cfg(j)
    }

    // ---------- the run ----------
    fun launch(cfg: Cfg, now: Long, id: String): Live {
        val c = cfg.with(id, now)
        val q = c.q
        return Live(c, q, List(q.size) { null })
    }

    /** Opens question [i]: loads its saved time, counts a visit, restarts the clock. */
    private fun beginQ(l: Live, i: Int, now: Long): Live {
        val r = l.res.getOrNull(i) ?: Res()
        val nr = r.copy(v = r.v + 1)
        val res = l.res.toMutableList()
        res[i] = nr
        return l.copy(idx = i, res = res, paused = false, base = r.t, start = now, loadedAt = now, vs = l.q[i].sub)
    }

    fun begin(l: Live, now: Long, testElapsed: Long = 0): Live {
        val s = l.copy(ready = false, running = true, testStart = if (l.cfg.test) now - testElapsed else 0)
        return beginQ(s, s.idx, now)
    }

    private fun commit(l: Live, now: Long): Live {
        val res = l.res.toMutableList()
        val r = res[l.idx] ?: Res()
        res[l.idx] = r.copy(t = l.elapsed(now))
        return l.copy(res = res)
    }

    fun nextOpen(l: Live, from: Int): Int {
        for (k in 1 until l.n) {
            val j = (from + k) % l.n
            if (l.res[j]?.st == null) return j
        }
        return -1
    }

    /** Marks the current question attempted ("A") or not attempted ("N") and moves on. Ignores a double tap. */
    fun answer(l: Live, st: String, now: Long): Live {
        if (!l.running || now - l.loadedAt < 350) return l
        var s = commit(l, now)
        val res = s.res.toMutableList()
        val r = res[s.idx] ?: Res()
        val f = if (st == "A" && r.f == null) (if (r.v <= 1) 1 else 0) else r.f
        res[s.idx] = r.copy(st = st, w = false, p = 0, f = f)
        s = s.copy(res = res)
        val nx = nextOpen(s, s.idx)
        if (nx < 0) return end(s, now, alreadyCommitted = true)
        return beginQ(s, nx, now)
    }

    fun jump(l: Live, j: Int, now: Long): Live {
        if (!l.running || j == l.idx || j < 0 || j >= l.n) return l
        return beginQ(commit(l, now), j, now)
    }

    fun setPaused(l: Live, v: Boolean, now: Long): Live {
        if (!l.running || v == l.paused) return l
        return if (v) l.copy(paused = true, pausedAt = now) else l.copy(paused = false, start = l.start + (now - l.pausedAt))
    }

    fun end(l: Live, now: Long, alreadyCommitted: Boolean = false): Live {
        val s = if (alreadyCommitted) l else commit(l, now)
        val used = if (s.testStart > 0) minOf(now - s.testStart, if (s.cfg.dur > 0) s.cfg.dur else Long.MAX_VALUE) else 0
        return s.copy(running = false, paused = false, ended = true, ready = false, testUsed = used)
    }

    /** Time left on a timed test; null when untimed. */
    fun testLeft(l: Live, now: Long): Long? = if (l.cfg.test && l.cfg.dur > 0 && l.testStart > 0) l.cfg.dur - (now - l.testStart) else null

    fun timeUp(l: Live, now: Long) = l.running && (testLeft(l, now) ?: 1) <= 0

    // ---------- scoring ----------
    fun qMarks(l: Live, i: Int): Double {
        val r = l.res[i]
        val q = l.q[i]
        if (r == null || r.st != "A") return 0.0
        if (r.w) return -q.neg
        if (r.p > 0) return r.p.toDouble()
        return q.pos
    }

    fun score(l: Live): Double = (0 until l.n).sumOf { qMarks(l, it) }
    fun maxMarks(l: Live): Double = l.q.sumOf { it.pos }

    data class SubStat(var sc: Double = 0.0, var mx: Double = 0.0, var att: Int = 0, var sk: Int = 0, var cnt: Int = 0, var t: Long = 0)
    data class Calc(
        val att: Int, val sk: Int, val un: Int, val wr: Int, val pt: Int, val tot: Long, val tA: Long,
        val fi: Int, val si: Int, val vis: Int, val avg: Long, val score: Double, val cor: Int, val subs: List<SubStat>,
    )

    fun calc(l: Live): Calc {
        var att = 0; var sk = 0; var un = 0; var wr = 0; var pt = 0
        var tot = 0L; var tA = 0L; var fi = -1; var si = -1
        val ns = maxOf(1, l.cfg.subs.size)
        val subs = List(ns) { SubStat() }
        l.res.forEachIndexed { i, r ->
            val S = subs[l.q[i].sub.coerceIn(0, ns - 1)]
            S.cnt++; S.mx += l.q[i].pos
            if (r == null) { un++; return@forEachIndexed }
            tot += r.t; S.t += r.t
            if (r.st == null) { un++; return@forEachIndexed }
            if (r.st == "A") {
                att++; S.att++
                if (r.w) wr++ else if (r.p > 0) pt++
                S.sc += qMarks(l, i)
            } else { sk++; S.sk++ }
            tA += r.t
            if (fi < 0 || r.t < l.res[fi]!!.t) fi = i
            if (si < 0 || r.t > l.res[si]!!.t) si = i
        }
        val vis = att + sk
        return Calc(att, sk, un, wr, pt, tot, tA, fi, si, vis, if (vis > 0) tA / vis else 0, score(l), att - wr - pt, subs)
    }

    /** Result chips: right -> wrong -> (partial steps) -> right. */
    fun cycleMark(l: Live, i: Int): Live {
        val r = l.res[i] ?: return l
        val pm = l.q[i].pm
        val nr = if (r.w) r.copy(w = false, p = if (pm > 0) 1 else 0)
        else if (r.p > 0) r.copy(p = if (r.p < pm) r.p + 1 else 0)
        else r.copy(w = true, p = 0)
        val res = l.res.toMutableList(); res[i] = nr
        return l.copy(res = res)
    }

    fun toggleDoubt(l: Live, i: Int): Live {
        val res = l.res.toMutableList()
        val r = res[i] ?: Res()
        res[i] = r.copy(d = !r.d)
        return l.copy(res = res)
    }

    fun qLabel(l: Live, i: Int): String = (if (l.cfg.subs.size > 1) l.cfg.subs.getOrElse(l.q[i].sub) { "" } + " · " else "") + "Q" + l.q[i].no

    // ---------- saved record (same shape as the web app's session row) ----------
    fun recordJson(l: Live, savedAt: Long): String {
        val res = JSONArray(); l.res.forEach { res.put(it?.toJson() ?: JSONObject.NULL) }
        return JSONObject().put("id", l.cfg.id).put("v", 1).put("kind", l.cfg.kind).put("name", l.cfg.name).put("date", l.cfg.date)
            .put("cfg", l.cfg.j).put("res", res).put("testUsed", l.testUsed).put("savedAt", savedAt).toString()
    }

    /** Reads a saved record back into an ended session. Returns null when the shape is wrong (same checks as the web app). */
    fun parseRecord(text: String?): Live? {
        val o = try { JSONObject(text ?: return null) } catch (e: Exception) { return null }
        val cj = o.optJSONObject("cfg") ?: return null
        val cfg = Cfg(cj)
        if (cfg.kind != "hw" && cfg.kind != "test") return null
        val q = cfg.q
        val ra = o.optJSONArray("res") ?: return null
        if (q.isEmpty() || ra.length() != q.size || cfg.id.isEmpty()) return null
        val res = (0 until ra.length()).map { Res.from(ra.optJSONObject(it)) }
        return Live(cfg, q, res, ready = false, ended = true, testUsed = o.optLong("testUsed", 0))
    }

    fun draftJson(l: Live, now: Long): String {
        val res = JSONArray(); l.res.forEach { res.put(it?.toJson() ?: JSONObject.NULL) }
        return JSONObject().put("v", 1).put("cfg", l.cfg.j).put("res", res).put("idx", l.idx).put("curT", l.elapsed(now))
            .put("testEl", if (l.testStart > 0) now - l.testStart else 0).put("savedAt", now).toString()
    }

    class Draft(val live: Live, val curT: Long, val testEl: Long, val savedAt: Long)

    fun parseDraft(text: String?): Draft? {
        val o = try { JSONObject(text ?: return null) } catch (e: Exception) { return null }
        val rec = parseRecord(text) ?: return null
        if (!o.has("savedAt")) return null
        return Draft(rec.copy(idx = o.optInt("idx", 0).coerceIn(0, rec.n - 1)), o.optLong("curT", 0), o.optLong("testEl", 0), o.optLong("savedAt", 0))
    }

    /** Continues a saved draft: the clock restarts from the time already spent on the open question. */
    fun resume(d: Draft, now: Long): Live {
        val res = d.live.res.toMutableList()
        val r = res[d.live.idx] ?: Res()
        res[d.live.idx] = r.copy(t = maxOf(r.t, d.curT))
        return begin(d.live.copy(res = res, ended = false, ready = true), now, d.testEl)
    }

    // ---------- shareable text ----------
    fun reportText(l: Live, dateText: String): String {
        val o = calc(l); val c = l.cfg; val T = c.test; val multi = c.subs.size > 1
        val L = ArrayList<String>()
        L.add("📊 ASCEND – " + (if (T) "TEST" else "SESSION") + " REPORT")
        L.add((if (T) "Test: " else "Task: ") + c.name)
        L.add("Date: $dateText")
        if (T) {
            if (multi) L.add("Subjects: " + c.subs.joinToString(", "))
            L.add("Pattern" + (if (multi) " (per subject)" else "") + ":")
            c.secs.forEachIndexed { i, s -> L.add("  " + (s.name.ifEmpty { "Section " + (i + 1) }) + ": " + s.count + " Q, +" + num(s.pos) + " / " + ng(s.neg) + (if (s.pm > 0) ", partial marking" else "")) }
            L.add("Duration: " + (if (c.dur > 0) fmt(c.dur) else "no limit") + " · time used " + fmt(l.testUsed))
        } else {
            val j = c.j
            L.add(if (c.rng.isNotEmpty()) "Questions: ${c.rng} (${l.n} questions)" else "Range: Q${j.optInt("from")} to Q${j.optInt("to")} (${l.n} questions)")
            L.add("Marking: +" + num(j.optDouble("pos")) + " / −" + num(j.optDouble("neg")))
        }
        L.add("")
        L.add("SCORE: " + num(o.score) + " / " + num(maxMarks(l)))
        L.add("Attempted: ${o.att} (correct ${o.cor}, wrong ${o.wr}" + (if (o.pt > 0) ", partial ${o.pt}" else "") + ")")
        L.add("Not attempted: ${o.sk}")
        if (o.un > 0) L.add("Unanswered: ${o.un}")
        if (o.att > 0) L.add("Accuracy: " + Math.round(o.cor * 100.0 / o.att) + "%")
        L.add("Total time: " + fmt(if (T) l.testUsed else o.tot))
        if (o.vis > 0) {
            L.add("Avg per question: " + fmt(o.avg))
            L.add("Fastest: " + qLabel(l, o.fi) + " (" + fmt(l.res[o.fi]!!.t) + ")")
            L.add("Slowest: " + qLabel(l, o.si) + " (" + fmt(l.res[o.si]!!.t) + ")")
        }
        if (multi) {
            L.add(""); L.add("SUBJECT-WISE")
            o.subs.forEachIndexed { k, S -> L.add(c.subs.getOrElse(k) { "" } + ": " + num(S.sc) + " / " + num(S.mx) + " · attempted ${S.att}, not attempted ${S.sk} · " + fmt(S.t)) }
        }
        L.add(""); L.add("QUESTION-WISE")
        var last = -1
        l.res.forEachIndexed { i, r ->
            val q = l.q[i]
            if (multi && q.sub != last) { last = q.sub; L.add("— " + c.subs.getOrElse(q.sub) { "" } + " —") }
            val ql = "Q${q.no}: "
            if (r == null || r.st == null) L.add(ql + "Unanswered" + (if (r != null && r.t > 0) " · " + fmt(r.t) + " spent" else ""))
            else if (r.st == "N") L.add(ql + "Not attempted · " + fmt(r.t))
            else L.add(ql + "Attempted " + (if (r.w) "✗ wrong" else if (r.p > 0) "½ partial" else "✓ correct") + " · " + fmt(r.t) + " [" + sg(qMarks(l, i)) + "]")
        }
        return L.joinToString("\n")
    }
}
