package com.ascend.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.Dates
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Planner
import com.ascend.app.domain.Sec
import com.ascend.app.domain.Sess
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The Practice tab: shows the setup page, or the running session / result when one is open. */
@Composable
fun PracticeHost(practice: PracticeController, domain: Domain, onHome: () -> Unit, onTests: () -> Unit = {}) {
    val live by practice.live.collectAsStateWithLifecycle()
    val l = live
    if (l == null) SetupScreen(practice, domain, onTests)
    else SessionScreen(practice, domain, l, onHome, onTests)
}

class SecEdit(var name: String = "", var count: String = "10", var pos: String = "4", var neg: String = "1", var partial: Boolean = false) {
    fun toSec() = Sec(
        name, count.toIntOrNull() ?: 0, pos.toDoubleOrNull() ?: -1.0,
        if (neg.isBlank()) 0.0 else (neg.toDoubleOrNull() ?: -1.0), partial,
    )
}

fun presetSecs(k: String): List<SecEdit> = when (k) {
    "adv" -> listOf(SecEdit("Single correct", "4", "3", "1"), SecEdit("Multiple correct", "4", "4", "2", true), SecEdit("Numerical", "6", "4", "0"))
    "neet" -> listOf(SecEdit("MCQ", "45", "4", "1"))
    else -> listOf(SecEdit("", "10", "4", "1"))
}

fun presetSubs(k: String): List<String> = when (k) {
    "neet" -> listOf("Physics", "Chemistry", "Botany", "Zoology")
    else -> listOf("Physics", "Chemistry", "Mathematics")
}

@Composable
fun Pill(label: String, on: Boolean, onClick: () -> Unit) {
    val t = Tk.c
    Box(
        Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else t.line.copy(alpha = 0.5f))
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 9.dp),
    ) { Text(label, color = if (on) t.accent else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, numeric: Boolean = false, decimal: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else if (numeric) KeyboardType.Number else KeyboardType.Text),
    )
}

@Composable
private fun SetupScreen(practice: PracticeController, domain: Domain, onTests: () -> Unit) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    val data by domain.data.collectAsStateWithLifecycle()
    val draftRow by domain.draftRow.collectAsStateWithLifecycle(initialValue = null)
    val rows by domain.sessionRows.collectAsStateWithLifecycle(initialValue = emptyList())
    var mode by remember { mutableStateOf("hw") }
    val draft = remember(draftRow?.data) { Sess.parseDraft(draftRow?.data) }
    val recent = remember(rows) { rows.mapNotNull { r -> Sess.parseRecord(r.data)?.let { r.id to it } }.sortedByDescending { it.second.cfg.date }.take(6) }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead("Practice", null)
        if (draft != null) {
            val done = draft.live.res.count { it?.st != null }
            Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { practice.resume(draft) }) {
                Text("Resume · " + (if (draft.live.cfg.test) "Test" else "Homework"), color = t.accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(draft.live.cfg.name, color = t.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$done of ${draft.live.n} answered", color = t.muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
        val plan = data?.let { d -> Planner.day(d, Dates.today()).filter { !it.item.done && com.ascend.app.domain.Ranges.numbers(it.item.rg).isNotEmpty() }.take(5) }.orEmpty()
        if (plan.isNotEmpty()) {
            Text("From your plan", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                plan.forEach { x ->
                    Pill(x.title.take(32), false) { scope.launch { practice.openTask(x.item, data!!.full(x.item), practice.marks()) } }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Glass(Modifier.fillMaxWidth(), onClick = onTests) {
            Text("Test folders and analysis", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Your mock and subject tests, question marking and results", color = t.muted, fontSize = 12.5.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(t.line.copy(alpha = 0.45f)).padding(3.dp)) {
            listOf("hw" to "Homework", "test" to "Test").forEach { (k, label) ->
                val on = mode == k
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable { mode = k }.padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = if (on) t.accent else t.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (mode == "hw") HomeworkForm(practice) else TestForm(practice)
        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("Recent sessions", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recent.forEach { (_, s) ->
                    val c = Sess.calc(s)
                    Glass(Modifier.fillMaxWidth(), onClick = { practice.view(s) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.cfg.name, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(dateText(s.cfg.date) + " · ${c.att} attempted", color = t.muted, fontSize = 12.5.sp)
                            }
                            Text(Sess.num(c.score) + " / " + Sess.num(Sess.maxMarks(s)), color = t.accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(96.dp))
    }
}

fun dateText(ms: Long): String = SimpleDateFormat("d MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))

@Composable
private fun HomeworkForm(practice: PracticeController) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var from by remember { mutableStateOf("1") }
    var to by remember { mutableStateOf("") }
    var pos by remember { mutableStateOf("4") }
    var neg by remember { mutableStateOf("1") }
    var err by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    if (!loaded) {
        loaded = true
        scope.launch { val m = practice.marks(); pos = Sess.num(m.first); neg = Sess.num(m.second) }
    }
    val f = from.toIntOrNull(); val tt = to.toIntOrNull(); val p = pos.toDoubleOrNull(); val n = if (neg.isBlank()) 0.0 else neg.toDoubleOrNull()
    val e = Sess.validateHw(f, tt, p, n)
    Glass(Modifier.fillMaxWidth()) {
        Field(name, { name = it.take(60) }, "Task name (optional)", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(from, { from = it.filter(Char::isDigit).take(3); err = "" }, "From Q", Modifier.weight(1f), numeric = true)
            Field(to, { to = it.filter(Char::isDigit).take(3); err = "" }, "To Q", Modifier.weight(1f), numeric = true)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(pos, { pos = it.take(5); err = "" }, "Correct +", Modifier.weight(1f), decimal = true)
            Field(neg, { neg = it.take(5); err = "" }, "Wrong −", Modifier.weight(1f), decimal = true)
        }
        if (e.isEmpty()) {
            val q = tt!! - f!! + 1
            Spacer(Modifier.height(8.dp))
            Text("$q question" + (if (q > 1) "s" else "") + " · max " + Sess.num(q * p!!) + " marks", color = t.muted, fontSize = 13.sp)
        }
        if (err.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(err, color = t.bad, fontSize = 13.sp) }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = {
        if (e.isNotEmpty()) err = e
        else { practice.rememberMarks(p!!, n!!); practice.open(Sess.hwCfg(name, f!!, tt!!, p, n)) }
    }) { Text("Start session", color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
}

/** Starting values when a test paper pattern is edited. */
class PatternInit(val name: String, val dur: Int, val subs: List<String>, val secs: List<Sec>)

@Composable
private fun TestForm(practice: PracticeController) {
    PatternForm(null, null, "Start test") { name, subs, secs, dur -> practice.open(Sess.testCfg(name, subs, secs, dur)) }
}

private fun secEdit(s: Sec) = SecEdit(s.name, s.count.toString(), Sess.num(s.pos), Sess.num(s.neg), s.partial)

/**
 * The paper pattern form: subjects (when several), sections with marks and partial marking, time limit.
 * [fixedMulti] = null shows a "Several subjects" switch; true/false fixes it (test folders). [init] fills an existing pattern.
 */
@Composable
fun PatternForm(fixedMulti: Boolean?, init: PatternInit?, submitLabel: String, nameLabel: String = "Test name (optional)", onGo: (String, List<String>, List<Sec>, Int) -> Unit) {
    val t = Tk.c
    var name by remember { mutableStateOf(init?.name ?: "") }
    var multi by remember { mutableStateOf(fixedMulti ?: (init != null && init.subs.size > 1)) }
    var on by remember { mutableStateOf(if (init != null) "" else if (multi) "main" else "custom") }
    val subs = remember { mutableStateListOf<String>().also { l -> if (init != null) l.addAll(init.subs) else if (multi) l.addAll(presetSubs("main")) } }
    val secs = remember { mutableStateListOf(*(if (init != null) init.secs.map { secEdit(it) } else presetSecs(if (multi) "main" else "custom")).toTypedArray()) }
    var tick by remember { mutableStateOf(0) }          // bumps to redraw after editing a SecEdit in place
    var newSub by remember { mutableStateOf("") }
    var dur by remember { mutableStateOf(if (init != null && init.dur > 0) init.dur.toString() else "") }
    var err by remember { mutableStateOf("") }
    val sl = secs.map { it.toSec() }
    val e = Sess.validateTest(subs.toList(), multi, sl, dur)
    tick.let { }

    Glass(Modifier.fillMaxWidth()) {
        Field(name, { name = it.take(60) }, nameLabel, Modifier.fillMaxWidth())
        if (fixedMulti == null) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Several subjects", color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Switch(checked = multi, onCheckedChange = { v ->
                    multi = v; on = if (v) "main" else "custom"
                    subs.clear(); if (v) subs.addAll(presetSubs("main"))
                    secs.clear(); secs.addAll(presetSecs(if (v) "main" else "custom"))
                })
            }
        }
        if (multi) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("main" to "Default", "adv" to "Preset 2", "neet" to "Preset 3", "custom" to "Custom").forEach { (k, label) ->
                    Pill(label, on == k) {
                        on = k; secs.clear(); secs.addAll(presetSecs(k))
                        if (k != "custom") { subs.clear(); subs.addAll(presetSubs(k)) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subs.toList().forEachIndexed { i, s -> Pill("$s  ×", false) { subs.removeAt(i); on = "" } }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Field(newSub, { newSub = it.take(20) }, "Add subject", Modifier.weight(1f))
                Pill("Add", false) {
                    val v = newSub.trim()
                    if (v.isNotEmpty() && subs.size < 8 && subs.none { it.equals(v, true) }) { subs.add(v); newSub = ""; on = "" }
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("custom" to "Custom", "adv" to "Preset 2", "neet" to "Preset 3").forEach { (k, label) ->
                    Pill(label, on == k) { on = k; secs.clear(); secs.addAll(presetSecs(k)) }
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    secs.forEachIndexed { i, s ->
        Glass(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Field(s.name, { s.name = it.take(28); on = ""; tick++ }, "Section name (optional)", Modifier.weight(1f))
                if (secs.size > 1) Text("Remove", color = t.bad, fontSize = 13.sp, modifier = Modifier.clickable { secs.removeAt(i); on = "" }.padding(10.dp))
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(s.count, { s.count = it.filter(Char::isDigit).take(3); on = ""; tick++ }, "Questions", Modifier.weight(1f), numeric = true)
                Field(s.pos, { s.pos = it.take(5); on = ""; tick++ }, "Correct +", Modifier.weight(1f), decimal = true)
                Field(s.neg, { s.neg = it.take(5); on = ""; tick++ }, "Wrong −", Modifier.weight(1f), decimal = true)
            }
            val can = s.toSec().canPartial
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Text("Partial marks" + (if (can) "" else " (needs whole marks of 2 or more)"), color = if (can) t.ink else t.muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Switch(checked = s.partial && can, enabled = can, onCheckedChange = { s.partial = it; on = ""; tick++ })
            }
        }
    }
    Pill("+ Add section", false) { secs.add(SecEdit("", "5", "4", "1")); on = "" }
    Spacer(Modifier.height(10.dp))
    Glass(Modifier.fillMaxWidth()) {
        Field(dur, { dur = it.filter(Char::isDigit).take(3); err = "" }, "Time limit in minutes (optional)", Modifier.fillMaxWidth(), numeric = true)
        if (e.isEmpty()) {
            val k = if (multi) subs.size else 1
            val q = sl.sumOf { it.count }
            val mx = sl.sumOf { it.count * it.pos }
            Spacer(Modifier.height(8.dp))
            Text((if (multi) "$k subject" + (if (k > 1) "s" else "") + " · " else "") + "${q * k} questions · max " + Sess.num(mx * k) + " marks", color = t.muted, fontSize = 13.sp)
        }
        if (err.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(err, color = t.bad, fontSize = 13.sp) }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = {
        if (e.isNotEmpty()) err = e
        else onGo(name, if (multi) subs.toList() else emptyList(), sl, dur.toIntOrNull() ?: 0)
    }) { Text(submitLabel, color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
}
