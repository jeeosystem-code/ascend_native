package com.ascend.app.ui

import android.graphics.Color as AColor
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ascend.app.Logic
import com.ascend.app.data.Keys
import com.ascend.app.data.Store
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.ascend.app.domain.Domain
import com.ascend.app.sync.Account
import com.ascend.app.ui.screens.PlanScreen
import com.ascend.app.ui.screens.AccountScreen
import com.ascend.app.ui.screens.HomeScreen
import com.ascend.app.ui.screens.SettingsScreen
import com.ascend.app.ui.screens.PracticeHost
import kotlinx.coroutines.launch
import com.ascend.app.practice.PracticeController
import com.ascend.app.ui.screens.FocusScreen
import com.ascend.app.focus.FocusController
import com.ascend.app.ui.screens.SoonScreen
import com.ascend.app.ui.screens.TestsScreen
import com.ascend.app.ui.screens.ReportsScreen
import com.ascend.app.ui.theme.AscendTheme
import com.ascend.app.ui.theme.Tk
import com.ascend.app.ui.theme.systemDark

@Composable
fun AscendRoot(store: Store, account: Account, domain: Domain, focus: FocusController, practice: PracticeController) {
    val mode by store.watch(Keys.THEME).collectAsStateWithLifecycle(initialValue = null)
    val dark = Logic.themeIsDark(mode, systemDark())
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(dark) {
        val style = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT) else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }
    AscendTheme(dark) { Shell(store, account, domain, focus, practice, mode ?: "system") }
}

private val TABS = listOf(
    Triple("home", "Home", Icons.home),
    Triple("plan", "Plan", Icons.plan),
    Triple("prac", "Practice", Icons.practice),
    Triple("trk", "Track", Icons.track),
    Triple("more", "More", Icons.more),
)
private val MORE_ROUTES = setOf("syl", "rep", "acc", "set", "foc")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Shell(store: Store, account: Account, domain: Domain, focus: FocusController, practice: PracticeController, mode: String) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = (entry?.destination?.route ?: "home").substringBefore("?")
    var more by remember { mutableStateOf(false) }
    val t = Tk.c
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var lastBack by remember { mutableLongStateOf(0L) }

    fun go(r: String) {
        more = false
        nav.navigate(r) {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    // Home: press Back twice to leave the app.
    BackHandler(enabled = route == "home" && !more) {
        val now = System.currentTimeMillis()
        if (now - lastBack < 2000) (ctx as ComponentActivity).finish()
        else { lastBack = now; Toast.makeText(ctx, "Press back again to exit", Toast.LENGTH_SHORT).show() }
    }

    Scaffold(
        containerColor = t.bg,
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            val inSession by practice.live.collectAsStateWithLifecycle()
            if (!(route == "prac" && inSession != null)) Dock(selected = if (route in MORE_ROUTES) "more" else if (route == "tests") "prac" else route) { r -> if (r == "more") more = true else go(r) }
        },
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(domain, onGo = { go(it) }) }
            composable("plan?add={add}", arguments = listOf(navArgument("add") { type = NavType.BoolType; defaultValue = false })) { e ->
                PlanScreen(domain, e.arguments?.getBoolean("add") == true, onPractice = { item ->
                    scope.launch { practice.openTask(item, domain.data.value?.full(item) ?: item.t, practice.marks()); go("prac") }
                })
            }
            composable("prac") { PracticeHost(practice, domain, onHome = { go("home") }, onTests = { go("tests") }) }
            composable("tests") { TestsScreen(domain, practice, onPractice = { go("prac") }, onBack = { nav.popBackStack() }) }
            composable("trk") { SoonScreen("Track", "Stage 7 · tracker and revision") }
            composable("syl") { SoonScreen("Syllabus", "Stage 7 · syllabus", onBack = { nav.popBackStack() }) }
            composable("rep") { ReportsScreen(domain, practice, onPractice = { go("prac") }, onBack = { nav.popBackStack() }) }
            composable("foc") { FocusScreen(focus, domain, onBack = { nav.popBackStack() }) }
            composable("acc") { AccountScreen(account, onBack = { nav.popBackStack() }) }
            composable("set") { SettingsScreen(store, domain, mode, onBack = { nav.popBackStack() }) }
        }
    }

    if (more) {
        ModalBottomSheet(onDismissRequest = { more = false }, containerColor = t.card) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
                listOf("foc" to "Focus timer", "syl" to "Syllabus", "rep" to "Reports", "acc" to "Account & backup", "set" to "Settings").forEach { (r, label) ->
                    Text(
                        label, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { go(r) }.padding(vertical = 16.dp, horizontal = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun Dock(selected: String, onTap: (String) -> Unit) {
    val t = Tk.c
    Row(
        Modifier.fillMaxWidth().background(t.card.copy(alpha = if (t.dark) 0.94f else 0.92f)).navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        TABS.forEach { (r, label, icon) ->
            val on = r == selected
            val c = if (on) t.accent else t.muted
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (on) t.accent.copy(alpha = 0.14f) else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable { onTap(r) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                SvgIcon(icon, c)
                Text(label, color = c, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
