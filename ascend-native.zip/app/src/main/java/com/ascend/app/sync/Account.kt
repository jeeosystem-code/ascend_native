package com.ascend.app.sync

import com.ascend.app.data.Keys
import com.ascend.app.data.Row
import com.ascend.app.data.RowDao
import com.ascend.app.data.Store
import com.ascend.app.domain.Merge
import java.io.IOException
import java.net.URLEncoder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

data class Session(val uid: String, val email: String, val idToken: String, val refreshToken: String, val expiresAt: Long) {
    fun toJson(): String = JSONObject().put("prov", "fb").put("uid", uid).put("email", email)
        .put("access_token", idToken).put("refresh_token", refreshToken).put("expires_at", expiresAt).toString()

    companion object {
        fun fromJson(s: String?): Session? = try {
            val j = JSONObject(s ?: "")
            if (j.optString("prov") != "fb" || j.optString("uid").isEmpty() || j.optString("refresh_token").isEmpty()) null
            else Session(j.getString("uid"), j.optString("email"), j.optString("access_token"), j.getString("refresh_token"), j.optLong("expires_at"))
        } catch (e: Exception) {
            null
        }
    }
}

data class AccountState(
    val ready: Boolean = false,
    val email: String? = null,
    val busy: Boolean = false,
    val message: String = "",
    val lastSync: Long = 0,
    val rows: Int = 0,
    val sessions: Int = 0,
    val pending: Int = 0,
)

/** Sign-in, token refresh, and the two-way sync of cloud rows. Same protocol as the web app: newest change wins. */
class Account(private val store: Store, private val rows: RowDao) {
    private val _state = MutableStateFlow(AccountState())
    val state: StateFlow<AccountState> = _state
    private var sess: Session? = null
    private val lock = Mutex()
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Default)
    private var soon: kotlinx.coroutines.Job? = null

    /** Sends fresh changes shortly after they are made (waits 1.5 s so a burst of edits goes out together). */
    fun syncSoon() {
        soon?.cancel()
        soon = scope.launch { kotlinx.coroutines.delay(1500); sync() }
    }

    private fun now() = System.currentTimeMillis()
    private fun say(m: String) = _state.update { it.copy(message = m) }

    private fun friendly(e: Throwable): String = when (e) {
        is ApiError -> e.message ?: "Error ${e.status}"
        is IOException -> "Can't reach Firebase. Check your internet."
        else -> e.message ?: e.javaClass.simpleName
    }

    private suspend fun counts() {
        val pending = rows.dirty().size
        _state.update { it.copy(rows = rows.live(), sessions = rows.sessions(), pending = pending) }
    }

    suspend fun boot() {
        sess = Session.fromJson(store.get(Keys.SESSION))
        _state.update { it.copy(ready = true, email = sess?.email) }
        counts()
    }

    fun signedIn() = sess != null

    private suspend fun keep(s: Session) {
        sess = s
        store.put(Keys.SESSION, s.toJson())
        _state.update { it.copy(email = s.email) }
    }

    private suspend fun wipeData() {
        rows.wipe()
        store.removeKeys { it.startsWith("sbpull:") || it == Keys.OWNER }
    }

    suspend fun signIn(email: String, password: String, create: Boolean): Boolean {
        if (email.isBlank() || password.isEmpty()) { say("Enter your email and password"); return false }
        if (create && password.length < 6) { say("Use a password of at least 6 characters"); return false }
        say(if (create) "Creating account…" else "Signing in…")
        return try {
            val body = JSONObject().put("email", email.trim()).put("password", password).put("returnSecureToken", true).toString()
            val r = JSONObject(Http.call("POST", Protocol.authUrl(if (create) "signUp" else "signInWithPassword"), json = body) ?: "{}")
            val uid = r.optString("localId")
            if (r.optString("idToken").isEmpty() || uid.isEmpty()) { say("Couldn't sign in. Try again."); return false }
            val owner = store.get(Keys.OWNER)
            if (owner != uid) wipeData()
            keep(Session(uid, r.optString("email", email.trim()), r.getString("idToken"), r.getString("refreshToken"), now() / 1000 + (r.optString("expiresIn").toLongOrNull() ?: 3600)))
            store.put(Keys.OWNER, uid)
            say("")
            counts()
            sync()
            true
        } catch (e: Exception) {
            say(friendly(e))
            false
        }
    }

    suspend fun resetPassword(email: String) {
        if (email.isBlank()) { say("Type your email first"); return }
        say("Sending reset link…")
        try {
            Http.call("POST", Protocol.authUrl("sendOobCode"), json = JSONObject().put("requestType", "PASSWORD_RESET").put("email", email.trim()).toString())
            say("Reset link sent. Open it, choose a new password, then sign in.")
        } catch (e: Exception) {
            val m = (e as? ApiError)?.raw.orEmpty()
            say(
                when {
                    Regex("EMAIL_NOT_FOUND").containsMatchIn(m) -> "No account uses that email."
                    Regex("INVALID_EMAIL").containsMatchIn(m) -> "That email doesn't look right."
                    else -> friendly(e)
                },
            )
        }
    }

    private suspend fun fresh(force: Boolean = false) {
        val s = sess ?: throw IllegalStateException("Not signed in")
        if (!force && s.expiresAt - 60 > now() / 1000) return
        try {
            val form = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(s.refreshToken, "UTF-8")
            val r = JSONObject(Http.call("POST", Protocol.tokenUrl(), form = form) ?: "{}")
            keep(Session(s.uid, s.email, r.getString("id_token"), r.optString("refresh_token", s.refreshToken), now() / 1000 + (r.optString("expires_in").toLongOrNull() ?: 3600)))
        } catch (e: ApiError) {
            if (Protocol.isRefreshDead(e.status, e.raw)) {
                sess = null
                store.delete(Keys.SESSION)
                _state.update { it.copy(email = null) }
            }
            throw e
        }
    }

    private suspend fun data(method: String, url: String, body: String? = null): String? {
        fresh()
        return try {
            Http.call(method, url, json = body, bearer = sess?.idToken)
        } catch (e: ApiError) {
            if (e.status == 401 && sess != null) {
                fresh(true)
                Http.call(method, url, json = body, bearer = sess?.idToken)
            } else throw e
        }
    }

    private suspend fun fetchAll(uid: String, since: Long): List<CloudRow> {
        val all = ArrayList<CloudRow>()
        var afterU: Long? = null
        var afterN: String? = null
        while (true) {
            val page = Protocol.parseRows(data("POST", Protocol.userBase(uid) + ":runQuery", Protocol.queryBody(since, afterU, afterN)))
            all.addAll(page)
            if (page.size < Protocol.PAGE) return all
            afterU = page.last().updatedAt
            afterN = page.last().name
        }
    }

    private suspend fun pull(uid: String) {
        val key = Keys.cursor(uid)
        val since = store.get(key)?.toLongOrNull() ?: 0L
        var top = since
        for (c in fetchAll(uid, since)) {
            if (c.updatedAt > top) top = c.updatedAt
            val local = rows.get(c.id)
            val kind = Merge.kind(c.id)
            if (kind != null && !c.deleted && c.data != null) {
                val m = Merge.mergeRow(kind, local?.data, c.data)
                if (m != null) {
                    if (m.need) rows.put(Row(c.id, m.json, false, now(), "put", now()))
                    else rows.put(Row(c.id, m.json, false, maxOf(c.updatedAt, local?.updatedAt ?: 0), "", 0))
                    continue
                }
            }
            when (Protocol.take(local?.updatedAt, c)) {
                Take.PUT -> rows.put(Row(c.id, c.data, false, c.updatedAt, "", 0))
                Take.DELETE -> rows.delete(c.id)
                Take.SKIP -> {}
            }
        }
        store.put(key, (if (top == 0L) 1L else top).toString())
    }

    private suspend fun push(uid: String) {
        val dirty = rows.dirty()
        if (dirty.isEmpty()) return
        val writes = dirty.map { r ->
            if (r.dirtyOp == "del" || r.deleted) Protocol.writeJson(uid, r.id, null, true, r.dirtyT)
            else Protocol.writeJson(uid, r.id, r.data, false, r.updatedAt)
        }
        for (c in Protocol.chunks(writes)) data("POST", Protocol.base() + ":commit", Protocol.commitBody(c))
        dirty.forEach { rows.clearDirty(it.id, it.dirtyT) }
    }

    suspend fun sync() {
        val uid = sess?.uid ?: return
        if (!lock.tryLock()) return
        try {
            _state.update { it.copy(busy = true, message = "Syncing…") }
            pull(uid)
            push(uid)
            _state.update { it.copy(lastSync = now(), message = "") }
        } catch (e: Exception) {
            say(if (sess != null) "Couldn't sync: " + friendly(e) else "Signed out. Please sign in again.")
        } finally {
            _state.update { it.copy(busy = false) }
            counts()
            lock.unlock()
        }
    }

    /** Fetches everything again from the cloud (the stored position is reset). */
    suspend fun restore() {
        val uid = sess?.uid ?: return
        store.put(Keys.cursor(uid), "0")
        sync()
    }

    /** Writes a harmless test row and reads it back: proves sign-in, rules, upload and download all work. */
    suspend fun probe(): String {
        val s = sess ?: return "Sign in first"
        val t0 = now()
        return try {
            val payload = "{\"t\":$t0}"
            val body = Protocol.commitBody(listOf(Protocol.writeJson(s.uid, "zz_android_probe", payload, false, t0)))
            data("POST", Protocol.base() + ":commit", body)
            val back = Protocol.parseRow(JSONObject(data("GET", Protocol.docUrl(s.uid, "zz_android_probe")) ?: "{}"))
            val ms = now() - t0
            if (back.data == payload && back.updatedAt == t0) "Cloud check passed: wrote and read back ($ms ms)" else "Cloud check FAILED: read back a different value"
        } catch (e: Exception) {
            "Cloud check FAILED: " + friendly(e)
        }
    }

    suspend fun pendingCount(): Int = rows.dirty().size

    /** Signs out and clears this phone's copy. Returns false (and does nothing) if changes are unsent and [force] is not set. */
    suspend fun signOut(force: Boolean): Boolean {
        if (!force) {
            try { if (sess != null) sync() } catch (e: Exception) {}
            if (rows.dirty().isNotEmpty()) return false
        }
        sess = null
        store.delete(Keys.SESSION)
        wipeData()
        _state.update { it.copy(email = null, message = "", lastSync = 0) }
        counts()
        return true
    }
}
