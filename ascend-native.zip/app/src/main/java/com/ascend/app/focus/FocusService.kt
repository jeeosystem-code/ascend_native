package com.ascend.app.focus

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.ascend.app.AscendApp
import com.ascend.app.MainActivity
import com.ascend.app.R
import com.ascend.app.domain.Pomo
import com.ascend.app.domain.PomoRun
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps the app alive while a focus session runs and shows the countdown in the notification shade. */
class FocusService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var shown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val focus = (application as AscendApp).focus
        focus.boot()
        show(focus.run.value)
        if (job == null) {
            job = scope.launch {
                focus.run.collect { r ->
                    if (r.idle) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    } else show(r)
                }
            }
        }
        return START_STICKY
    }

    private fun show(r: PomoRun) {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val phase = when (r.ph) { "focus" -> "Focus"; "short" -> "Short break"; "long" -> "Long break"; else -> "Focus" }
        val b = NotificationCompat.Builder(this, FocusController.CH_RUN)
            .setSmallIcon(R.mipmap.ic_launcher).setContentTitle(phase + (if (r.lab.isNotEmpty()) " · " + r.lab else ""))
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open).setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (r.run) {
            val left = Pomo.left(r, System.currentTimeMillis())
            b.setUsesChronometer(true).setChronometerCountDown(true).setWhen(System.currentTimeMillis() + left).setShowWhen(true)
            b.setContentText("Time left")
        } else {
            b.setShowWhen(false)
            b.setContentText(if (r.wait) "Ready when you are" else "Paused · " + Pomo.fmt(Pomo.left(r, System.currentTimeMillis())) + " left")
        }
        val n = b.build()
        if (!shown) {
            shown = true
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        } else {
            getSystemService(android.app.NotificationManager::class.java).notify(1, n)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
