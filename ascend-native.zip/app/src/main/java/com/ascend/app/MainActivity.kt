package com.ascend.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.ascend.app.ui.AscendRoot
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as AscendApp
        lifecycleScope.launch {
            app.account.boot()
            // Sync when the app comes to the front, then once a minute while it stays open.
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    app.account.sync()
                    delay(60_000)
                }
            }
        }
        setContent { AscendRoot(app.store, app.account, app.domain) }
    }
}
