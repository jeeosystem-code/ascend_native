package com.ascend.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

/**
 * A local copy of one cloud row. [dirtyOp] is "" when in sync, "put" or "del" when this phone changed it and the change
 * still has to be sent; [dirtyT] is the time of that change (so a newer change is never cleared by an older send).
 */
@Entity(tableName = "rows")
data class Row(
    @PrimaryKey val id: String,
    val data: String?,
    val deleted: Boolean,
    val updatedAt: Long,
    val dirtyOp: String,
    val dirtyT: Long,
)

@Dao
interface RowDao {
    @Query("SELECT * FROM rows WHERE id = :id")
    suspend fun get(id: String): Row?

    @Query("SELECT * FROM rows")
    suspend fun all(): List<Row>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(row: Row)

    @Query("DELETE FROM rows WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT * FROM rows WHERE dirtyOp != ''")
    suspend fun dirty(): List<Row>

    @Query("UPDATE rows SET dirtyOp = '' WHERE id = :id AND dirtyT = :t")
    suspend fun clearDirty(id: String, t: Long)

    @Query("SELECT COUNT(*) FROM rows WHERE deleted = 0")
    suspend fun live(): Int

    @Query("SELECT COUNT(*) FROM rows WHERE deleted = 0 AND id NOT LIKE 'zz!_%' ESCAPE '!'")
    suspend fun sessions(): Int

    @Query("DELETE FROM rows")
    suspend fun wipe()
}
