package com.ascend.app.ui.screens

import android.Manifest
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.ComponentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.Dates
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Planner
import com.ascend.app.domain.Pomo
import com.ascend.app.domain.PomoSettings
import com.ascend.app.focus.FocusController
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun FocusScreen(focus: FocusController, domain: Domain, onBack: () -> Unit) {
    val t = Tk.c
    val r by focus.run.collectAsStateWithLifecycle()
    val s by focus.settings.collectAsStateWithLifecycle()
    val data by domain.data.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(r.idle, r.run) {
        while (!r.idle) { now = System.currentTimeMillis(); delay(250) }
    }
    // Keep the screen on while a block runs, if the setting is on.
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(r.run, s.wake) {
        if (r.run && s.wake) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    val today = Dates.today()
    val entries = data?.focus.orEmpty()
    val (tod, week) = Pomo.totals(entries, today, now)

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead("Focus", onBack)
        if (r.idle) SetupView(focus, domain, s, tod.b, tod.m, week.m)
        else if (r.cel > 0) DoneView(focus, domain, r, s, entries, tod.b, tod.m, today)
        else RunView(focus, domain, r, s, now, tod.b, tod.m, week.m)
        Spacer(Modifier.height(96.dp))
    }
}

@Composable
private fun TotalsRow(blocks: Int, today: Int, week: Int) {
    val t = Tk.c
    Glass(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat2(blocks.toString(), "Blocks today")
            Stat2(Pomo.hm(today), "Focus today")
            Stat2(Pomo.hm(week), "This week")
        }
    }
}

@Composable
private fun Stat2(big: String, small: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(big, color = Tk.c.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(small, color = Tk.c.muted, fontSize = 11.sp)
    }
}

@Composable
private fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    val t = Tk.c
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Round("–", onMinus)
        Text(value, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 6.dp).size(width = 56.dp, height = 24.dp))
        Round("+", onPlus)
    }
}

@Composable
private fun Round(sym: String, onClick: () -> Unit) {
    val t = Tk.c
    Box(Modifier.size(40.dp).clip(CircleShape).background(t.line.copy(alpha = 0.6f)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(sym, color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Toggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Tk.c.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange)
    }
}

@Composable
private fun PillChip(label: String, on: Boolean, onClick: () -> Unit) {
    val t = Tk.c
    Box(
        Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) t.accent.copy(alpha = 0.18f) else t.line.copy(alpha = 0.5f))
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 9.dp),
    ) { Text(label, color = if (on) t.accent else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
}

@Composable
private fun SetupView(focus: FocusController, domain: Domain, s: PomoSettings, blocks: Int, today: Int, week: Int) {
    val t = Tk.c
    val data by domain.data.collectAsStateWithLifecycle()
    var label by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { focus.start(label, link) }
    val ctx = LocalContext.current
    TotalsRow(blocks, today, week)
    Spacer(Modifier.height(12.dp))
    val todayKey = Dates.today()
    val open = data?.let { d -> Planner.day(d, todayKey).filter { !it.item.done }.take(4) }.orEmpty()
    Glass(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = label, onValueChange = { label = it.take(40); link = "" }, singleLine = true,
            label = { Text("What are you studying? (optional)") }, modifier = Modifier.fillMaxWidth(),
        )
        if (open.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                open.forEach { x -> PillChip(x.title.take(30), link == x.item.id) { label = x.title.take(40); link = x.item.id } }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(listOf(25, 5, 15, 4), listOf(50, 10, 20, 3), listOf(90, 15, 30, 2)).forEach { p ->
                PillChip("${p[0]} / ${p[1]}", s.f == p[0] && s.s == p[1] && s.l == p[2] && s.e == p[3]) {
                    focus.change { it.copy(f = p[0], s = p[1], l = p[2], e = p[3]) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Stepper("Focus (min)", s.f.toString(), { focus.change { it.bump("f", -1) } }, { focus.change { it.bump("f", 1) } })
        Stepper("Short break (min)", s.s.toString(), { focus.change { it.bump("s", -1) } }, { focus.change { it.bump("s", 1) } })
        Stepper("Long break (min)", s.l.toString(), { focus.change { it.bump("l", -1) } }, { focus.change { it.bump("l", 1) } })
        Stepper("Blocks before long break", s.e.toString(), { focus.change { it.bump("e", -1) } }, { focus.change { it.bump("e", 1) } })
        Spacer(Modifier.height(6.dp))
        Toggle("Start breaks automatically", s.auto) { v -> focus.change { it.copy(auto = v) } }
        Toggle("Sound", s.snd) { v -> focus.change { it.copy(snd = v) } }
        Toggle("Vibrate", s.vib) { v -> focus.change { it.copy(vib = v) } }
        Toggle("Keep screen on", s.wake) { v -> focus.change { it.copy(wake = v) } }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = {
        val need = Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (need) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else focus.start(label, link)
    }) { Text("Start ${s.f} min focus", color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
    Spacer(Modifier.height(8.dp))
    Text("The timer keeps running if you leave the app. Your study minutes are saved as they pass.", color = t.muted, fontSize = 12.sp)
}

@Composable
private fun Ring(frac: Float, color: Color, content: @Composable () -> Unit) {
    val t = Tk.c
    Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 14.dp.toPx()
            val inset = w / 2
            val sz = Size(size.width - w, size.height - w)
            drawArc(t.line, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
            drawArc(color, -90f, 360f * frac.coerceIn(0f, 1f), false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
private fun Dots(n: Int, e: Int, focusing: Boolean) {
    val t = Tk.c
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0 until e) {
            val c = if (i < n) t.good else if (i == n && focusing) t.accent else t.line
            Box(Modifier.size(10.dp).clip(CircleShape).background(c))
        }
    }
}

@Composable
private fun RunView(focus: FocusController, domain: Domain, r: com.ascend.app.domain.PomoRun, s: PomoSettings, now: Long, blocks: Int, today: Int, week: Int) {
    val t = Tk.c
    val data by domain.data.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var arm by remember { mutableStateOf(false) }
    LaunchedEffect(arm) { if (arm) { delay(2600); arm = false } }
    val left = Pomo.left(r, now)
    val brk = r.ph != "focus"
    val phase = when (r.ph) { "focus" -> "Focus"; "short" -> "Short break"; else -> "Long break" }
    val item = data?.items?.firstOrNull { it.id == r.hw && !it.x }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Ring(if (r.tot > 0) left.toFloat() / r.tot else 0f, if (brk) t.good else t.accent) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(phase, color = t.muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(Pomo.fmt(left), color = t.ink, fontSize = 56.sp, fontWeight = FontWeight.Bold)
                Text(if (r.wait) "Ready when you are" else if (!r.run) "Paused" else " ", color = t.muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Dots(r.n, s.e, r.ph == "focus")
        if (r.lab.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(r.lab, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
        if (item != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                if (item.done) "Done ✓" else "Mark task done", color = if (item.done) t.good else t.accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = !item.done) { scope.launch { domain.toggle(item.id) } }.padding(10.dp),
            )
        }
    }
    Spacer(Modifier.height(18.dp))
    val playLabel = if (r.wait) (if (r.ph == "focus") "Start focus" else if (r.ph == "short") "Start break" else "Start long break") else if (r.run) "Pause" else "Resume"
    Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { focus.toggle() }) {
        Text(playLabel, color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Glass(Modifier.weight(1f), onClick = { focus.skip() }) { Text("Skip", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        Glass(Modifier.weight(1f), onClick = { if (arm) { arm = false; focus.stop() } else arm = true }) {
            Text(if (arm) "Tap again to end" else "End session", color = t.bad, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
    Spacer(Modifier.height(14.dp))
    TotalsRow(blocks, today, week)
}

@Composable
private fun DoneView(
    focus: FocusController, domain: Domain, r: com.ascend.app.domain.PomoRun, s: PomoSettings,
    entries: List<com.ascend.app.domain.FocusEntry>, blocks: Int, today: Int, todayKey: String,
) {
    val t = Tk.c
    val data by domain.data.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val all = r.cel == 2
    val long = r.ph == "long"
    val quote = Pomo.QUOTES[r.cq.coerceIn(0, Pomo.QUOTES.size - 1)]
    val item = data?.items?.firstOrNull { it.id == r.hw && !it.x }
    Glass(Modifier.fillMaxWidth(), tint = t.good) {
        Text(if (all) "All ${s.e} blocks done" else "Block ${r.n} of ${s.e}", color = t.muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(if (all) "Session complete." else "Well done.", color = t.ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("“$quote”", color = t.muted, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Dots(r.n, s.e, false)
        if (all) {
            Pomo.pills(entries, r, todayKey).forEach {
                Text(it, color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Glass(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            if (!all) Stat2("${if (r.cm > 0) r.cm else s.f} min", "This block")
            Stat2(Pomo.hm(r.sm), "This session")
            Stat2(blocks.toString(), "Blocks today")
            Stat2(Pomo.hm(today), "Focus today")
        }
    }
    if (r.lab.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text("Studied: ${r.lab}", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
    if (item != null) {
        Spacer(Modifier.height(10.dp))
        Glass(Modifier.fillMaxWidth(), tint = if (item.done) t.good else null, onClick = { if (!item.done) scope.launch { domain.toggle(item.id) } }) {
            Text(if (item.done) "Task done ✓" else "Mark task done", color = if (item.done) t.good else t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
    Spacer(Modifier.height(14.dp))
    if (all) {
        Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { focus.afterBlock("end") }) {
            Text("Finish session", color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Glass(Modifier.weight(1f), onClick = { focus.afterBlock("break") }) { Text("Take a ${s.l} min break", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
            Glass(Modifier.weight(1f), onClick = { focus.afterBlock("again") }) { Text("Another round", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        }
    } else {
        Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = { focus.afterBlock("break") }) {
            Text("Start ${if (long) s.l else s.s} min ${if (long) "long " else ""}break", color = t.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Glass(Modifier.weight(1f), onClick = { focus.afterBlock("again") }) { Text("Another block", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
            Glass(Modifier.weight(1f), onClick = { focus.afterBlock("end") }) { Text("Finish", color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        }
    }
}
