package com.ascend.app

import android.app.Application
import androidx.room.Room
import com.ascend.app.data.AppDb
import com.ascend.app.data.Store

class AscendApp : Application() {
    lateinit var store: Store
        private set

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, AppDb::class.java, "ascend.db").build()
        store = Store(db.docs())
    }
}
