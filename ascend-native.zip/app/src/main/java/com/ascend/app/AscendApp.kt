package com.ascend.app

import android.app.Application
import androidx.room.Room
import com.ascend.app.data.AppDb
import com.ascend.app.data.Store
import com.ascend.app.domain.Domain
import com.ascend.app.sync.Account

class AscendApp : Application() {
    lateinit var store: Store
        private set
    lateinit var account: Account
        private set
    lateinit var domain: Domain
        private set

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, AppDb::class.java, "ascend.db")
            .fallbackToDestructiveMigrationFrom(1)   // version 1 held only the theme choice
            .build()
        store = Store(db.docs())
        account = Account(store, db.rows())
        domain = Domain(db.rows()) { account.syncSoon() }
    }
}
