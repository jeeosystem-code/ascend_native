package com.ascend.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.data.Keys
import com.ascend.app.data.Store
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(store: Store, mode: String, onBack: () -> Unit) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    var check by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead("Settings", onBack)
        Glass {
            Text("Appearance", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "Auto", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
                    val on = mode == k
                    Glass(
                        modifier = Modifier.weight(1f), tint = if (on) t.accent else null,
                        onClick = { scope.launch { store.put(Keys.THEME, k) } },
                    ) {
                        Text(label, color = if (on) t.accent else t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Glass(onClick = {
            scope.launch {
                val payload = "ok-" + System.nanoTime()
                val t0 = System.nanoTime()
                try {
                    store.put(Keys.SELF_TEST, payload)
                    val back = store.get(Keys.SELF_TEST)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    check = if (back == payload) "Local storage works (${ms} ms)" else "Local storage FAILED: read back a different value"
                } catch (e: Exception) {
                    check = "Local storage FAILED: " + (e.message ?: e.javaClass.simpleName)
                }
            }
        }) {
            Text("Check local storage", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (check.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(check, color = if (check.contains("FAILED")) t.bad else t.good, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Ascend native · stage 1 build", color = t.muted, fontSize = 12.sp)
    }
}
