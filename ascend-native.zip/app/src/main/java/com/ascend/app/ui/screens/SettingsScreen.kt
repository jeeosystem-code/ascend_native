package com.ascend.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ascend.app.domain.Dates
import com.ascend.app.domain.Domain
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascend.app.data.Keys
import com.ascend.app.data.Store
import com.ascend.app.ui.Glass
import com.ascend.app.ui.theme.Tk
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(store: Store, domain: Domain, mode: String, onBack: () -> Unit) {
    val t = Tk.c
    val scope = rememberCoroutineScope()
    var check by remember { mutableStateOf("") }
    val data by domain.data.collectAsStateWithLifecycle()
    val prof = data?.profile
    var examName by remember(prof?.examName) { mutableStateOf(prof?.examName ?: "Exam") }
    var examDay by remember(prof?.exam) { mutableStateOf(prof?.exam ?: "") }
    var cap by remember(prof?.capHours) { mutableStateOf((prof?.capHours ?: 6).toString()) }
    var mpq by remember(prof?.minPerQ) { mutableStateOf((prof?.minPerQ ?: 3).toString()) }
    var pickExam by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHead("Settings", onBack)
        Glass {
            Text("Appearance", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "Auto", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
                    val on = mode == k
                    Glass(
                        modifier = Modifier.weight(1f), tint = if (on) t.accent else null,
                        onClick = { scope.launch { store.put(Keys.THEME, k) } },
                    ) {
                        Text(label, color = if (on) t.accent else t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Glass {
            Text("Target exam", color = t.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = examName, onValueChange = { examName = it.take(24) }, singleLine = true, label = { Text("Exam name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Glass(Modifier.fillMaxWidth(), onClick = { pickExam = true }) {
                Text(if (Dates.valid(examDay)) Dates.dowShort(examDay) + " " + Dates.parse(examDay).dayOfMonth + " " + Dates.monthName(examDay) + " " + Dates.parse(examDay).year else "Pick exam date", color = t.ink, fontSize = 15.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = cap, onValueChange = { cap = it.filter { c -> c.isDigit() }.take(2) }, singleLine = true, label = { Text("Hours a day") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = mpq, onValueChange = { mpq = it.filter { c -> c.isDigit() }.take(3) }, singleLine = true, label = { Text("Min per question") }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Glass(Modifier.fillMaxWidth(), tint = t.accent, onClick = {
                val c = (cap.toIntOrNull() ?: 6).coerceIn(1, 14)
                val m = (mpq.toIntOrNull() ?: 3).coerceIn(1, 30)
                scope.launch { domain.saveExam(if (Dates.valid(examDay)) examDay else "", examName.ifBlank { "Exam" }, c, m); saved = "Saved" }
            }) { Text(if (saved.isEmpty()) "Save target" else saved, color = t.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(12.dp))
        Glass(onClick = {
            scope.launch {
                val payload = "ok-" + System.nanoTime()
                val t0 = System.nanoTime()
                try {
                    store.put(Keys.SELF_TEST, payload)
                    val back = store.get(Keys.SELF_TEST)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    check = if (back == payload) "Local storage works (${ms} ms)" else "Local storage FAILED: read back a different value"
                } catch (e: Exception) {
                    check = "Local storage FAILED: " + (e.message ?: e.javaClass.simpleName)
                }
            }
        }) {
            Text("Check local storage", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (check.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(check, color = if (check.contains("FAILED")) t.bad else t.good, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Ascend native · stage 3 build", color = t.muted, fontSize = 12.sp)
    }
    if (pickExam) {
        val st = rememberDatePickerState(initialSelectedDateMillis = LocalDate.parse(if (Dates.valid(examDay)) examDay else Dates.today()).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { pickExam = false },
            confirmButton = { TextButton(onClick = { st.selectedDateMillis?.let { examDay = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString() }; saved = ""; pickExam = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { pickExam = false }) { Text("Cancel") } },
        ) { DatePicker(state = st) }
    }
}
