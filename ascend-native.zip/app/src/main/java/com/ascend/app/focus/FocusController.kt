package com.ascend.app.focus

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ascend.app.MainActivity
import com.ascend.app.R
import com.ascend.app.data.Store
import com.ascend.app.domain.Domain
import com.ascend.app.domain.Pomo
import com.ascend.app.domain.PomoRun
import com.ascend.app.domain.PomoSettings
import com.ascend.app.domain.PomoStep
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.ZoneId

/**
 * Owns the focus timer. The state is saved after every change with absolute end times, so closing the app or
 * rebooting never loses the running block; the minutes studied go into the shared revision log as they pass.
 */
class FocusController(private val app: Application, private val store: Store, private val domain: Domain) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val lock = Mutex()
    private val _run = MutableStateFlow(PomoRun())
    private val _set = MutableStateFlow(PomoSettings())
    val run: StateFlow<PomoRun> = _run
    val settings: StateFlow<PomoSettings> = _set
    private var ticker: Job? = null
    private var booted = false

    companion object {
        const val KEY_RUN = "pomo_run"
        const val KEY_SET = "pomo"
        const val CH_RUN = "focus_run"
        const val CH_DONE = "focus_done"
        const val NOTE_DONE = 4242
    }

    private fun zone(): ZoneId = ZoneId.systemDefault()

    fun boot() {
        if (booted) return
        booted = true
        makeChannels()
        scope.launch {
            lock.withLock {
                _set.value = PomoSettings.parse(store.get(KEY_SET))
                _run.value = PomoRun.parse(store.get(KEY_RUN))
            }
            if (!_run.value.idle) { startService(); startTicker() }
        }
    }

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Focus timer", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shows the running focus block"
            setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Focus block finished", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Tells you when a focus block or break is over"
            setSound(null, null)
            enableVibration(false)
        })
    }

    private fun startService() {
        try { ContextCompat.startForegroundService(app, Intent(app, FocusService::class.java)) } catch (e: Exception) { }
    }

    private fun startTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (!_run.value.idle) {
                tick()
                delay(250)
            }
        }
    }

    private suspend fun oldEntry(r: PomoRun) = if (r.id.isNotEmpty() && r.am < 0) domain.focusEntry("pm:" + r.id) else null

    private suspend fun tick() {
        lock.withLock {
            val r = _run.value
            if (r.idle) return
            val now = System.currentTimeMillis()
            if (Pomo.due(r, now)) apply(Pomo.end(r, _set.value, oldEntry(r), true, now, zone(), (Math.random() * Pomo.QUOTES.size).toInt()))
            else if (r.run) apply(Pomo.live(r, _set.value, oldEntry(r), now, zone(), false))
        }
    }

    /** Saves a step's result: new state, session entry, and the end-of-block alert. Call with the lock held. */
    private suspend fun apply(st: PomoStep) {
        _run.value = st.run
        if (st.run.idle) store.delete(KEY_RUN) else store.put(KEY_RUN, st.run.toJson())
        st.entry?.let { domain.saveFocus(it) }
        st.alert?.let { alert(it) }
    }

    fun start(label: String, hw: String) {
        scope.launch {
            lock.withLock {
                if (!_run.value.idle) return@withLock
                val now = System.currentTimeMillis()
                apply(PomoStep(Pomo.start(label, hw, java.lang.Long.toString(now, 36), _set.value, now)))
            }
            startService()
            startTicker()
        }
    }

    fun toggle() = scope.launch {
        lock.withLock { apply(PomoStep(Pomo.toggle(_run.value, _set.value, System.currentTimeMillis()))) }
        startTicker()
    }

    fun skip() = scope.launch {
        lock.withLock {
            val r = _run.value.copy(cel = 0)
            if (r.idle) return@withLock
            val now = System.currentTimeMillis()
            val st = Pomo.end(r, _set.value, oldEntry(r), false, now, zone(), 0)
            val next = if (_set.value.auto && !st.run.run) Pomo.begin(st.run, st.run.ph, _set.value, now) else st.run
            apply(st.copy(run = next))
        }
    }

    fun stop() = scope.launch {
        lock.withLock {
            val r = _run.value
            if (r.idle) return@withLock
            apply(Pomo.stop(r, _set.value, oldEntry(r), System.currentTimeMillis(), zone()))
            cancelDone()
        }
    }

    /** Buttons on the block-complete page. */
    fun afterBlock(what: String) = scope.launch {
        lock.withLock {
            val r = _run.value
            val now = System.currentTimeMillis()
            when (what) {
                "break" -> apply(PomoStep(Pomo.begin(r.copy(cel = 0), r.ph, _set.value, now)))
                "again" -> apply(PomoStep(Pomo.begin(r.copy(cel = 0, n = if (r.ph == "long") 0 else r.n), "focus", _set.value, now)))
                else -> apply(Pomo.stop(r.copy(ph = "break"), _set.value, null, now, zone()))
            }
            cancelDone()
        }
        startTicker()
    }

    fun change(f: (PomoSettings) -> PomoSettings) {
        scope.launch {
            lock.withLock {
                _set.value = f(_set.value)
                store.put(KEY_SET, _set.value.toJson())
            }
        }
    }

    // ---- alerts ----

    @SuppressLint("MissingPermission")
    private fun alert(msg: String) {
        val s = _set.value
        if (s.snd) try { RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play() } catch (e: Exception) { }
        if (s.vib) buzz()
        val ok = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        val open = PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(app, CH_DONE)
            .setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Ascend").setContentText(msg)
            .setAutoCancel(true).setContentIntent(open).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(app).notify(NOTE_DONE, n) } catch (e: Exception) { }
    }

    private fun cancelDone() { try { NotificationManagerCompat.from(app).cancel(NOTE_DONE) } catch (e: Exception) { } }

    private fun buzz() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) (app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else @Suppress("DEPRECATION") (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 220, 110, 220, 110, 380), -1))
        } catch (e: Exception) { }
    }
}
