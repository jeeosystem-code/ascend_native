package com.ascend.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** Result of merging a local copy of a document row with the cloud copy. */
data class Merged(val json: String, val changed: Boolean, val need: Boolean)

/**
 * The web app's merge rules for homework and syllabus documents: items are matched by id and the one with the
 * larger "u" (last-changed time) wins. Pure code, tested against the same rules the web app uses.
 */
object Merge {
    fun kind(id: String): String? = when {
        id == "zz_hw" || id.startsWith("zz_hw_") -> "hw"
        id == "zz_syllabus" -> "sy"
        else -> null
    }

    private fun u(o: JSONObject) = o.optLong("u", 0)
    fun isX(o: JSONObject): Boolean = o.optBoolean("x", false) || o.optInt("x", 0) != 0

    /** Same as hwList in the web app: keep a's order, add new items from b, replace an item when b's copy is newer. */
    fun list(a: JSONArray?, b: JSONArray?): JSONArray {
        val out = ArrayList<JSONObject>()
        val pos = HashMap<String, Int>()
        for (i in 0 until (a?.length() ?: 0)) {
            val r = a!!.optJSONObject(i) ?: continue
            pos[r.optString("id")] = out.size
            out.add(r)
        }
        for (i in 0 until (b?.length() ?: 0)) {
            val r = b!!.optJSONObject(i) ?: continue
            val id = r.optString("id")
            val p = pos[id]
            if (p == null) {
                pos[id] = out.size
                out.add(r)
            } else if (u(r) > u(out[p])) {
                out[p] = r
            }
        }
        val arr = JSONArray()
        out.forEach { arr.put(it) }
        return arr
    }

    /** id:u:x for every entry, sorted: two documents with the same signature hold the same content. */
    fun sig(a: JSONArray?): String {
        val l = ArrayList<String>()
        for (i in 0 until (a?.length() ?: 0)) {
            val r = a!!.optJSONObject(i) ?: continue
            l.add(r.optString("id") + ":" + r.optLong("u", 0) + ":" + (if (isX(r)) 1 else 0))
        }
        l.sort()
        return l.joinToString(",")
    }

    private fun keys(kind: String) = if (kind == "hw") listOf("subjects", "items") else listOf("nodes", "keys")

    private fun docSig(kind: String, d: JSONObject) = keys(kind).joinToString("|") { sig(d.optJSONArray(it)) }

    fun valid(kind: String, d: JSONObject?): Boolean {
        if (d == null) return false
        return keys(kind).take(if (kind == "hw") 2 else 1).all { d.optJSONArray(it) != null }
    }

    fun merge(kind: String, a: JSONObject?, b: JSONObject?): JSONObject {
        val out = JSONObject()
        for (k in keys(kind)) out.put(k, list(a?.optJSONArray(k), b?.optJSONArray(k)))
        out.put("savedAt", maxOf(a?.optLong("savedAt", 0) ?: 0, b?.optLong("savedAt", 0) ?: 0))
        return out
    }

    /** Merges the cloud copy into the local one. [need] is true when the result holds something the cloud copy lacks. */
    fun mergeRow(kind: String, local: String?, cloud: String): Merged? {
        val c = try { JSONObject(cloud) } catch (e: Exception) { return null }
        if (!valid(kind, c)) return null
        val l = try { if (local == null) null else JSONObject(local) } catch (e: Exception) { null }
        if (l == null || !valid(kind, l)) return Merged(cloud, true, false)
        val m = merge(kind, l, c)
        return Merged(m.toString(), docSig(kind, m) != docSig(kind, l), docSig(kind, m) != docSig(kind, c))
    }
}
