package com.ascend.app.domain

/** Question ranges such as "1-30" or "1-20, 25-30" (same rules as the web app). */
data class RangeInfo(val ok: Boolean, val n: Int = 0, val norm: String = "", val msg: String = "")

object Ranges {
    private val span = Regex("^(\\d{1,4})\\s*(?:[-–—~]|to)\\s*(\\d{1,4})$", RegexOption.IGNORE_CASE)
    private val one = Regex("^(\\d{1,4})$")

    fun parse(input: String?): RangeInfo {
        val str = (input ?: "").trim()
        if (str.isEmpty()) return RangeInfo(true)
        val rs = ArrayList<IntArray>()
        for (raw in str.split(Regex("[,;]+"))) {
            val p = raw.trim()
            if (p.isEmpty()) continue
            val m1 = span.find(p)
            val a: Int
            val b: Int
            if (m1 != null) {
                a = m1.groupValues[1].toInt(); b = m1.groupValues[2].toInt()
            } else {
                val m2 = one.find(p) ?: return RangeInfo(false, msg = "“$p” isn't a range. Try 1-30 or 1-20, 25-30.")
                a = m2.groupValues[1].toInt(); b = a
            }
            if (a < 1) return RangeInfo(false, msg = "Questions start at 1.")
            if (a > b) return RangeInfo(false, msg = "“$p” starts after it ends.")
            rs.add(intArrayOf(a, b))
        }
        if (rs.isEmpty()) return RangeInfo(true)
        rs.sortBy { it[0] }
        val mg = ArrayList<IntArray>()
        mg.add(rs[0])
        for (i in 1 until rs.size) {
            val l = mg.last()
            if (rs[i][0] <= l[1] + 1) l[1] = maxOf(l[1], rs[i][1]) else mg.add(rs[i])
        }
        val n = mg.sumOf { it[1] - it[0] + 1 }
        return RangeInfo(true, n, mg.joinToString(", ") { if (it[0] == it[1]) "${it[0]}" else "${it[0]}–${it[1]}" })
    }
}
