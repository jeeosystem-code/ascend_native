package com.ascend.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Day keys are "yyyy-MM-dd" in the phone's local time, exactly like the web app. */
object Dates {
    fun today(): String = LocalDate.now().toString()
    fun parse(k: String): LocalDate = LocalDate.parse(k)
    fun add(k: String, n: Int): String = parse(k).plusDays(n.toLong()).toString()
    /** Monday of the week that holds [k]. */
    fun weekStart(k: String): String = parse(k).with(DayOfWeek.MONDAY).toString()
    fun between(a: String, b: String): Int = ChronoUnit.DAYS.between(parse(a), parse(b)).toInt()
    fun valid(k: String?): Boolean = k != null && Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(k) && try { parse(k); true } catch (e: Exception) { false }
    /** Month document key of a day: "2026-10" or "undated". */
    fun shard(d: String?): String = if (d != null && Regex("^\\d{4}-\\d{2}.*").matches(d)) d.substring(0, 7) else "undated"

    private val MON = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    private val DOW = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    fun monthName(k: String) = MON[parse(k).monthValue - 1]
    fun dowName(k: String) = DOW[parse(k).dayOfWeek.value % 7]
    fun dowShort(k: String) = dowName(k).substring(0, 3)

    /** 95 -> "1h 35m", 40 -> "40m", 0 -> "". */
    fun hm(minutes: Int): String {
        if (minutes <= 0) return ""
        val h = minutes / 60
        val r = minutes % 60
        return if (h > 0) "${h}h" + (if (r > 0) " ${r}m" else "") else "${r}m"
    }

    /** "14:05" -> "2:05 PM". */
    fun clock(t: String?): String {
        if (t.isNullOrEmpty()) return ""
        val p = t.split(":")
        var h = p[0].toIntOrNull() ?: return ""
        val ap = if (h >= 12) "PM" else "AM"
        h %= 12
        if (h == 0) h = 12
        return "$h:${p.getOrNull(1)?.ifEmpty { "00" } ?: "00"} $ap"
    }
}
