# Ascend (native Android) – stage 3

Upload `ascend-native.zip` to the GitHub repository as it is (replace the old zip), then **Actions → Build Ascend (native) → Run workflow**, download **Ascend-native-APK**, install over the old app.

## What is new
- **Plan** tab: your day (Today / date, week strip, load bar, tasks). Tick to finish, tap a task to edit or delete, **+** to add (subject, date, time, how long, priority, note). Overdue tasks are listed under today with "Move all overdue to today".
- **Home**: greeting with your name, days to your target exam, a Today card with your next tasks, Add task.
- Tasks are saved as the same cloud rows the web app uses (one per month), so a task added on the phone appears in the web app and the other way round.

## Check on the phone (sign in first: More → Account & backup)
1. Home shows your name and the exam countdown (if set in the web planner).
2. Plan → today's tasks match the web app's Today. Tap a date in the week strip; use ‹ › for other weeks.
3. Add a task on the phone, wait a few seconds, then open the web app: it appears there. Add one in the web app, open More → Account → Sync now: it appears on the phone.
4. Tick, untick, edit time/duration, delete: each shows on both sides after sync.
5. Overdue list and "Move all overdue to today" work.

Not in this stage yet: week/month/plans views, the plan wizard and plan overview, subject/chapter pickers for questions ranges, swipe to finish (next stage 3B).
