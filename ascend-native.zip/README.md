# Ascend (native Android) – stage 2

Upload `ascend-native.zip` to the GitHub repository as it is (replace the old zip), then **Actions → Build Ascend (native) → Run workflow**, download **Ascend-native-APK**, install. Uninstalling is not needed; installing over the old one keeps the theme choice only (stage 1 stored nothing else).

## Stage 2 check on the phone (More → Account & backup)
1. Sign in with your existing Ascend account (same email and password as the web app). Wrong password shows "Wrong email or password."
2. After sign-in it shows "Synced just now" and **N items on this phone · S saved sessions**. S should match the number of saved sessions in the web app's history.
3. **Cloud check** shows green "Cloud check passed" (it writes one harmless test row and reads it back).
4. **Sync now** and **Restore everything from cloud** finish without a red message.
5. Turn on aeroplane mode, tap Sync now: "Can't reach Firebase. Check your internet." Turn it off and sync again: works.
6. **Sign out** clears the phone's copy; signing in again brings everything back.
7. Close and reopen the app: still signed in.

Not in this stage: the screens that show your plans, tests, homework and sessions (they come in the next stages; their data is already downloaded and kept safe). File backup/restore arrives with those screens, because the file format holds that data.
