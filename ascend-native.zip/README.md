# Ascend (native Android) – stage 1

1. On github.com create a new **private** repository (for example `ascend-native`).
2. Unzip `ascend-native.zip` on your phone/computer. Upload the files **inside** the folder (`app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`) to the repository's top level. (If `.github` is hidden, turn on "show hidden files"; if you cannot upload folders, upload the zip itself – the build unzips it.)
3. Open **Actions → Build Ascend (native) → Run workflow**. Takes about 5–8 minutes the first time.
4. Open the finished run, download **Ascend-native-APK**, unzip, install `app-debug.apk`.

If the run turns red, send me a screenshot of the first red step.

## Stage 1 check on the phone
- App opens on Home, greeting changes with the time of day.
- Bottom dock: Home, Plan, Practice, Track, More. More opens a sheet (Syllabus, Reports, Account & backup, Settings).
- Settings → Auto / Light / Dark changes the theme at once and is remembered after closing the app.
- Settings → **Check local storage** shows green "Local storage works".
- Back on Home: first press shows "Press back again to exit", second press leaves. Back in a sub-page returns; Back with the More sheet open closes the sheet.
