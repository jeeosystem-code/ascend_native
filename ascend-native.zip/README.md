# Ascend (native Android) – stage 5

Upload `ascend-native.zip` to the GitHub repository as it is (replace the old zip), then **Actions → Build Ascend (native) → Run workflow**, download **Ascend-native-APK**, install over the old app.

## What is new
- **Plan** tab: your day (Today / date, week strip, load bar, tasks). Tick to finish, tap a task to edit or delete, **+** to add (subject, date, time, how long, priority, note). Overdue tasks are listed under today with "Move all overdue to today".
- **Home**: greeting with your name, days to your target exam, a Today card with your next tasks, Add task.
- Tasks are saved as the same cloud rows the web app uses (one per month), so a task added on the phone appears in the web app and the other way round.

## Check on the phone (sign in first: More → Account & backup)
1. Home shows your name and the exam countdown (if set in the web planner).
2. Plan → today's tasks match the web app's Today. Tap a date in the week strip; use ‹ › for other weeks.
3. Add a task on the phone, wait a few seconds, then open the web app: it appears there. Add one in the web app, open More → Account → Sync now: it appears on the phone.
4. Tick, untick, edit time/duration, delete: each shows on both sides after sync.
5. Overdue list and "Move all overdue to today" work.

Stage 3B adds Week, Month and Plans views, plan overview (progress, pace, chapters, finish-by date, delete) and the exam target in Settings. Still to come: the plan wizard, subject/chapter pickers for question ranges, swipe to finish.


## Stage 4: focus timer
Home → Focus (or More → Focus timer). Presets 25/5, 50/10, 90/15, steppers, auto-start breaks, sound, vibration, keep screen on. The timer keeps running when you leave the app (notification with a countdown), survives closing the app, and saves your minutes into the same revision log the web app uses, so Today/Week totals match across both. Android asks once for permission to show notifications.

## Stage 5: practice sessions
Practice tab. Homework sessions (question range, +/- marks) and tests (several subjects, sections, partial marks, time limit). Per-question timer with pause, Attempted / Not attempted, question palette, jump to any question, two-tap Finish, "Save and go back" keeps a draft you can resume (also from another device). Result: score, accuracy, time boxes, subject-wise, change wrong/partial marks, mark doubts, time-per-question bars, share report text. Sessions are saved in the same format as the web app and sync both ways. Tasks with question ranges can be practised from the plan (Plan -> open task -> Practice this task, or "From your plan" chips); finishing marks the questions done and completes the task when all are covered.
Not yet: test folders and saved attempts, chapter tags and mistake notebook (stage 6), revision sessions (stage 7).

## Stage 6A: test folders and marking
Practice → "Test folders and analysis". Mock and Subject folders, tests with date and paper pattern (future tests only need name + date), tap a test to mark each question Attempted / Review / Important / Doubt, add the result (score, percentile, rank, total students auto-fill each other), set Pending / In process / Analysed, and plan the analysis as a homework item. Syncs as the same `zz_tests*` rows as the web app.
Next (6B): attempts with mistake reasons and the analysis hub; (6C): mistake notebook, chapter report, PDF share.

## Stage 6B: attempts and reports
Tap a test with a pattern to open its page: start an attempt (Exam with the time limit, or Practice), "Wrong & skipped" to redo only what you have not got right, and the list of attempts. Every attempt is saved per question (`zz_att_<test>_<n>` rows, same as the web app). The attempt report has Summary (score, marks lost by reason, first look vs coming back, comparison with the previous attempt), Subjects, Time and Questions (tag why a mistake happened, add a note). When a test attempt ends, "Attempt report" opens it directly.
Still to come (6C): chapter tags and Chapters tab, paper attempts, target score, plan from a report, PDF share, mistake notebook, chapter report.

## Stage 6C: chapters, notebook, chapter report
- Test page → "Paper & chapters": tap a first and last question to select a range (or "One by one"), then "Chapter" to tag them from your syllabus. Tags are stored in the same paper record as the web app.
- Attempt report has a Chapters tab (weakest first) and "Share report" (text) and "Tag chapters".
- More → Reports: Mistake notebook (latest wrong/skipped questions of all tests, filters by reason, "Attempt these N") and Chapter report (all tests together).
Not yet: paper-attempt logging, target score, plan-from-report, PDF share. Syllabus screen comes in Stage 7 (chapters must exist in the synced syllabus to tag).
